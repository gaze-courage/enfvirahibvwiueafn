#include <cstdint>
#include <cstddef>
#include <functional>
#include <string>
#include <stdint.h>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <deque>
#include <unordered_set>
#include <unordered_map>
#include <chrono>
#include <random>
#include <mutex>
#include <atomic>

using namespace std;




// 硬盘存储结构


atomic<long long> Code_Time = 0;

// 运算端状态控制量
char IF_SELF_TURN_OFF = 1; // 整体程序开关
char IF_SELF_COMMUNIATE = 0;
char IF_SELF_CONNECT = 0;
char IF_SELF_WORKING = 0; // 模型运行开关

// 执行端状态控制量
char IF_NEED_COMMUNIATE = 1;
char IF_NEED_WORKING = 1;
char IF_NEED_CAPTURE = 0;
char IF_NEED_ACTION = 0;

atomic<unsigned int> NEWIST_USEFUL_ID = 1;  // 最新可用节点id
atomic<long long> CURRENT_MODEL_TIME = 100; // 模型时间，不依赖系统时间，是模型迄今为止运行过的时间，每1ms前进一
atomic<unsigned int> ALL_NUM_OF_CH = 0;     // 存在的字符数量
atomic<unsigned int> LAST_PACK_NUMBER = 0;  // 快速读取文件的包数

atomic<int> FREE_ID_NUM = 0;
vector<unsigned int> FREE_ID_LIST; // 曽被删除的节点id
atomic<int> Free_Id_Ocuppy(0);

atomic<int> CURRENT_SYSTEM_MEMORY;

// 包使用频度计算 使用频度与重要性
char time_curr = 0;
atomic<long long> use_time[4] = {0, 0, 0, 0};
atomic<int> time_node_occupy[4] = {0, 0, 0, 0};
atomic<int> node_total_occupy = 0;


// 模型状态记录文件
struct state_record_file
{
    unsigned int newist_useful_id = 1; // 最新可用编号
    unsigned int all_num_of_ch = 0;    // 存在的字符数量
    unsigned int last_pack_num = 0;    // 预读取文件的包数

    char time_curr = 0;
    int time_node_occupy[4] = {0, 0, 0, 0};
    long long use_time[4] = {0, 0, 0, 0};
    long long node_total_occupy = 0;

    long long current_model_time = 100; // 已用模型时间
    long long size_of_pre_load_file = 0;
};


// 初始化状态记录文件函数
void init_model_record()
{
    // 打开文件
    FILE *fp = fopen("Record_Model_State.rec", "r");

    state_record_file rf;
    state_record_file *ptr = &rf;
    // 失败，创建文件
    if (fp)
    {
        // 成功，读入文件
        fread(ptr, sizeof(state_record_file), 1, fp);

        fseek(fp, sizeof(state_record_file), 1);
        fread(&FREE_ID_NUM, sizeof(int), 1, fp);

        FREE_ID_LIST.resize(FREE_ID_NUM);
        fseek(fp, sizeof(int), 1);
        fread(FREE_ID_LIST.data(), sizeof(int) * FREE_ID_NUM, 1, fp);

        fclose(fp); // 关闭
    }
    // 赋予文件属性
    NEWIST_USEFUL_ID = rf.newist_useful_id;
    CURRENT_MODEL_TIME = rf.current_model_time;
    ALL_NUM_OF_CH = rf.all_num_of_ch;
    LAST_PACK_NUMBER = rf.last_pack_num;

    time_curr = rf.time_curr;
    time_node_occupy[0] = rf.time_node_occupy[0];
    time_node_occupy[1] = rf.time_node_occupy[1];
    time_node_occupy[2] = rf.time_node_occupy[2];
    time_node_occupy[3] = rf.time_node_occupy[3];
    use_time[0] = rf.use_time[0];
    use_time[1] = rf.use_time[1];
    use_time[2] = rf.use_time[2];
    use_time[3] = rf.use_time[3];
    node_total_occupy = rf.node_total_occupy;
}

// 运行状态记录保存函数
void save_record_model()
{
    // 打开文件
    FILE *fp = fopen("Record_Model_State.rec", "w");
    state_record_file rf;
    state_record_file *ptr = &rf;

    // 赋予文件属性
    rf.newist_useful_id = NEWIST_USEFUL_ID;
    rf.current_model_time = CURRENT_MODEL_TIME;
    rf.all_num_of_ch = ALL_NUM_OF_CH;
    rf.last_pack_num = LAST_PACK_NUMBER;

    rf.time_curr = time_curr;
    rf.time_node_occupy[0] = time_node_occupy[0];
    rf.time_node_occupy[1] = time_node_occupy[1];
    rf.time_node_occupy[2] = time_node_occupy[2];
    rf.time_node_occupy[3] = time_node_occupy[3];
    rf.use_time[0] = use_time[0];
    rf.use_time[1] = use_time[1];
    rf.use_time[2] = use_time[2];
    rf.use_time[3] = use_time[3];
    rf.node_total_occupy = node_total_occupy;

    fwrite(ptr, sizeof(state_record_file), 1, fp);

    fseek(fp, sizeof(state_record_file), 1);
    fwrite(&FREE_ID_NUM, sizeof(int), 1, fp);

    fseek(fp, sizeof(int), 1);
    fwrite(FREE_ID_LIST.data(), sizeof(int) * FREE_ID_NUM, 1, fp);

    // 关闭
    fclose(fp);
}

// 单个存储包内部结构
struct Pack_Inside
{
    unsigned int attribute_item[256];
};
// 256*4字节

vector<Pack_Inside> Neuro_Pack_Storage;         // 神经元包的存储，占很大内存，10~20g
vector< atomic<char> > Neuro_Pack_Read_Occupy;  // 对包占用数据记录，控制同时读，不可写
vector< atomic<char> > Neuro_Pack_Write_Occupy; // 写时不可再 读写
atomic<int> Neuro_Pack_Push_Occupy(0);

unordered_map<unsigned int, uint32_t> Pack_Vector_Index_Find;   // 存储神经元包下标
vector<uint32_t> Free_Pack_Index_List;  // 空包回收
vector<uint32_t> Free_2_Pack_Index_List;
vector<uint32_t> Free_4_Pack_Index_List;
vector<uint32_t> Free_8_Pack_Index_List;
atomic<int> Free_Neuro_Pack_Occupy(0);

long long Pack_Limit = 10 * 10000; // 1500 * 10000包量略小于16g，1200 * 10000略小于13g
atomic<long long> Free_Pack_Num(Pack_Limit - 1);
atomic<long long> Current_Pack_Num(1);



struct Pack_Record
{
    char is_use = 1;
    char pack_state = 1; // 包状态，可使用空间0，待存储读入1，空闲中2，使用中3，修改中4，连带包5，待存储写入6
    char pack_size = 0;
    char time_curr = 0;

    unsigned int pack_id = 0; // 自身编号

    unsigned int use_time[8] = {0, 0, 0, 0, 0, 0, 0, 0}; // 时间清理统计
    unsigned int history_use_num[4] = {0, 0, 0, 0};      // 被占用的总数
};
// 14*4字节

vector<Pack_Record> Neuro_Pack_Record_Storage;  // 神经元包的存储记录
vector< atomic<char> > Neuro_Pack_Record_Occupy;// 读写占用


// 上次运行结束数据读取
void get_pre_load_file()
{
    // 存储初始化
    Neuro_Pack_Storage.reserve(Pack_Limit);
    Neuro_Pack_Storage.resize(1 + LAST_PACK_NUMBER);
    
    Neuro_Pack_Record_Storage.reserve(Pack_Limit);
    Neuro_Pack_Record_Storage.resize(1 + LAST_PACK_NUMBER);
    
    // 原子类型的初始化怎么做
    // Neuro_Pack_Read_Occupy.resize(Pack_Limit);
    // Neuro_Pack_Write_Occupy.resize(Pack_Limit);
    // Pack_Vector_Index_Find.reserve(Pack_Limit);

    if (!LAST_PACK_NUMBER)
        return; // 无记录

    FILE* fp_I = fopen("Record_Pre_Load_File_I.rec", "r");
    FILE* fp_II = fopen("Record_Pre_Load_File_II.rec", "r");

    if (fp_I && fp_II)
    {
        int size_neuro_inside = sizeof(Pack_Inside);
        int size_neuro_record = sizeof(Pack_Record);

        Pack_Inside single_data;
        Pack_Inside* single_data_ptr = &single_data;

        Pack_Record single_record;
        Pack_Record* single_record_ptr = &single_record;

        int i = 1;

        while (i <= LAST_PACK_NUMBER)
        {
            fread(single_data_ptr, size_neuro_inside, 1, fp_I);
            fread(single_record_ptr, size_neuro_record, 1, fp_II);

            Neuro_Pack_Storage[i] = single_data;
            Neuro_Pack_Record_Storage[i] = single_record;

            if (single_record.pack_state)
                Pack_Vector_Index_Find[single_record.pack_id] = i;
            else
                Free_Pack_Index_List.push_back(i);

            fseek(fp_I, size_neuro_inside, 1);
            fseek(fp_II, size_neuro_record, 1);

            i++;
        }

        fclose(fp_I);
        fclose(fp_II);
    }
}

// 下次运行初始数据保存
void save_pre_load_file()
{
    FILE *fp = fopen("Record_Pre_Load_File.rec", "w");
    LAST_PACK_NUMBER = Neuro_Pack_Storage.size() - 1;
    fwrite(Neuro_Pack_Storage.data() + 1, LAST_PACK_NUMBER * sizeof(Pack_Inside), 1, fp);
    fclose(fp);
}

// 包位置查找函数
uint32_t pack_index_find(unsigned int target)
{
    auto position = Pack_Vector_Index_Find.find(target);

    if (position != Pack_Vector_Index_Find.end())
        return (position->second); // 在存储中的下标
    else
        return 0; // 包不存在
}

// 包位置提供函数
uint32_t pack_position_insert(unsigned int target, char pack_num) // 返回下标
{
    uint32_t first_idx;
    uint32_t idx;

    if(Free_Pack_Num.load() < 16)
        return 0;

    Current_Pack_Num.fetch_add(pack_num);

    //四种大小的包的需求
    if(pack_num == 1)
    {
        if (!Free_Pack_Index_List.empty())
        { // 覆盖
            int expected = 0;
            while(Free_Neuro_Pack_Occupy.compare_exchange_strong(expected, 1, memory_order_seq_cst) )
                expected = 0;

            idx = Free_Pack_Index_List.back();
            Free_Pack_Index_List.pop_back();

            expected = 1;
            while(Free_Neuro_Pack_Occupy.compare_exchange_strong(expected, 0, memory_order_seq_cst) )
                expected = 1;
            
            first_idx = idx;

            Neuro_Pack_Record_Storage[idx].pack_size = pack_num;
            Neuro_Pack_Record_Storage[idx].pack_state = 1;

        } else { // 新建
            Pack_Record new_record;
            new_record.pack_size = pack_num;
            new_record.pack_state = 1;

            Pack_Inside new_object; 

            int expected = 0;
            while( Neuro_Pack_Push_Occupy.compare_exchange_strong(expected, 1, memory_order_seq_cst) )
                expected = 0;

            idx = Neuro_Pack_Storage.size();
            Neuro_Pack_Record_Storage.push_back(new_record);
            Neuro_Pack_Storage.push_back(new_object);

            expected = 1;
            while( Neuro_Pack_Push_Occupy.compare_exchange_strong(expected, 0, memory_order_seq_cst) )
                expected = 1;
        }
    } else if(pack_num == 2) {

        char curr_check = 0;
        uint32_t cover_check[8];
        char suitable_success = 1;

        while (!Free_2_Pack_Index_List.empty())
        { // 覆盖
            int expected = 0;
            while( !Free_Neuro_Pack_Occupy.compare_exchange_strong(expected, 1, memory_order_seq_cst) )
                expected = 0;

            idx = Free_2_Pack_Index_List.back();
            Free_2_Pack_Index_List.pop_back();

            expected = 1;
            while( !Free_Neuro_Pack_Occupy.compare_exchange_strong(expected, 0, memory_order_seq_cst) )
                expected = 1;

            //三重检验
            char expected_char = 0;

            //存储连续性检验
            while(curr_check < pack_num && suitable_success != 0)
            {
                //提前筛出
                if(Neuro_Pack_Record_Storage[idx].pack_state != 0)
                {
                    suitable_success = 0;
                    break;
                }

                //非写
                while(!Neuro_Pack_Write_Occupy[idx].compare_exchange_strong(expected_char, 1, memory_order_seq_cst))
                    expected_char = 0;
                  
                //非读
                while(!Neuro_Pack_Read_Occupy[idx].compare_exchange_strong(expected_char, 1, memory_order_seq_cst))
                    expected_char = 0;

                //非占用
                if(Neuro_Pack_Record_Storage[idx].pack_state == 0)
                {
                    cover_check[curr_check] = idx;
                    curr_check++;

                    if(curr_check == pack_num - 1)
                    {
                        suitable_success = 2;
                        curr_check = 0;
                        first_idx = cover_check[0];
                        
                        //全体包填写
                        while(curr_check < pack_num)
                        {
                            idx = cover_check[curr_check];
                            Neuro_Pack_Record_Storage[idx].pack_size = pack_num;
                            Neuro_Pack_Record_Storage[idx].pack_state = 1;

                            //解除占用
                            Neuro_Pack_Write_Occupy[idx].fetch_sub(1);
                            Neuro_Pack_Read_Occupy[idx].fetch_sub(1);
                        }
                    }//成功找到连续位置

                } else {
                    suitable_success = 0;
                    break;
                }
            }
            
        }// 覆盖结束 或 失败
        
        if (Free_2_Pack_Index_List.empty() && suitable_success != 2)
        {
            // 新建
            int expected = 0;
            while( Neuro_Pack_Push_Occupy.compare_exchange_strong(expected, 1, memory_order_seq_cst) )
                expected = 0;
            
            Pack_Record new_record;
            new_record.pack_size = pack_num;
            new_record.pack_state = 1;
            idx = Neuro_Pack_Record_Storage.size();
            Neuro_Pack_Record_Storage.push_back(new_record);

            first_idx = idx;

            Pack_Inside new_object; 
            Neuro_Pack_Storage.push_back(new_object);
            pack_num--;

            while(pack_num)
            {
                Pack_Record new_record;
                new_record.pack_state = 5;
                idx = Neuro_Pack_Record_Storage.size();
                Neuro_Pack_Record_Storage.push_back(new_record);

                Pack_Inside new_object; 
                Neuro_Pack_Storage.push_back(new_object);
                pack_num--;
            }

            expected = 1;
            while( Neuro_Pack_Push_Occupy.compare_exchange_strong(expected, 0, memory_order_seq_cst) )
                expected = 1;
        }

    } else if(pack_num == 4) {

        char curr_check = 0;
        uint32_t cover_check[8];
        char suitable_success = 1;

        while (!Free_4_Pack_Index_List.empty())
        { // 覆盖
            int expected = 0;
            while( !Free_Neuro_Pack_Occupy.compare_exchange_strong(expected, 1, memory_order_seq_cst) )
                 expected = 0;
            
            idx = Free_4_Pack_Index_List.back();
            Free_4_Pack_Index_List.pop_back();

            expected = 1;
            while( !Free_Neuro_Pack_Occupy.compare_exchange_strong(expected, 0, memory_order_seq_cst) )
                 expected = 1;
            //三重检验
            char expected_char = 0;

            //存储连续性检验
            while(curr_check < pack_num && suitable_success != 0)
            {
                //提前筛出
                if(Neuro_Pack_Record_Storage[idx].pack_state != 0)
                {
                    suitable_success = 0;
                    break;
                }

                //非写
                while(!Neuro_Pack_Write_Occupy[idx].compare_exchange_strong(expected_char, 1, memory_order_seq_cst))
                    expected_char = 0;
                
                //非读
                while(!Neuro_Pack_Read_Occupy[idx].compare_exchange_strong(expected_char, 1, memory_order_seq_cst))
                    expected_char = 0;

                //非占用
                if(Neuro_Pack_Record_Storage[idx].pack_state == 0)
                {
                    cover_check[curr_check] = idx;
                    curr_check++;

                    if(curr_check == pack_num - 1)
                    {
                        suitable_success = 2;
                        curr_check = 0;
                        first_idx = cover_check[0];
                        
                        //全体包填写
                        while(curr_check < pack_num)
                        {
                            idx = cover_check[curr_check];
                            Neuro_Pack_Record_Storage[idx].pack_size = pack_num;
                            Neuro_Pack_Record_Storage[idx].pack_state = 1;

                            //解除占用
                            Neuro_Pack_Write_Occupy[idx].fetch_sub(1);
                            Neuro_Pack_Read_Occupy[idx].fetch_sub(1);
                        }
                    }//成功找到连续位置

                } else {
                    suitable_success = 0;
                    break;
                }
            }
            
        }// 覆盖结束 或 失败
        
        if (Free_4_Pack_Index_List.empty() && suitable_success != 2)
        {
            // 新建
            int expected = 0;
            while( Neuro_Pack_Push_Occupy.compare_exchange_strong(expected, 1, memory_order_seq_cst) )
                expected = 0;
            
            Pack_Record new_record;
            new_record.pack_size = pack_num;
            new_record.pack_state = 1;
            idx = Neuro_Pack_Record_Storage.size();
            Neuro_Pack_Record_Storage.push_back(new_record);

            first_idx = idx;

            Pack_Inside new_object; 
            Neuro_Pack_Storage.push_back(new_object);
            pack_num--;

            while(pack_num)
            {
                Pack_Record new_record;
                new_record.pack_state = 5;
                idx = Neuro_Pack_Record_Storage.size();
                Neuro_Pack_Record_Storage.push_back(new_record);

                Pack_Inside new_object; 
                Neuro_Pack_Storage.push_back(new_object);
                pack_num--;
            }

            expected = 1;
            while( Neuro_Pack_Push_Occupy.compare_exchange_strong(expected, 0, memory_order_seq_cst) )
                expected = 1;
        }

    } else if(pack_num == 8) {
        
        char curr_check = 0;
        uint32_t cover_check[8];
        char suitable_success = 1;

        while (!Free_8_Pack_Index_List.empty())
        { // 覆盖
            int expected = 0;
            while( !Free_Neuro_Pack_Occupy.compare_exchange_strong(expected, 0, memory_order_seq_cst) )
                expected = 0;
            idx = Free_8_Pack_Index_List.back();
            Free_8_Pack_Index_List.pop_back();

            expected = 1;
            while( !Free_Neuro_Pack_Occupy.compare_exchange_strong(expected, 0, memory_order_seq_cst) )
                expected = 1;
            //三重检验
            char expected_char = 0;

            //存储连续性检验
            while(curr_check < pack_num && suitable_success != 0)
            {
                //提前筛出
                if(Neuro_Pack_Record_Storage[idx].pack_state != 0)
                {
                    suitable_success = 0;
                    break;
                }

                //非写
                while(!Neuro_Pack_Write_Occupy[idx].compare_exchange_strong(expected_char, 1, memory_order_seq_cst))
                    expected_char = 0;
                
                //非读
                while(!Neuro_Pack_Read_Occupy[idx].compare_exchange_strong(expected_char, 1, memory_order_seq_cst))
                    expected_char = 0;

                //非占用
                if(Neuro_Pack_Record_Storage[idx].pack_state == 0)
                {
                    cover_check[curr_check] = idx;
                    curr_check++;

                    if(curr_check == pack_num - 1)
                    {
                        suitable_success = 2;
                        curr_check = 0;
                        first_idx = cover_check[0];
                        
                        //全体包填写
                        while(curr_check < pack_num)
                        {
                            idx = cover_check[curr_check];
                            Neuro_Pack_Record_Storage[idx].pack_size = pack_num;
                            Neuro_Pack_Record_Storage[idx].pack_state = 1;

                            //解除占用
                            Neuro_Pack_Write_Occupy[idx].fetch_sub(1);
                            Neuro_Pack_Read_Occupy[idx].fetch_sub(1);
                        }
                    }//成功找到连续位置

                } else {
                    suitable_success = 0;
                    break;
                }
            }
            
        }// 覆盖结束 或 失败
        
        if (Free_8_Pack_Index_List.empty() && suitable_success != 2)
        {
            // 新建
            int expected = 0;
            while( Neuro_Pack_Push_Occupy.compare_exchange_strong(expected, 1, memory_order_seq_cst) )
                expected = 0;
            
            Pack_Record new_record;
            new_record.pack_size = pack_num;
            new_record.pack_state = 1;
            idx = Neuro_Pack_Record_Storage.size();
            Neuro_Pack_Record_Storage.push_back(new_record);

            first_idx = idx;

            Pack_Inside new_object; 
            Neuro_Pack_Storage.push_back(new_object);
            pack_num--;

            while(pack_num)
            {
                Pack_Record new_record;
                new_record.pack_state = 5;
                idx = Neuro_Pack_Record_Storage.size();
                Neuro_Pack_Record_Storage.push_back(new_record);

                Pack_Inside new_object; 
                Neuro_Pack_Storage.push_back(new_object);
                pack_num--;
            }

            expected = 1;
            while( Neuro_Pack_Push_Occupy.compare_exchange_strong(expected, 0, memory_order_seq_cst) )
                expected = 1;
        }
    }
    
    Pack_Vector_Index_Find[target] = first_idx;

    return first_idx;
} // 函数结束

// 包删除函数
void pack_delete(unsigned int target)
{
    uint32_t pack_idx = pack_index_find(target);

    if (pack_idx == 0)
        return;

    // 目标存在
    Pack_Vector_Index_Find.erase(target);
    Neuro_Pack_Record_Storage[pack_idx].pack_state = 0;

    char pack_size = Neuro_Pack_Record_Storage[pack_idx].pack_size;

    if(pack_size == 1)
    {
        Neuro_Pack_Record_Storage[pack_idx].pack_state = 0;
        Free_Pack_Index_List.push_back(pack_idx);
    } else if(pack_size == 2) {

        Neuro_Pack_Record_Storage[pack_idx].pack_state = 0;
        Free_2_Pack_Index_List.push_back(pack_idx);
        
        //载入更小的包
        // while (pack_size > 0)
        // {
        //     Neuro_Pack_Record_Storage[pack_idx].pack_state = 0;
        //     Free_Pack_Index_List.push_back(pack_idx);
        //     pack_idx += 1;
        //     pack_size--;
        // }

    } else if(pack_size == 4) {

        Neuro_Pack_Record_Storage[pack_idx].pack_state = 0;
        Free_4_Pack_Index_List.push_back(pack_idx);

    } else if(pack_size == 8) {

        Neuro_Pack_Record_Storage[pack_idx].pack_state = 0;
        Free_8_Pack_Index_List.push_back(pack_idx);

    }
    
    //未原子化 和 多空余队列添加

} // 函数结束


// 生成随机值 均等生成 0~255 之内的随机数
inline uint8_t rand_0_to_255()
{
    static thread_local uint32_t x = 764182953u;
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    return uint8_t(x);
}

// 共享随机值生成
random_device Union_RD;
mt19937 Union_Gen(Union_RD());

// 记忆管理
int current_01s_memory_value = 0;
char memory_time_num = 0;
float total_memory_value_10s_average = 0;

int newly_use_memoey = 0;
int newly_memory_max_value; // 不能超过总值，不能超过写值
float newly_memory_max_rate = 0.05; // 中的
float newly_memory_attract = 1;

atomic<int> restore_memory_need_value = 0;
float restore_memory_rate;

atomic<int> recall_memory_need_value = 0;
float recall_memory_rate;

// 待读取任务队列
deque<unsigned int> Will_Read_Neuro_Queue;
mutex mutex_will_read;

// 待写入任务队列
deque<unsigned int> Will_Write_Neuro_Queue;
mutex mutex_will_write;

void add_to_Will_Read_Neuro_Queue(unsigned int target)
{
    mutex_will_read.lock();
    Will_Read_Neuro_Queue.push_back(target);
    mutex_will_read.unlock();

    recall_memory_need_value.fetch_add(1);
}

void add_to_Will_Write_Neuro_Queue(unsigned int target)
{
    mutex_will_write.lock();
    Will_Write_Neuro_Queue.push_back(target);
    mutex_will_write.unlock();
    
    restore_memory_need_value.fetch_add(1);
}

// 一字节转string类型
string byteToHex(uint8_t byte)
{
    std::string out;
    static const char hex[] = "0123456789ABCDEF";
    out[0] = hex[(byte >> 4) & 0x0F]; // 高 4 位
    out[1] = hex[byte & 0x0F];        // 低 4 位
    return out;
}

// unsigned int类型的量转化成路径
std::string VariableToPath(unsigned int target)
{
    // 目录名生成
    string dir1 = byteToHex(static_cast<unsigned char>((target >> 24) & 0xFF));
    string dir2 = byteToHex(static_cast<unsigned char>((target >> 16) & 0xFF));
    string dir3 = byteToHex(static_cast<unsigned char>((target >> 8) & 0xFF));
    string name4 = byteToHex(static_cast<unsigned char>((target) & 0xFF));

    // 构建目录路径 （ linux版路径）
    std::string directory;
    directory = dir1 + "/" + dir2 + "/" + dir3 + "/" + name4 + ".n";

    // 返回完整路径
    return directory;
} // 函数结束

// 计算神经元消耗的存储空间
long long ALL_NEURO_RAM = 0;

// 内存消耗计算函数，未完成改，无含网络占用统计
void ram_coast()
{
    ALL_NEURO_RAM = sizeof(Pack_Inside) * Neuro_Pack_Storage.size();
}

long long one_G = 1024 * 1024 * 1024;

long long LIMIT_RAM = 24 * one_G; // 允许的上限内存

float Pack_Attract_Rate = 0;

int gap_time = 16 * 256; // 约4s

long long time_update_gap = 0xFFFFFFFFFFFFF000;

// 神经元使用记录 更新函数
void neuro_use_record_update(unsigned int target_id)
{
    // 更新
    uint32_t idx = Pack_Vector_Index_Find[target_id];
    Pack_Record& pack_record = Neuro_Pack_Record_Storage[idx];

    long long curr_time = 0;
    long long front = pack_record.use_time[pack_record.time_curr * 2];
    front = front << 32;
    long long back = pack_record.use_time[pack_record.time_curr * 2 + 1];
    curr_time |= front;
    curr_time |= back;

    if (curr_time != (CURRENT_MODEL_TIME & time_update_gap) )
    {
        pack_record.time_curr += 1;

        if (pack_record.time_curr >= 4)
            pack_record.time_curr = 0;

        curr_time = CURRENT_MODEL_TIME & time_update_gap;

        pack_record.use_time[pack_record.time_curr * 2] = curr_time >> 32;
        pack_record.use_time[pack_record.time_curr * 2 + 1] = curr_time & 0xffffffff;
    }

    pack_record.history_use_num[pack_record.time_curr] += 1;

    time_node_occupy[time_curr] += 1;

} // 使用次数更新函数结束


// 冷包剔除函数
void Cool_Pack_Delete()
{
    //非重要内存数据剔除
    int Half_Pack_Limit = Pack_Limit * 0.5;

    while (IF_SELF_TURN_OFF)
    {
        // 包增加容忍度计算公式
        Pack_Attract_Rate = (Half_Pack_Limit - Current_Pack_Num.load()) / Half_Pack_Limit;

        for (int a = 0; a < 4; a++)
            node_total_occupy += time_node_occupy[a];

        float ave_occupy = node_total_occupy / (Current_Pack_Num.load() + 1);

        // 使用频度衰减--- 数据占用程度，取时间使用性
        int i = 1;
        while (i < Neuro_Pack_Storage.size())
        {
            Pack_Record& pack_record = Neuro_Pack_Record_Storage[i];

            if (pack_record.pack_state == 0 || pack_record.pack_state != 2)
                continue;

            int curr_pack_total_history_use_num = 0;
            long long low_permit = use_time[time_curr] - 4 * gap_time;

            for (int b = 0; b < 4; b++)
            {
                if (*(long long *)(pack_record.use_time + 2 * b) < low_permit)
                    continue;
                
                curr_pack_total_history_use_num += pack_record.history_use_num[b];
            }

            float Curr_Pack_Attract = (curr_pack_total_history_use_num - ave_occupy) / ave_occupy;

            // 触发删除判定
            if (CURRENT_MODEL_TIME - *(long long *)(pack_record.use_time + pack_record.time_curr * 2) > 360000 // 360秒未使用
                || Curr_Pack_Attract + Pack_Attract_Rate < 0)
            {
                // 包使用记录 删除
                pack_record.pack_state = 6;

                // 删除包
                add_to_Will_Write_Neuro_Queue(pack_record.pack_id);
            } // 触发删除判定 解决
            i++;

        } // 以遍历完一个包
        i = 1;

    } // 重复工作
}


// 神经元查找函数，返回节点首字节的指针
unsigned int* node_find(unsigned int target)
{
    int vec_pos = pack_index_find(target);

    if (vec_pos == -1)
        return 0;

    neuro_use_record_update(target);

    unsigned int * return_ptr = Neuro_Pack_Storage[vec_pos].attribute_item;
    
    return return_ptr;
} // 函数结束


// 神经元相关属性

// 神经元头部数据
struct Neuro_Head_Attribute
{
    unsigned char neuro_kind;     // 节点性质
    unsigned char node_size = 1;  // 节点大小
    unsigned short used_item_num = 0;   // 已用节点特征数量，limit上限:256、512、1024
}; // 神经元架构，1*4字节

// 神经元节点 头部数据返回函数
Neuro_Head_Attribute neuro_head_read(int x) // 输入头目属性
{
    Neuro_Head_Attribute s;
    s.neuro_kind = (x >> 24) & 0xFF;
    s.node_size = (x >> 16) & 0xFF;
    s.used_item_num = x & 0xFFFF;
    return s;
} // 函数结束


// 图像神经元描述
struct Image_Neuro_Desc
{
    char neuro_is_image = 1;
    char detail_kind;    // 线段形态1，色彩线段2，复合图形3
    char source_num = 0; // 来源数量
    char predict_stability_8_num = 0; // 上限8/16/32

    int neuro_active_num = 0; // 使用次数
    int self_attention = 0;

    // 3*4字节
    //理解需求相关
    float predict_stability_8 = 0; // 预测稳定性(8次以内)
    // float predict_stability_32 = 0; // 预测稳定性(32次以内)

    float appear_worth = 0; // 出现价值，由注意力结合生成率 汇总而成
    //减少了多少预测/识别消耗，或者预测/识别了多少
    //长期预测繁复

    //出现幅度衡量

    //外部好感
    float puruse = 0;

    //理解需求 和 实现需求

    // 内部属性数

    // 独有属性
    // unsigned char red;
    // unsigned char green;
    // unsigned char blue;

    // unsigned char length;
    // unsigned char direction;


}; // 15*4字节，神经元架构

// 文本神经元描述
struct Text_Neuro_Desc
{
    char neuro_is_text = 2;
    char detail_kind;   // 字符1 文本2
    char source_num;    // 来源数量
    char predict_stability_num = 0; // 使用上限8/16/32

    int neuro_active_num = 0; // 使用次数
    int self_attention = 0;
    // 3*4字节

    float predict_stability = 0; // 预测稳定性 与其他值控制 model_require_average

    // 内部属性数
    // int stat_num = 0;    // 统计属性数量
    // int fusion_num = 0;  // 聚合属性数量

}; // 15*4字节，神经元架构

// 概念神经元描述
struct Concept_Neuro_Desc
{
    char neuro_is_concept = 3;
    char be_restrain_num = 0;
    char source_num = 0;
    char predict_stability_num = 0; // 上限8/16/32

    int neuro_active_num = 0; // 使用次数
    int self_attention = 0;
    // 3*4字节

    float predict_stability = 0; /* 预测稳定性，这个值是平均数，加上最近的节点值再平均，
    精度有损的估计方法，但是存储很低就可以获取最近时间内的需求 */

    // 内部属性数
};
// 15*4字节，神经元架构

// 数量条目
struct Number_Item
{
    int active_stat_num = 0;    // 激活或统计的次数
    int realize_detect_num = 0; // 实现或探测的次数
};
// 2*4字节，神经元架构

struct Image_Item
{
    char direction; // 方向区间
    char direction_scale = 3;   // 方向覆盖规模 0(无方向性)、1=1、2=3、3=5 向两旁蔓延的幅度

    char distance;  // 距离区间
    char distance_scale = 3;    // 距离覆盖规模 0(无距离性)、1=1、2=3、3=5，原区间+-得到

    char logic;         // 生成逻辑 或 模拟中应该有1
    char related_scale; // 相对尺度，正数为当前尺度偏对方大 负数为当前尺度偏对方小 1为使用尺度相同
    char a;
    char b;

    unsigned int related_id;
};
// 3*4字节，神经元架构

// 内部自定位条目
struct Self_Cognition_Item
{
    unsigned char coding_mode = 0; // 叠层1，直接2，延续叠层3
    unsigned char self_inside_I = 0;
    unsigned char self_inside_II = 0;
    unsigned char self_inside_III = 0;
};
// 1*4字节

// 主动观测条目 
struct Initiative_Observation_Item
{
    //方向，距离
    //
    unsigned int target;
};

// 文本神经元
// 文本空间组合属性
struct Text_Item
{
    char left_distance = 1;           // 左端作用位置，-8～8
    char right_distance = 1;          // 右端作用位置，-8～8
    unsigned char distance_scale = 4; // 距离幅度，2的指数，1=1，2=2，3=4，4=8
    char logic = 0; // 生成文本1，生成概念2  或 统计字符1，统计字符串2 或 模拟中应该有1

    unsigned int target_id;
};
// 2*4字节，神经元架构

// 概念神经元

// 时间相关条目
struct Time_Item
{
    char time_range;    // 时间区域(-8~8)，0是同时，1是从此刻至一尺度时间，2是一尺度至二尺度，类推
    char time_scale;    // 时间尺度，通常是0是无尺度(仅模糊方向)，1是0.1秒，2是0.4秒(每次乘4倍)，3是1.6秒，类推1、2、3、4(6.4)
    char time_logic = 0;    // 对象存在1，对象不存在2
    char item_detail = 0; // 模拟中应该有1

    unsigned int related_id;// 生成对象
};
//2*4字节，神经元架构


// 输出行为条目
struct External_Action_Item
{
    char action_kind;              // 鼠标1，键盘2，文本传回3，文本显示4，窗口隐藏5，窗口显示6
    unsigned char vk_or_mouseData; // 键码，滚轮为char乘120
    char direction;                // 方向区间
    char distance;                 // 距离区间

    unsigned int dwFlags;

    unsigned int target_id; // 定位本体id 附属在待操作的图形条件的定位点
}; // 3*4字节，神经元架构

// 两者同一的信念，未经证实的推测，文本呈递的经验
// 认知信念条目
struct Connition_Belief_Item
{
    char belief_kind; // 同一/对应1，产生2，信息3
    // 信念强度
    // 信念概率 置信度
    unsigned int belief_object; // 等同的对象
};

// 态度管理属性
struct Emotion_Item
{
    char emotion_kind; // 注意力需求1 识别需求2 理解需求3 实现需求4
    //统计指标：关注度 清楚度 可能性 
    //追求指标：好感度 求知欲 合理性

    //理解时间 理解空间 理解文本
    //识别空间 识别时间 识别文本
    //时间上的实现 特定空间上的时间的实现

    int emotion_value;
    // float attention_rate; // 比例
    unsigned int effect_id;
};


// 因果抑制条目
struct Casual_Restrain_Item
{
    unsigned int Restrain_Target;
    
};

// 通用条件
union General_Condition
{
    unsigned int condition;
    Image_Item image_condition;
    Time_Item time_condition;
    Text_Item text_condition;
    External_Action_Item action_conditon;
    //brief
    
};

// 通用结果
union General_Result
{
    unsigned int result;
    Image_Item image_result;
    Time_Item time_result;
    Text_Item text_result;
    Emotion_Item emotion_result;
};

// 通用可变属性
struct General_Flow_Attribute
{
    //
    unsigned char attritube_kind; // 前四比特：概率与统计1，生成2，抑制3，类别4，下级分解5，主观行动6，
    // 后四比特：可否升级

    unsigned char condition_result_kind;//同通

    unsigned char condition_num; // **是 *不是
    unsigned char result_num;    // **是 *不是

    int active_stat_num;    // 激活、统计的次数
    int realize_detect_num; // 生成、实现的次数

    // //
    General_Condition condition[4];
    General_Result result[4];
    // //

}; //(4~23)*4字节，神经元架构

struct Attribute_Head
{
    char attribute_kind = 0; // 必填，概率与统计1，生成2，下级分解3，类别4，抑制5，主观行动6，
    char able_update = 0; // 可升级1 已有升级精细化2 已有升级节点化3 已有升级多样化4
    
    char condition_kind = 0; // 必填，图像1、时间2、文本3、行动4、
    char condition_num = 0; // 必填
    char un_condition_num = 0; // 必填
    char condition_size;

    char result_kind = 0; // 必填，图像1、时间2、文本3、行动4、态度5
    char result_num = 0; // 必填
    char un_result_num = 0; // 必填
    char result_size;

    char item_num; // 所占4字节的数量
};

// 记录条目解析
Attribute_Head attribute_head_get(unsigned int *ptr)
{
    char one = *(char *)ptr;
    char two = *((char *)ptr + 1);
    char three = *((char *)ptr + 2);
    char four = *((char *)ptr + 3);

    Attribute_Head return_item;

    return_item.attribute_kind = one >> 4;
    return_item.able_update = one & 0xf;
    
    return_item.condition_kind = two >> 4;
    return_item.result_kind = two & 0xf;
    
    return_item.condition_num = three >> 4;
    return_item.un_condition_num = three & 0xf;

    return_item.result_num = four >> 4;
    return_item.un_result_num = four & 0xf;

    char condition_size;
    char result_size;

    if (return_item.condition_kind >= 2 && return_item.condition_kind <= 4)
        condition_size = 2;
    else if (return_item.condition_kind == 1)
        condition_size = 1;
    else if (return_item.condition_kind == 5)
        condition_size = 3;

    if (return_item.result_kind >= 2 && return_item.result_kind <= 4)
        result_size = 2;
    else if (return_item.result_kind == 1)
        result_size = 1;

    return_item.condition_size = condition_size;
    return_item.result_size = result_size;

    return_item.item_num = 3 + condition_size * (return_item.condition_num + three)
        + result_size * (return_item.result_kind + four);

    return return_item;
}

// 记录条目写入
void attribute_head_put(Attribute_Head item_head, vector<int>& target_list)
{
    int *ptr = target_list.data();

    char condition_kind = item_head.condition_kind;
    char result_kind = item_head.result_kind;
    char condition_num = item_head.result_num;
    char un_condition_num = item_head.un_condition_num;
    char result_num = item_head.result_num;
    char un_result_num = item_head.un_result_num;

    char condition_size;
    char result_size;

    if (condition_kind == 2 || condition_kind == 5)
        condition_size = 3;
    else if (condition_kind == 3 || condition_kind == 4)
        condition_size = 2;
    else if (condition_kind == 1)
        condition_size = 1;
    
    if(result_kind == 2)
        result_size = 3;
    else if (result_kind == 3 || result_kind == 4)
        result_size = 2;
    else if (result_kind == 1)
        result_size = 1;

    char item_num = 3 + condition_size * (condition_num + un_condition_num) + result_size * (result_num + un_result_num);

    target_list.resize(item_num);

    char one = condition_kind << 4;
    one |= result_kind;

    char two = condition_num << 4;
    two |= un_condition_num;

    char three = result_num << 4;
    three |= un_result_num;

    *((char *)ptr) = item_head.attribute_kind;
    *((char *)ptr + 1) = one;
    *((char *)ptr + 2) = two;
    *((char *)ptr + 3) = three;

    //没有神经元锁定
}

//通用属性写入
void general_attribute_put(Attribute_Head attribute_head, vector<int>& target_list,
    vector<General_Condition>& general_condition_list, vector<General_Result>& general_result_list)
{
    attribute_head_put(attribute_head, target_list);
    
    char condition_kind = attribute_head.condition_kind;
    char result_kind= attribute_head.result_kind;
    char condition_size = general_condition_list.size();
    char result_size = general_result_list.size();

    int* ptr = target_list.data();
    ptr += 3;

    switch(condition_kind)
    {
        case 1:
        {
            for(int a = 0; a < condition_size; a++)
            {
                general_condition_list[a].condition;

                ptr += 1;
            }
        }
        break;
        case 2:
        {
            for(int a = 0; a < condition_size; a++)
            {
                general_condition_list[a].image_condition;

                ptr += 2;
            }
        }
        break;
        case 3:
        {
            for(int a = 0; a < condition_size; a++)
            {
                general_condition_list[a].time_condition;

                ptr += 2;
            }
        }
        break;
        case 4:
        {
            for(int a = 0; a < condition_size; a++)
            {
                general_condition_list[a].text_condition;

                ptr += 2;
            }
        }
        break;
        case 5:
        {
            for(int a = 0; a < condition_size; a++)
            {
                general_condition_list[a].action_conditon;

                ptr += 3;
            }
        }
        break;
    }

    switch(result_kind)
    {
        case 1:
        {
            for(int b = 0; b < result_size; b++)
            {
                general_result_list[b].result;

                ptr += 1;
            }
        }
        break;
        case 2:
        {
            for(int b = 0; b < result_size; b++)
            {
                general_result_list[b].image_result;

                ptr += 2;
            }
        }
        break;
        case 3:
        {
            for(int b = 0; b < result_size; b++)
            {
                general_result_list[b].time_result;

                ptr += 2;
            }
        }
        break;
        case 4:
        {
            for(int b = 0; b < result_size; b++)
            {
                general_result_list[b].text_result;

                ptr += 2;
            }
        }
        break;
    }

    //没有在节点添加连接的环节

}

// 被动记录属性
struct Passive_Link_Attribute
{
    char kind_is_passive = 10;
    char link_attribute_kind;
    char b;
    char c;
    unsigned int target_id;
};
// 2*4字节，神经元架构

//
void passive_link_put(Passive_Link_Attribute passive_link_attritube, vector<int>& target_list)
{
    target_list.resize(2);
    int* ptr = target_list.data();
    *((char*)ptr) = passive_link_attritube.kind_is_passive;
    *((char*)ptr + 1) = passive_link_attritube.link_attribute_kind;
    *(ptr + 1) = passive_link_attritube.target_id;
}


// 神经元改写任务队列
unordered_set<unsigned int> waiting_modify_neuro_search;
deque<unsigned int> waiting_modify_neuro;
deque<vector<int>> waiting_modify_context;

// 待写队列加载函数，未完成
void modify_neuro_queue_load(unsigned int target, vector<int> context)
{
    if (waiting_modify_neuro_search.count(target) == 1)
    {
        // 已有任务下
        // 没写好
        // 怎么增加任务
    } else {
        // 未有任务
        waiting_modify_neuro.push_back(target);
        waiting_modify_context.push_back(context);
        waiting_modify_neuro_search.insert(target);
    }
}

// 神经元新建函数，返回新建节点id
unsigned int neuro_create(char neuro_kind,// 1 2 3
    char detail_kind = 0)
{
    unsigned int node_id;

    if (FREE_ID_NUM > 0)
    {
        FREE_ID_NUM--;
        node_id = FREE_ID_LIST.back();
        FREE_ID_LIST.pop_back();
    }
    else
    {
        // 查找此时的最新未使用节点
        node_id = NEWIST_USEFUL_ID;
        NEWIST_USEFUL_ID += 1;
    }

    uint32_t idx = pack_position_insert(node_id, 1); // 新插一个包

    // 填写神经元头
    Neuro_Head_Attribute neuro_head;
    neuro_head.neuro_kind = neuro_kind;

    unsigned int *ptr = Neuro_Pack_Storage[idx].attribute_item;
    *(Neuro_Head_Attribute*)ptr = neuro_head;

    // 描述类型填入
    ptr += 1;
    if(neuro_kind == 1)
    {
        Image_Neuro_Desc desc;
        desc.detail_kind = detail_kind;
        *(Image_Neuro_Desc*)ptr = desc;
        
    } else if(neuro_kind == 2) {
        
        Text_Neuro_Desc desc;
        desc.detail_kind = detail_kind;
        *(Text_Neuro_Desc*)ptr = desc;

    } else if(neuro_kind == 3) {
        
        Concept_Neuro_Desc desc;
        *(Concept_Neuro_Desc*)ptr = desc;
    }

    return node_id;
} // 函数结束

// 神经元删除函数，未完成
void neuro_delete(unsigned int node_id)
{
    // 擦除所有被动链接与上级节点、下级节点连接，未完成

    FREE_ID_NUM++;
    FREE_ID_LIST.push_back(node_id);
}

// 神经元扩容函数
char neuro_size_up(unsigned int target_id, unsigned char level)
{
    //但是怎么去确定是否扩容
    //毕竟小于4级时扩容不消耗存储空间

    uint32_t ori_idx;

    if (Pack_Vector_Index_Find.count(target_id) != 0)
        ori_idx = Pack_Vector_Index_Find[target_id];
    else
        return -1;

    char curr_pack_size = Neuro_Pack_Record_Storage[ori_idx].pack_size;
    char more_pack_size = level - curr_pack_size;

    if (more_pack_size < 0)
        return -2;

    //提供空位
    uint32_t new_idx = pack_position_insert(target_id, level);

    //转移内容
    for(int a = 0; a < curr_pack_size; a++)
    {
        Neuro_Pack_Storage[new_idx + a] = Neuro_Pack_Storage[ori_idx + a];
        Neuro_Pack_Record_Storage[new_idx + a] = Neuro_Pack_Record_Storage[ori_idx + a];
    }

    // 改头部数据
    char *head_ptr = (char *)Neuro_Pack_Storage[new_idx].attribute_item;
    head_ptr++;
    *head_ptr = level;
    head_ptr++;
    *(short *)head_ptr += more_pack_size * 256;

    return 1;
}

// 神经元条目删除函数，未完成，被动连接未删除，属性描述未填改
char neuro_item_delete(unsigned int target,
    unsigned short item_order, unsigned char item_num)
{
    // 查找节点位置
    uint32_t vec_pos = pack_index_find(target);

    if (vec_pos == -1)
        return 0;

    unsigned int* ptr = Neuro_Pack_Storage[vec_pos].attribute_item;

    if (ptr == 0) // 未载入包，查找失败
        return -1;

    char* pack_state = &Neuro_Pack_Record_Storage[vec_pos].pack_state;

    unsigned char pack_size = Neuro_Pack_Record_Storage[vec_pos].pack_size;
    unsigned short used_item_num = *((unsigned short *)(ptr) + 1);

    if (item_order > used_item_num) // 填位置错，不应该
        return -2;

    if (*pack_state != 2)
        return -3;

    *pack_state = 5;

    // 修改原描述，更新头部数据
    *((unsigned short *)(ptr) + 1) -= item_num;

    unsigned int *delete_ptr = ptr;
    ptr += item_num;

    // 覆盖指定内容
    for (unsigned short curr_item = item_order + item_num; curr_item <= used_item_num; curr_item++)
    {
        *delete_ptr = *ptr;

        delete_ptr += 1;
        ptr += 1;
    }

    *pack_state = 2;

    return 1;
}

// 神经元属性添加函数，没有改描述信息
char neuro_attribute_write(
    unsigned int target_ID, vector<int> item_context,
    unsigned short position, bool add_or_insert ) // 中间插入0，末尾添入1
{
    // 查找节点位置
    unsigned int* ptr = node_find(target_ID);

    if (ptr == 0)
    { // 查找失败，因为没有载入包
        // 加载包
        add_to_Will_Read_Neuro_Queue(target_ID);

        // 加入神经元填写任务队列
        modify_neuro_queue_load(target_ID, item_context);
        return 0;
    }

    unsigned int *first_ptr = ptr;
    char *pack_state = ((char *)(first_ptr - 15) + 1);

    if (*pack_state != 2)
        return 0;

    *pack_state = 4;
    char pack_size = *((char *)(first_ptr) + 1);
    unsigned short used_item_num = *((short *)(first_ptr) + 1);

    int item_context_size = item_context.size();

    // 1、可写空址搜寻
    if ((pack_size * 256 - 16 - used_item_num) > item_context_size)
    {
        // 不通过，空间不足
        // 加入神经元填写任务队列
        vector<int> context; // 待
        modify_neuro_queue_load(target_ID, context);
        return 0;
    }

    // 2、录入属性信息
    *((short *)first_ptr + 1) += item_context_size;

    char curr_pack_order = 0;

    unsigned short curr_order;

    bool have_more_pack = 0;

    if (pack_size > 1)
        have_more_pack = 1;
    

    // 3、正式录入
    if (add_or_insert == 1)
    {
        // 追加条目

        // 找到读写位置
        ptr += used_item_num;

        // 开始追加
        for (int single_item : item_context)
        {
            // 不连续包，连续性侦测
            *ptr = single_item;
        }

    } else if (add_or_insert == 2) {

        // 挪移条目

        char pack_size = *((char *)first_ptr + 1);
        unsigned short used_item_num = *((short *)first_ptr + 1);

        int insert_pos = position;

        // 开始挪移
        unsigned int *write_ptr;
        unsigned int *end_ptr;
        int middle_item_num = used_item_num - insert_pos;

        // 挪移条目
        if (have_more_pack == 0)
        {
            // 找到位置
            write_ptr = first_ptr + used_item_num;
            end_ptr = first_ptr + used_item_num + item_context_size;

            for (int q = 0; q < middle_item_num; q++)
            {
                *end_ptr = *write_ptr;
                end_ptr--;
                write_ptr--;
            }
        }

        // 4、写入条目
        ptr = first_ptr + insert_pos;

        for (int single_item : item_context)
        {
            *ptr = single_item;
            ptr++;
        }

    }

    // 录入完成
    *pack_state = 2;

    return 1;
}

// 整合神经元属性添加函数
void simple_neuro_attribute_write(unsigned int target_id, 
    unsigned short position, bool add_or_insert,// 中间插入0，末尾添入1
    Attribute_Head attribute_head, 
    vector<General_Condition>& general_condition_list, vector<General_Result>& general_result_list)
{
    vector<int> add_item;
    vector<int> passive_item;

    Passive_Link_Attribute passive_link_attribute;
    passive_link_attribute.link_attribute_kind = attribute_head.attribute_kind;
    passive_link_attribute.target_id = target_id;

    general_attribute_put(attribute_head, add_item, general_condition_list, general_result_list);
    passive_link_put(passive_link_attribute, passive_item);

    neuro_attribute_write(target_id, add_item, 0, 1);
    neuro_attribute_write(general_result_list[0].image_result.related_id, passive_item, 0, 1);
}


// 图像相关

// rgb像素值
struct RGB_Unit
{
    unsigned char r, g, b;
};

// 二维点
struct point_2d
{
    unsigned short x, y;
};

struct Point_2d_Equal
{
    bool operator()(const point_2d &a, const point_2d &b) const
    {
        return a.x == b.x && a.y == b.y;
    }
};

struct Point_2d_Hash
{
    size_t operator()(const point_2d &p) const
    {
        return hash<int>()(p.x) ^ (hash<int>()(p.y) << 1);
    }
};

inline bool point_less(const point_2d &a, const point_2d &b)
{
    if (a.x != b.x)
        return a.x < b.x;
    return a.y < b.y;
}

// 节点作用属性
struct un_int_of_4_blank
{
    uint32_t blank[4] = {0, 0, 0, 0};
};

struct un_int_of_6_blank
{
    uint32_t blank[6] = {0, 0, 0, 0, 0, 0};
};

struct VectorUint32_tHash
{
    size_t operator()(const vector<uint32_t> &v) const noexcept
    {
        uint64_t h = 1469598103934665603ULL; // FNV-1a offset

        for (uint32_t x : v)
        {
            uint64_t z = static_cast<uint64_t>(x);
            h ^= z;
            h *= 1099511628211ULL; // FNV prime
        }

        return static_cast<size_t>(h);
    }
};

struct VectorUint32_tEq
{
    bool operator()(const vector<uint32_t> &a,
        const vector<uint32_t> &b) const noexcept
    {
        return a == b; // 实现逐元素比较
    }
};




// 现象相关 统计 模拟 因果


// 节点特性
struct Node_Image_Attribute
{
    char curr_is_use = 1;
    char kind_is_self_attribute = 1;
    char kind_is_Node_Image_Attribute = 1;
    char standard_size; // 视角大小

    unsigned short x, y; // 图中定位点位置

    int block_num = 0;  // 占据格数
    int contain_distance = 0; // 内部包含的距离总和
};

struct Node_Text_Attribute
{
    char curr_is_use = 1;
    char kind_is_self_attribute = 1;
    char kind_is_Node_Text_Attribute = 2;

    uint32_t index_position = 0;
    int block_num = 0;
};

struct Node_Time_Attribute
{
    char curr_is_use = 1;
    char kind_is_self_attribute = 1;
    char kind_is_Node_Time_Attribute = 3;

    int self_time_front = 0; // 由long long切分而来的时间
    int self_time_back = 0; // 等同于模型时间上的位置

    int node_num = 0;
};

struct Node_Probability_Attribute
{
    char curr_is_use = 1;
    char kind_is_self_attribute = 1;
    char kind_is_Node_Probability_Attribute = 3;

    int base_value = 0;
    int actual_value = 0;
};


struct Node_Number_Attribute
{
    char curr_is_use = 1;
    char kind_is_self_attribute = 1;
    char kind_is_Node_Number_Attribute = 5;

    int number = 0;
};

struct Node_Motion_Attribute
{
    char curr_is_use = 1;
    char kind_is_self_attribute = 1;
    char kind_is_Node_Motion_Attribute = 6;
    char non;

    char action_order; // 行动顺序
    char action_kind; // 行动类型，鼠标1，键盘2，文本传回3，文本显示4，窗口隐藏5，窗口显示6
    unsigned char vk; // 键盘可选，键码
    char mouseData; // 鼠标可选，滚轮 1格 = 120

    short x, y; // 鼠标可选，自身坐标
    
    unsigned int dwFlags; // 通用，行为标志
};



// 链接属性
struct Link_Object_Attribute
{
    char Link_Attribute = 2; // 节点链接2、所属场域3、意图节点4
    char Link_Kind = 0; /* 下源1 上成2 原因3 结果4 抑制5 无需6 数目统计上7 数目统计下8 
        存在0* 不存在1* 行动性2*(下行动21 上行动22 前行动23 后行动24) 主动连接0** 被动连接1** */
    uint32_t Link_Idx; // 节点下标
    float Link_Value = 1; // 属性值，因果概率
};

union Flexible_Object
{
    // 自身属性
    Node_Image_Attribute node_image_attribute;
    Node_Time_Attribute node_time_attribute;
    Node_Text_Attribute node_text_attribute;
    Node_Probability_Attribute node_probability_attribute;
    Node_Number_Attribute node_number_attribute;
    Node_Motion_Attribute node_motion_attribute;

    // 链接属性
    Link_Object_Attribute link_attribute;

    // 模拟需求
    Image_Item simulate_image_require;
    Time_Item simulate_time_require;
    Text_Item simulate_text_require;
};


// 通用认知节点
struct General_Cognition_Node
{
    //
    // 固定属性区
    bool is_use = 1;
    char now_occupy = 0;
    char node_kind; // 现实0 模拟1，不存在(未生成)3，不需要4，数量统计5，检索1*，新生2*
    char self_from; // 图象1，文本2，时间线3，行动后果4(可变概率)，概念？

    char exclusive_attritube_num; // 拓展属性数量
    unsigned char node_layer;
    unsigned char rough_free_item_size;// 大致剩余的空余空间 (原值/8)-2
    char node_calu_state = 1; // 运算的辅助量
    char stability_num;

    int node_attention = 0; // 注意力值
    unsigned int self_id = 0;

    int component = 0; // 运算的辅助量

    float complete = 1; // 完整度
    float probability = 1; // 存在概率
    float predict_stability = 0;

    // 自身需求
    int recognize_require = 0; // 识别需求 不清楚度
    int model_require = 0; // 建模需求 理解出现逻辑 预测 或 规划 主动创造知识
    int identify_require = 0; // 对应化需求


    //
    // 链接区
    vector<Flexible_Object> object_list;
};


// 关注对象，生成时检索
struct Focus_Object
{
    char focus_kind; // 关注1 需求2 需求汇总3 匹配4 无需5 抑制6
    uint32_t focus_idx;
};

// 后统计结果待记录入神经元
struct Wait_Added_Neuro
{
    //在每次检索目标神经元时，检查有无后续追加的统计数量，若有，直接加上
    char is_use = 1;
    char operation;
    
    unsigned int target_id;

    unsigned int record_id; // 定位要增加统计数量的条目
    unsigned char item;
};

// 待激活神经元
struct Wait_Active_Neuro
{
    char curr_is_use = 1;
    unsigned int id;
};

// 注意对象
struct Attention_Object
{
    char curr_use = 1;
    char id_or_idx_kind = 0;

    int value = 0;
    unsigned int id_and_idx = 0; // 

    // 反馈对象，一般是一些需求与填写的任务
    vector<uint32_t> feedback_object;

    // int contradiction_value;// 矛盾，因果统计，落后架构？
    // int duration_time;
    // long long expect_time;
};



// 需求对象
struct Require_Object
{
    char require_kind; // retrieve检索1 model建模2
    int require_value = 0;
    unsigned int require_id;
};

// 节点匹配生成
struct Generate_Match
{
    char attritube_kind;

    char need_condition_num;
    char not_condition_num;
    char node_num;

    unsigned int every_condition[5] = {0, 0, 0, 0, 0};
    uint32_t every_node_from[5];

    unsigned int infer_result_id;
};

// 要求无
struct UnNeed_Have
{
    char kind;         // 节点 匹配
    uint32_t node_idx; // 所支撑节点
};

// 聚合抑制，大概转到注意力与需求抑制
struct Restrain_Concept
{
    char source_num;
    unsigned int causal_restrain_source[5];
    vector<uint32_t> effect_idx;
};

// 因果抑制，因果统计时使用
struct Casual_Restrain
{
    uint32_t Restrain_Source;
    unsigned int Restrain_Target;

    float Restrain_Rate;
};


// 区域属性存储
struct Scene_Image_Attribute
{
    char curr_is_use = 1;
    char Self_Scene_Attribute_Is_Image = 1;

    unsigned short left, right, bottom, top;
};

struct Scene_Text_Attribute
{
    char curr_is_use = 1;
    char Self_Scene_Attribute_Is_Text = 2;

    unsigned short left, right;
};

struct Scene_Time_Attribute
{
    char curr_is_use = 1;
    char Self_Scene_Attribute_Is_Time = 3;
    
    int begin_time_front;
    int begin_time_end;

    int durable_over_time; // 占据的时间
};

struct Scene_Probability_Attribute
{
    char curr_is_use = 1;
    char Self_Scene_Attribute_Is_Probability = 4;

    char kind; // source1 next2
    unsigned short current_scene_layer;
    float probability; // source1 next2 self3
    uint32_t station_idx;
};

struct Scene_Motion_Attribute
{
    char curr_is_use = 1;
    char Self_Scene_Attribute_Is_Motion = 5;

    uint32_t curr_motion_idx;
};

//

// 链接场景属性
struct Related_Scene
{
    char kind;                  // 连接域1 目标相关1*
    unsigned char Related_Kind; // 图像1 文本2 心理3 界面4 现实1* 混杂2* 想象3* 组成1** 分解2**
    uint32_t Scene_Idx;
    float Related_Value;
};

//
union Scene_Object
{
    Scene_Image_Attribute scene_image_attribute;
    Scene_Text_Attribute scene_text_attribute;
    Scene_Time_Attribute scene_time_attribute;
    Scene_Probability_Attribute scene_probability_attribute;
    Scene_Motion_Attribute scene_motion_attribute;

    Related_Scene relative_Scene;
};

// 通用认知场景 (概率统计网络 概率统计区 概率模拟网络 概率模拟区）
struct General_Cognition_Scene
{
    bool curr_use = 1;
    char scene_kind; // 图像1 文本2 心理(通用)3 界面4 现实1* 混杂2* 想象3*

    // 内部事件存储
    vector<uint32_t> all_have_node_idx_list;
    unordered_map<unsigned int, vector<uint32_t>> id_find_node_idx; // id查找存储下标

    vector<uint32_t> number_record_node_list; // 数量统计节点，不算真实的节点
    unordered_map<unsigned int, uint32_t> id_number_record_node; // 统计同一id的数量

    // 相关场景属性
    vector<Related_Scene> Related_Scene_List;

    // 综合查找
    unordered_map<unsigned int, vector<Focus_Object>> Focus_Object_Check;

    vector<Generate_Match> Generate_Match_List; // 生成匹配
    vector<uint32_t> Free_Generate_Match_Idx;

    vector<Require_Object> Require_Object_List; // 目标需求
    vector<uint32_t> Free_Require_Object_Idx;

    // vector<UnNeed_Have> Un_Being_List; // 无性需求
    // vector<uint32_t> Free_Un_Being_List;

    // vector<Restrain_Concept> Restrain_LIst; // 生成抑制
    // vector<uint32_t> Free_Restrain_LIst;
};


// 模型输出行动
struct Model_Output_Action
{
    char action_order; // 行动顺序
    char action_kind; // 行动类型，1鼠标，2键盘，文本传回3，文本显示4，窗口隐藏5，窗口显示6
    unsigned char vk; // 键盘可选，键码
    char mouseData; // 鼠标可选，滚轮  *120/格

    short x, y; // 鼠标可选，坐标 精确偏移量 模糊偏移量
    
    unsigned int dwFlags; // 通用，行为标志
}; // windows版本键鼠输出，3*4字节


// 图像属性


// 线段实体
struct Line_Object
{
    char line_kind; // 边界 内部 复合 杂色
    unsigned char standard_size;

    char direction;                 // 方向
    unsigned char length;           // 长度
    unsigned char red, green, blue; // 色彩

    int attention_value = 0;

    int x_sum = 0;
    int y_sum = 0;

    int block_num;
    float reward_rate;
    int reward_value;

    float abs_diff_value;
    float sum_diff_value;
    float ave_diff_rate;

    point_2d middle_coordinate; // 中部位置
    point_2d base_point; // 起始位置
    
    vector<point_2d> Inside_Point; // ？-
};


// 图像覆盖解释区块
struct Image_Cover_Explain_Block
{
    char proc_stage = 0; // 点处理类型；未观测0，团块内点1，边界点2
    char diff_colour = 0b00000000; // 异值像素点的方向

    // 颜色相关
    unsigned char ave_r, ave_g, ave_b;

    unsigned char unexplain_line = 0; // 线段构造需求
    char have_node_num = 0;
    
    uint32_t have_node_idx[6];
};


// 空间覆盖解释网络
struct Image_Cover_Explain_Network
{
    char standard_size; // 尺寸 1 2 4 8
    char is_init = 0;

    unsigned short self_width, self_height; // 宽高

    //内部像素数统计
    vector<int> colour_number_distribution; // 8*8*8 = 512
    vector<int> colour_x_distribution; // 8*8*8 = 512
    vector<int> colour_y_distribution; // 8*8*8 = 512

    vector<Image_Cover_Explain_Block> Cover_Block_List;
};


// 空间覆盖概览网络
struct Image_Cover_Node_Network
{
    char record_distance = 4; // 4、8、16、32，4*4相当于16个像素

    vector< vector<uint32_t> > Image_Node_Idx_Record;
};


// 区块关注
struct Rigion_Value_Stat
{
    unsigned short height;           // 垂直单位数量
    unsigned short width;            // 水平单位数量
    unsigned short height_unit_size; // 垂直区域单位大小
    unsigned short width_unit_size;  // 水平区域单位大小

    vector<int> attention_unit_list;
};

//
struct Space_Attend_Attention
{
    char is_use = 1;
    char is_region = 1;
    unsigned short left, right, top, bottom;

    int attention_value = 0;
};

//
struct Colour_Attend_Attention
{
    char is_use = 1;
    char is_connect = 0;
    char is_colour = 1;

    unsigned char red_min;
    unsigned char red_max;

    unsigned char green_min;
    unsigned char green_max;

    unsigned char blue_min;
    unsigned char blue_max;

    int attention_vlaue = 0;
};

//
struct Target_Attend_Attention
{
    char is_use = 1;
    char is_connect = 0;

    unsigned int id;
    int attention_vlaue = 0;
};

//
union Attend_attention
{
    Space_Attend_Attention space_object;
    Colour_Attend_Attention colour_object;
    Target_Attend_Attention target_object;
};

// 图像匹配
struct Image_Match
{
    char generate_kind = 0; // 仅统计0 生成图像1 生成概念2
    char total_need = 0;
    char node_num;
    
    unsigned int result_generate_id; // 生成的结果，或者是统计的源头
    uint32_t node_idx_from_list[5];
    Image_Item need_condition_list[4];
};


// 完整图形分析
struct Map_Analysis_Scene
{
    char curr_use = 1;
    char is_init_recognize = 0; // 初始化
    char is_lock_occupy = 0;
    char model_output_action_num = 0;

    unsigned short width, height; // 宽高
    
    uint32_t last_map = 0;
    uint32_t next_map = 0;

    int attention = 0;
    int sum_nature_attention = 0;   // 总区域变化和继承

    int sum_retrieve_require = 0;
    int sum_model_space_require = 0;
    int sum_model_time_require = 0;
    int sum_construct_require = 0;

    float retrieve_add_rate = 1;
    float model_space_add_rate = 0.5;
    float model_time_add_rate = 0.5;
    float construct_add_rate = 0;

    int graph_node_num;

    // 来源时间
    long long input_time;

    Model_Output_Action current_output_action[5];

    // 原图
    vector<RGB_Unit> RGB_Map;

    // 自然注意力区域
    vector<Rigion_Value_Stat> Block_Attention_List; // 区块注意力 由像素点形成
    vector<Rigion_Value_Stat> Area_Attention_List;  // 区域注意力 更大 8倍汇总率
    
    vector< vector<int> > retrieve_require_list; // 区域需求 8倍汇总率
    vector< vector<int> > model_require_list; // 区域需求 8倍汇总率

    // 附加注意力
    vector<Attend_attention> append_attention;

    // 图像解释覆盖
    vector<Image_Cover_Explain_Network> Image_Cover_Explain_View;
    Image_Cover_Node_Network Image_Cover_Node_View;

    // 图像节点存储
    vector<uint32_t> Image_Node_List; // 当前场景 全体节点
    unordered_map<unsigned int, vector<uint32_t>> Id_Find_Index; // id查找图像节点下标

    vector<uint32_t> number_record_node_list; // 数量统计节点，不算真实的节点
    unordered_map<unsigned int, uint32_t> id_number_record_node; // 统计同一id的数量

    // 图像聚合去重
    unordered_set<vector<uint32_t>, VectorUint32_tHash, VectorUint32_tEq> image_combo_hash;

    // 图像聚合匹配
    vector<Image_Match> Image_Match_List;
    vector<uint32_t> Free_Image_Match_Index;
    unordered_map<unsigned int, vector<uint32_t>> Find_Image_Match;

    //图像需求匹配
    unordered_map<unsigned int, uint32_t> id_to_require;
    vector<Require_Object> require_object_list;

    // 相关场景属性
    vector<Related_Scene> Related_Scene_List;
};


// 文本相关


// 文本匹配
struct Text_Match
{
    char generate_kind = 0; // 仅统计0 生成文本1 生成概念2
    char need_condition_num = 0;
    char node_num;
    
    unsigned int infer_sustain_id; // 生成的结果，或者是统计的源头
    uint32_t node_idx_from_list[5];
    Image_Item need_condition_list[4];
};

// 字符推理上下行网络
struct Text_Inference_Scene
{
    char is_use = 1;
    char source_kind; // 1输入获取 2界面输入 3内部生成
    char have_init = 0;
    char Retrieval_Density = 8;    // 4、8、16

    char scene_layer = 0; // 模拟量
    char scene_order = 0; // 模拟量
    
    int text_derive_attention;

    int sum_retrieve_require = 0;
    int sum_model_require = 0;
    int sum_identify_require = 0;
    int sum_construct_require = 0;

    float retrieve_add_rate = 1;
    float model_add_rate = 0.5;
    float construct_add_rate = 0;

    long long input_time; // 来源时间

    vector<uint32_t> original_text_list; // 字符推理基层存储
    vector< vector<uint32_t> > text_infer_node_list; // 文本推理节点存储，每原文8格收拢为一个vector

    vector<uint32_t> number_record_node_list; // 数量统计节点，不算真实的节点
    unordered_map<unsigned int, uint32_t> id_number_record_node; // 统计同一id的数量

    vector<uint32_t> high_attention_list;  //
    vector<uint32_t> free_attention_idx;   //

    // 需求汇总侦测网络
    vector<vector<int>> retrieve_require; // 8 倍汇总率，一个vector<int>记录当前8个格的需求
    vector<vector<int>> model_require;    // 8 倍汇总率

    // 相关场景属性
    vector<Related_Scene> Relative_Scene_List;
};


// 文本界面显示
struct Gtk_Text_Display_Interface
{
    char use = 1;
    char response_kind; // 解释1 回答2 求知3 追求4 维持5 固化6

    char input_value_I_num = 0;
    char input_value_II_num = 0;
    char output_value_num = 0;

    int input_value_I[10];
    int input_value_II[10]; /*
    0-1、注意力
    1-1、外部追求偏好、外部满足程度、外部追求需求、内部理解需求、内部识别程度(清楚度)、群体推演性(合理性)、注意力
    2-1、
    3-1、
    4-1、
    5-1、外部追求偏好(好感度)、内部理解需求(求知欲)、注意力
    6-1、外部追求偏好、清楚度
    */
    
    int response_value[10]; /*
    1-1、外部追求偏好、清楚度、注意力
    2-1、
    3-1、
    4-1、
    5-1、
    6-1、
    */

    /*任务特性*/
    /*外部性 内部性*/
    /*一次性 持续性*/
    /*求解性 赋予性*/
    /*单象性 双象性*/
    /*主动性 被动性*/
    /*根本性 运行性*/

    uint32_t Purpose_Idx = 0;

    uint32_t Text_input_Inference_A_Idx = 0;
    uint32_t Text_input_Inference_B_Idx = 0;
    uint32_t Text_output_Inference_Idx = 0;

    vector<char> input_string_A;
    vector<char> input_string_B;
    vector<char> response_string;
};



//意图相关
struct Purpose_Related
{
    char curr_use = 1; // 已完成0
    char purpose_kind; // 需求节点1 相关意图2 场景3
    char position_kind; // 来源1  下属2  上一个3  下一个4

    char Require_kind; // recognize1 foresee2 identify3 comprehend4 construct5 infer6 pursue7
    // 图像1 文本2 心理3 界面4 现实1* 混杂2* 想象模拟3*
    
    int Require_value = 0;
    unsigned int Require_object = 0; // id1 purpose_idx2 scene3
};


//通用意图
struct General_Purpose
{
    bool curr_is_use = 1;
    bool constant = 0;
    char purpose_layer = 0; // 这个越中心的目标越下面
    char purpose_order = 0; // 

    int attention = 0;

    // int desire_sum = 0;

    vector<Purpose_Related> purpose_related_list;
};


/*模型的准则

    <1> 尽可能地认知当前世界，低消耗地、准确地、全面地
    <2> 在1的基础上，执行界面输入的内容，并且运行流畅稳定自洽

*/


//
struct Feel_Emotion
{
    int value; // 未处理度、不清楚度/好奇度  内部达成度、外部达成度/需求度 评估Appraisse
    uint32_t self_source;
    int duration;
};


// 反馈 奖励
struct Feedback_Reward
{
    bool is_use = 1;
    int joy_value;               // 奖励
    float independent_attention; // 情绪注意力
    int duration;                // 持续时间
};

//感知 归因 反馈

// 线程核调度
struct Single_Thread
{
    char now_normal = 1;
    short need_free_time = 0;

    int future_invest = 0; // 投入任务
    vector<uint32_t> task; // 任务

    //线程反馈任务提醒
};


/*
 *
 *核心共享区
 *
 */


// 线程管理
int Base_Thread_Num = 4;
int Calculate_Thread_Num = 0;
int Use_Thread_Num = Base_Thread_Num + Calculate_Thread_Num;
vector<Single_Thread> Thread_Handle_List;
float Thread_Limit_Free_Rate = 0.3; // 线程闲置度，防cpu过热

// 收发处理
vector<Model_Output_Action> Watting_Action_List; // 待发送行动
atomic<char> Send_Action_Number(0);

vector<char> Send_Text_List; // 待发送文本
atomic<bool> Text_Is_Send(0);

vector<char> Receive_Text_List; // 接受文本


// 关注相关
int Total_Task_Attention = 100 * Calculate_Thread_Num;
int Free_Total_Task_Attention = Total_Task_Attention;

unordered_map< unsigned int, vector<uint32_t> > Find_Total_Focus_Object;
vector<Focus_Object> Total_Focus_Object_List; // 检查生成的单元
vector<uint32_t> Free_Focus_Object_Index; // 空下标

vector<Attention_Object> Attention_Object_List; // 关注、忽略的注意力对象
vector<uint32_t> Free_Attention_Object_Index;

vector<Require_Object> Require_Object_List; // 对象需求
vector<uint32_t> Free_Require_Object_Idx;

vector<UnNeed_Have> UnNeed_List; // 无性需求
vector<uint32_t> Free_UnNeed_Idx;

vector<Restrain_Concept> Restrain_List; // 生成抑制
vector<uint32_t> Free_Restrain_Idx;

vector<Generate_Match> Generate_Match_List; // 生成匹配
vector<uint32_t> Free_Generate_Match_Idx;

vector<Wait_Added_Neuro> Wait_Added_Record_List; // 待追加记录
vector<uint32_t> Free_Wait_Added_Record_Idx;


// 当下关注
int current_attention = 100;
int free_attention = 0;
vector<Attention_Object> Current_Attention_Object_List; // 注意力对象
vector<uint32_t> Free_Current_Attention_Object_Index;

unordered_map<unsigned int, uint32_t> node_summary; // 统合的注意力与全体数量

// 需求相关
int Retrieve_Desire; // 识别的相关需求
float Retrieve_Preference;
int UnRetrieve = 0; // 检索需求决定 未识别性
int UnRetrieve_Expect;

int Model_Desire; // 理解 出现逻辑 的需求
float Model_Preference;
int UnModel = 0; // 建模需求决定 未理解性
int UnModel_Expect;

int Construct_Desire; // 预测 或 规划 主动创造知识 的需求
float Construct_Preference;
int UnConstruct = 0; // 行动需求决定 未满足性
int UnConstruct_Expect;

// 目标相关
vector<General_Purpose> General_Purpose_Focus_List;
vector<uint32_t> Free_General_Purpose_Focus_Idx;
int General_Purpose_Num = 0;

vector<Related_Scene> All_Process_Object;
vector<int> All_Dealing_Require;


// 行动相关
vector<Model_Output_Action> action_choose_list; // 行动列表，在外部环境中实现
vector<int> action_choose_weights;

vector<External_Action_Item> action_item_storage; // 节点行动属性存储
vector<uint32_t> free_action_item_idx;

unsigned short Current_X = 0;
unsigned short Current_Y = 0;
bool Current_Interface_Show = 1;
bool Current_Interface_Text_Have = 0;
bool Current_Text_Show = 0;


// 奖励相关
vector<Feedback_Reward> provide_emotion; // 宜100~200
vector<uint32_t> free_emotion_list; // 空情绪位置回收

int Current_Joy = 0;
int Approach_Joy = 0;
int Satisfy_Standard = 0000;


// 图像存储
vector<Map_Analysis_Scene> Map_Analysis_Scene_Storage;
vector<uint32_t> Free_Map_Analysis_Index;
vector<uint32_t> New_Map_Analysis_Index;
atomic<int> Map_Analysis_Num = 0;
unordered_map<long long, uint32_t> Time_To_Map_Search;
uint32_t newist_map_idx = 0;

// 文本存储
vector<Text_Inference_Scene> Text_Inference_Scene_Storage;
vector<uint32_t> Free_Text_Inference_Index;
vector<uint32_t> New_Text_Inference_Index;
atomic<int> Text_Inference_Num = 0;
unordered_map<long long, uint32_t> Search_Text_Inference;

vector<Gtk_Text_Display_Interface> gtk3_text_display; // 文本界面显示

// 心理存储
vector<General_Cognition_Node> General_Cognition_Node_Storage; // 内部概念
vector< atomic<char> > General_Cognition_Node_Occupy;
atomic<int> General_Cognition_Node_Storage_Occupy(0);
atomic<long long> Mental_Cognition_Node_Num;
unordered_map<unsigned int, vector<uint32_t>> Search_General_Cognition_Node;
vector<uint32_t> Free_General_Cognition_Node_Index;

// 场景存储
vector<General_Cognition_Scene> General_Cognition_Scene_Storage; // 通用区存储
vector< atomic<char> > General_Cognition_Scene_Occupy;
vector<uint32_t> Free_General_Cognition_Scene_Index;
atomic<int> General_Cognition_Scene_Num = 0;

// 时间-场景查找
unordered_map<long long, uint32_t> Search_Time_Scene;
vector<uint32_t> Time_Scene_STorage;
atomic<uint32_t> oldest_time_scene = 0;

// 预测 关注 反馈
deque< vector<uint32_t> > Fixed_Event_Predict_List; // Attention_Object下标

vector<uint32_t> Total_Event_Predict_List; // Attention_Object下标
vector<uint32_t> Free_Event_Predict_Idx;


/*
 *
 * fin
 *
 */



//对多线程使用方案，绝大部分都没写完


uint32_t create_a_General_Cognition_Node()
{
    uint32_t idx;

    if (Free_General_Cognition_Node_Index.size() > 0)
    {
        idx = Free_General_Cognition_Node_Index.back();
        Free_General_Cognition_Node_Index.pop_back();

    } else {
        General_Cognition_Node new_thing;
        idx = General_Cognition_Node_Storage.size();
        General_Cognition_Node_Storage.push_back(new_thing);
    }

    Mental_Cognition_Node_Num++;

    return idx;
}

void release_a_General_Cognition_Node(uint32_t idx)
{
    General_Cognition_Node& the = General_Cognition_Node_Storage[idx];
    the.is_use = 0;
    Free_General_Cognition_Node_Index.push_back(idx);

    Mental_Cognition_Node_Num--;
}


General_Cognition_Node read_a_General_Cognition_Node(uint32_t idx)
{
    General_Cognition_Node return_node;

    return return_node;
}

void write_a_General_Cognition_Node(uint32_t node_idx, General_Cognition_Node write_context)
{
    ;
}

//
void push_back_a_flexible_object_to_General_Cognition_Node(uint32_t node_idx, Flexible_Object flexible_object)
{
    char expect = 0;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 1, memory_order_seq_cst) )
        expect = 0;

    General_Cognition_Node_Storage[node_idx].object_list.push_back(flexible_object);

    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 1, memory_order_seq_cst) )
        expect = 0;
}



// 节点属性获取
//图像属性
void create_a_Node_Image_Attribute(uint32_t node_idx)
{
    //创建节点属性
    General_Cognition_Node& curr_node = General_Cognition_Node_Storage[node_idx];
    Node_Image_Attribute attribute;
    Flexible_Object fo = {.node_image_attribute = attribute};
    curr_node.object_list.push_back(fo);
}

void release_a_Node_Image_Attribute(uint32_t node_idx)
{
    //删除节点属性
    General_Cognition_Node the_node = General_Cognition_Node_Storage[node_idx];
    vector<Flexible_Object>& link_object_list = the_node.object_list;
    int object_size = link_object_list.size();

    Node_Image_Attribute attribute;

    for (int q = 0; q < object_size; q++)
    {
        if (link_object_list[q].node_image_attribute.kind_is_self_attribute == 1)
        {
            if (link_object_list[q].node_image_attribute.kind_is_Node_Image_Attribute == 1)
            {
                link_object_list[q].node_image_attribute.curr_is_use = 0;
                break;
            }
        }
    }

}

Node_Image_Attribute read_a_Node_Image_Attribute(uint32_t node_idx)
{
    //读取节点属性
    General_Cognition_Node the_node = General_Cognition_Node_Storage[node_idx];
    vector<Flexible_Object>& link_object_list = the_node.object_list;
    int object_size = link_object_list.size();

    Node_Image_Attribute attribute;

    for (int q = 0; q < object_size; q++)
    {
        if (link_object_list[q].node_image_attribute.kind_is_self_attribute == 1)
        {
            if (link_object_list[q].node_image_attribute.kind_is_Node_Image_Attribute == 1)
            {
                attribute = link_object_list[q].node_image_attribute;
                break;
            }
        }
    }

    return attribute;
}

void write_a_Node_Image_Attribute(uint32_t node_idx, Node_Image_Attribute write_attribute)
{
    //填写节点属性
    General_Cognition_Node the_node = General_Cognition_Node_Storage[node_idx];
    vector<Flexible_Object>& link_object_list = the_node.object_list;
    int object_size = link_object_list.size();

    for (int q = 0; q < object_size; q++)
    {
        if (link_object_list[q].node_image_attribute.kind_is_self_attribute == 1)
        {
            if (link_object_list[q].node_image_attribute.kind_is_Node_Image_Attribute == 1)
            {
                link_object_list[q].node_image_attribute = write_attribute;
                break;
            }
        }
    }
    
    //此时无该属性，生成一个
    create_a_Node_Image_Attribute(node_idx);
    //重填写
    write_a_Node_Image_Attribute(node_idx, write_attribute);
}


//字符属性
void create_a_Node_Text_Attribute(uint32_t node_idx)
{
    //创建节点属性
    General_Cognition_Node& curr_node = General_Cognition_Node_Storage[node_idx];
    Node_Text_Attribute attribute;
    Flexible_Object fo = {.node_text_attribute = attribute};
    curr_node.object_list.push_back(fo);
}


void release_a_Node_Text_Attribute(uint32_t node_idx)
{
    //删除节点属性
    General_Cognition_Node the_node = General_Cognition_Node_Storage[node_idx];
    vector<Flexible_Object>& link_object_list = the_node.object_list;
    int object_size = link_object_list.size();


    for (int q = 0; q < object_size; q++)
    {
        if (link_object_list[q].node_text_attribute.kind_is_self_attribute == 1)
        {
            if (link_object_list[q].node_text_attribute.kind_is_Node_Text_Attribute == 2)
            {
                link_object_list[q].node_text_attribute.curr_is_use = 0;
                break;
            }
        }
    }

}

Node_Text_Attribute read_a_Node_Text_Attribute(uint32_t node_idx)
{
    General_Cognition_Node &the_node = General_Cognition_Node_Storage[node_idx];
    vector<Flexible_Object> &object_list = the_node.object_list;
    int object_size = object_list.size();

    Node_Text_Attribute attribute;
    
    for (int q = 0; q < object_size; q++)
    {
        if (object_list[q].node_text_attribute.kind_is_self_attribute == 1)
        {
            if (object_list[q].node_text_attribute.kind_is_Node_Text_Attribute == 2)
            {
                attribute = object_list[q].node_text_attribute;
                break;
            }
        }
    }

    return attribute;
}


void write_a_Node_Text_Attribute(uint32_t node_idx, Node_Text_Attribute write_attritube)
{
    //填写节点属性
    General_Cognition_Node the_node = General_Cognition_Node_Storage[node_idx];
    vector<Flexible_Object>& link_object_list = the_node.object_list;
    int object_size = link_object_list.size();

    for (int q = 0; q < object_size; q++)
    {
        if (link_object_list[q].node_text_attribute.kind_is_self_attribute == 1)
        {
            if (link_object_list[q].node_text_attribute.kind_is_Node_Text_Attribute == 2)
            {
                link_object_list[q].node_text_attribute = write_attritube;
                break;
            }
        }
    }
    
    //此时无该属性，生成一个
    create_a_Node_Text_Attribute(node_idx);
    //重填写
    write_a_Node_Text_Attribute(node_idx, write_attritube);
}


//时间属性
void create_a_Node_Time_Attribute(uint32_t node_idx)
{
    //创建节点属性
    General_Cognition_Node& curr_node = General_Cognition_Node_Storage[node_idx];
    Node_Time_Attribute attribute;
    Flexible_Object fo = {.node_time_attribute = attribute};
    curr_node.object_list.push_back(fo);
}


void release_a_Node_Time_Attribute(uint32_t node_idx)
{
    //删除节点属性
    General_Cognition_Node the_node = General_Cognition_Node_Storage[node_idx];
    vector<Flexible_Object>& link_object_list = the_node.object_list;
    int object_size = link_object_list.size();

    Node_Time_Attribute attribute;

    for (int q = 0; q < object_size; q++)
    {
        if (link_object_list[q].node_time_attribute.kind_is_self_attribute == 1)
        {
            if (link_object_list[q].node_time_attribute.kind_is_Node_Time_Attribute == 3)
            {
                link_object_list[q].node_time_attribute.curr_is_use = 0;
                break;
            }
        }
    }

}

Node_Time_Attribute read_a_Node_Time_Attribute(uint32_t node_idx)
{
    General_Cognition_Node &the_node = General_Cognition_Node_Storage[node_idx];
    vector<Flexible_Object> &object_list = the_node.object_list;
    int object_size = object_list.size();

    Node_Time_Attribute attribute;

    for (int q = 0; q < object_size; q++)
    {
        if (object_list[q].node_time_attribute.kind_is_self_attribute == 1)
        {
            if (object_list[q].node_time_attribute.kind_is_Node_Time_Attribute == 3)
            {
                attribute = object_list[q].node_time_attribute;
            }
        }
    }

    return attribute;

}


void write_a_Node_Time_Attribute(uint32_t node_idx, Node_Text_Attribute write_attritube)
{
    //填写节点属性
    General_Cognition_Node the_node = General_Cognition_Node_Storage[node_idx];
    vector<Flexible_Object>& link_object_list = the_node.object_list;
    int object_size = link_object_list.size();

    for (int q = 0; q < object_size; q++)
    {
        if (link_object_list[q].node_text_attribute.kind_is_self_attribute == 1)
        {
            if (link_object_list[q].node_text_attribute.kind_is_Node_Text_Attribute == 2)
            {
                link_object_list[q].node_text_attribute = write_attritube;
                break;
            }
        }
    }
    
    //此时无该属性，生成一个
    create_a_Node_Time_Attribute(node_idx);
    //重填写
    write_a_Node_Time_Attribute(node_idx, write_attritube);

    //这种write的形式不正确，最好以更新包的形式检查有无中途更新，原子加锁
}

//数量属性
void create_a_Node_Number_Attribute(uint32_t node_idx)
{
    //创建节点属性
    General_Cognition_Node& curr_node = General_Cognition_Node_Storage[node_idx];
    Node_Number_Attribute attribute;
    Flexible_Object fo = {.node_number_attribute = attribute};
    curr_node.object_list.push_back(fo);
}


void release_a_Node_Number_Attribute(uint32_t node_idx)
{
    //删除节点属性
    General_Cognition_Node the_node = General_Cognition_Node_Storage[node_idx];
    vector<Flexible_Object>& link_object_list = the_node.object_list;
    int object_size = link_object_list.size();

    Node_Number_Attribute attribute;

    for (int q = 0; q < object_size; q++)
    {
        if (link_object_list[q].node_number_attribute.kind_is_self_attribute == 1)
        {
            if (link_object_list[q].node_number_attribute.kind_is_Node_Number_Attribute == 3)
            {
                link_object_list[q].node_number_attribute.curr_is_use = 0;
                break;
            }
        }
    }

}

Node_Number_Attribute read_a_Node_Number_Attribute(uint32_t node_idx)
{
    General_Cognition_Node& the_node = General_Cognition_Node_Storage[node_idx];
    vector<Flexible_Object> & object_list = the_node.object_list;
    int object_size = object_list.size();

    Node_Number_Attribute attribute;

    for (int q = 0; q < object_size; q++)
    {
        if (object_list[q].node_number_attribute.kind_is_self_attribute == 1)
        {
            if (object_list[q].node_number_attribute.kind_is_Node_Number_Attribute == 3)
            {
                attribute = object_list[q].node_number_attribute;
            }
        }
    }

    return attribute;

}


void write_a_Node_Number_Attribute(uint32_t node_idx, Node_Number_Attribute write_attritube)
{
    //填写节点属性
    General_Cognition_Node the_node = General_Cognition_Node_Storage[node_idx];
    vector<Flexible_Object>& link_object_list = the_node.object_list;
    int object_size = link_object_list.size();

    for (int q = 0; q < object_size; q++)
    {
        if (link_object_list[q].node_number_attribute.kind_is_self_attribute == 1)
        {
            if (link_object_list[q].node_number_attribute.kind_is_Node_Number_Attribute == 5)
            {
                link_object_list[q].node_number_attribute = write_attritube;
                break;
            }
        }
    }
    
    //此时无该属性，生成一个
    create_a_Node_Number_Attribute(node_idx);
    //重填写
    write_a_Node_Number_Attribute(node_idx, write_attritube);
}

uint32_t create_a_Scene_Inside_Image_Match(vector<Image_Match> Image_Match_List,
    vector<uint32_t> Free_Image_Match_Index)
{
    uint32_t idx;

    if(!Free_Image_Match_Index.empty())
    {
        idx = Free_Image_Match_Index.back();
    } else {
        Image_Match image_match;
        idx = Image_Match_List.size();
        Image_Match_List.push_back(image_match);
    }

    return idx;
}

void release_a_Scene_Inside_Object()
{
    ;
}

//场景内的focus_object
void get_a_general_object(int example_number, vector<uint32_t> &storage_list, vector<uint32_t> &free_list)
{
    if (!free_list.empty())
    {
        storage_list[free_list.back()] = example_number;
        free_list.pop_back();
    
    } else {
        storage_list.push_back(example_number);
    }
}

void clear_a_general_object(uint32_t idx, vector<uint32_t> &free_list)
{
    free_list.push_back(idx);
}


// 生成检索
uint32_t get_a_Focus_Object(char object_kind, uint32_t object_idx, unsigned int object_id)
{
    uint32_t idx;
    if(Free_Focus_Object_Index.size() != 0)
    {
        idx = Free_Focus_Object_Index.back();
        Free_Focus_Object_Index.pop_back();

        Focus_Object fo;
        fo.focus_idx = object_idx;
        fo.focus_kind = object_kind;

        Total_Focus_Object_List[idx] = fo;

    } else {
        Focus_Object fo;
        fo.focus_idx = object_idx;
        fo.focus_kind = object_kind;

        idx = Total_Focus_Object_List.size();
        Total_Focus_Object_List.push_back(fo);
    }
    
    Find_Total_Focus_Object[object_id].push_back(idx);

    return idx;
}

void clear_a_Focus_Object(uint32_t idx, char kind, unsigned int object_id)
{
    vector<uint32_t>& Focus_Object_Idx_List = Find_Total_Focus_Object[object_id];

    uint32_t i;

    for(int a = 0; a < Focus_Object_Idx_List.size(); a++)
    {
        i = Focus_Object_Idx_List[a];
        Focus_Object fo = Total_Focus_Object_List[i];

        if(fo.focus_kind == kind && fo.focus_idx == idx)
        {
            Focus_Object_Idx_List.erase(Focus_Object_Idx_List.begin() + a);
        }

    }

    Free_Focus_Object_Index.push_back(i);
}


//注意对象
uint32_t get_a_Attention_Object()
{
    uint32_t idx;
    if(Free_Attention_Object_Index.size() != 0)
    {
        idx = Free_Attention_Object_Index.back();
        Free_Attention_Object_Index.pop_back();
    } else {
        idx = Attention_Object_List.size();
        Attention_Object ao;
        Attention_Object_List.push_back(ao);
    }
    
    return idx;
}

void clear_a_Attention_Object(uint32_t idx)
{
    Attention_Object_List[idx].curr_use = 0;
    Free_Attention_Object_Index.push_back(idx);
}

// 需求对象
uint32_t get_a_Require_Object()
{
    uint32_t idx;
    if(Free_Require_Object_Idx.size() != 0)
    {
        idx = Free_Require_Object_Idx.back();
        Free_Require_Object_Idx.pop_back();

    } else {
        idx = Require_Object_List.size();
        Require_Object ro;
        Require_Object_List.push_back(ro);
    }
    
    return idx;
}

void clear_a_Require_Object(uint32_t idx)
{
    Free_Require_Object_Idx.push_back(idx);
}

// 节点匹配生成
uint32_t get_a_Generate_Match()
{
    uint32_t idx;
    if(Free_Generate_Match_Idx.size() != 0)
    {
        idx = Free_Generate_Match_Idx.back();
        Free_Generate_Match_Idx.pop_back();

    } else {
        idx = Generate_Match_List.size();
        Generate_Match rm;
        Generate_Match_List.push_back(rm);
    }
    
    return idx;
}

void clear_a_Generate_Match(uint32_t idx)
{
    Free_Generate_Match_Idx.push_back(idx);
}

// 要求无
uint32_t get_a_UnNeed_Have()
{
    uint32_t idx;
    if(Free_UnNeed_Idx.size() != 0)
    {
        idx = Free_UnNeed_Idx.back();
        Free_UnNeed_Idx.pop_back();

    } else {
        idx = UnNeed_List.size();
        UnNeed_Have uh;
        UnNeed_List.push_back(uh);
    }
    
    return idx;
}

void clear_a_UnNeed_Have(uint32_t idx)
{
    Free_UnNeed_Idx.push_back(idx);
}

// 聚合抑制
uint32_t get_a_Restrain_Concept()
{
    uint32_t idx;
    if(Free_Restrain_Idx.size() != 0)
    {
        idx = Free_Restrain_Idx.back();
        Free_Restrain_Idx.pop_back();

    } else {
        idx = Restrain_List.size();
        Restrain_Concept rc;
        Restrain_List.push_back(rc);
    }
    
    return idx;
}

void clear_a_Restrain_Concept(uint32_t idx)
{
    Free_Restrain_Idx.push_back(idx);
}


uint32_t read_require_summary(unsigned int target)
{
    vector<uint32_t>& chose_list = Find_Total_Focus_Object[target];

    for(int a = 0; a < chose_list.size(); a++)
    {
        Focus_Object& fo = Total_Focus_Object_List[a];

        if(fo.focus_kind = 3)
            return fo.focus_idx;
    }
    
    return 0;
}

uint32_t create_a_General_Purpose()
{
    uint32_t idx;
    if(Free_General_Purpose_Focus_Idx.size() != 0)
    {
        idx = Free_General_Purpose_Focus_Idx.back();
        Free_General_Purpose_Focus_Idx.pop_back();

    } else {
        idx = General_Purpose_Focus_List.size();
        General_Purpose gp;
        General_Purpose_Focus_List.push_back(gp);
    }
    
    return idx;
}

void release_a_General_Purpose(uint32_t idx)
{
    Free_General_Purpose_Focus_Idx.push_back(idx);
}

Purpose_Related read_General_Purpose_need_id(General_Purpose& Curr_Purpose, int order)
{
    Purpose_Related purpose_related;
    
    return purpose_related;
}


//场景操作

uint32_t get_a_Map_Analysis()
{
    uint32_t idx;

    if (Free_Map_Analysis_Index.size() > 0)
    {
        idx = Free_Map_Analysis_Index.back();
        Free_Map_Analysis_Index.pop_back();
        
    } else {
        Map_Analysis_Scene new_map;
        idx = Map_Analysis_Scene_Storage.size();
        Map_Analysis_Scene_Storage.push_back(new_map);
    }

    Map_Analysis_Num++;

    return idx;
}

void clear_a_Map_Analysis(uint32_t idx)
{
    Map_Analysis_Scene_Storage[idx].curr_use = 0;
    Free_Map_Analysis_Index.push_back(idx);
    Map_Analysis_Num--;
    // clear;
    // reserve();
}

uint32_t get_a_Text_Inference()
{
    uint32_t idx;

    if (!Free_Text_Inference_Index.empty())
    {
        idx = Free_Text_Inference_Index.back();
        Free_Text_Inference_Index.pop_back();

    } else {
        Text_Inference_Scene hte;
        hte.input_time = CURRENT_MODEL_TIME;
        idx = Text_Inference_Scene_Storage.size();
        Text_Inference_Scene_Storage.push_back(hte);
    }

    Text_Inference_Num++;

    return idx;
}

void clear_a_Text_Inference(uint32_t idx)
{
    Text_Inference_Scene &the = Text_Inference_Scene_Storage[idx];
    the.is_use = 0;
    Free_Text_Inference_Index.push_back(idx);
    Text_Inference_Num--;
}

uint32_t get_a_gtk3_text_display()
{
    int i = 0;
    int s = gtk3_text_display.size();

    while (i < s)
    {
        if (gtk3_text_display[i].use == 0)
            break;

        i++;
    }

    if (i == s)
    {
        Gtk_Text_Display_Interface text_display;
        gtk3_text_display.push_back(text_display);
    }

    return i;
}

void clear_a_gtk3_text_display(uint32_t idx)
{
    gtk3_text_display[idx].use = 0;
}


uint32_t get_a_General_Cognition_Scene()
{
    uint32_t idx;

    if (Free_General_Cognition_Scene_Index.size() > 0)
    {
        idx = Free_General_Cognition_Scene_Index.back();
        Free_General_Cognition_Scene_Index.pop_back();

    } else {
        General_Cognition_Scene new_thing;
        idx = General_Cognition_Scene_Storage.size();
        General_Cognition_Scene_Storage.push_back(new_thing);
    }

    General_Cognition_Scene_Num++;

    return idx;
}

void clear_a_General_Cognition_Scene(uint32_t idx)
{
    General_Cognition_Scene &the = General_Cognition_Scene_Storage[idx];
    Free_General_Cognition_Scene_Index.push_back(idx);
    General_Cognition_Scene_Num--;
}

void push_back_a_node_to_General_Cognition_Scene(uint32_t scene_idx, uint32_t node_idx)
{
    char expect = 0;
    while( General_Cognition_Scene_Occupy[scene_idx].compare_exchange_strong(expect, 1, memory_order_seq_cst) )
        expect = 0;

    General_Cognition_Scene& scene = General_Cognition_Scene_Storage[scene_idx];
    scene.all_have_node_idx_list.push_back(node_idx);
    General_Cognition_Node& node = General_Cognition_Node_Storage[node_idx];
    scene.id_find_node_idx[node.self_id].push_back(node_idx);

    scene.id_number_record_node;
    scene.number_record_node_list;

    expect = 1;
    while( General_Cognition_Scene_Occupy[scene_idx].compare_exchange_strong(expect, 0, memory_order_seq_cst) )
        expect = 1;
}

void push_back_a_related_scene_to_General_Cognition_Scene(uint32_t scene_idx, Related_Scene push_related)
{
    char expect = 0;
    while( General_Cognition_Scene_Occupy[scene_idx].compare_exchange_strong(expect, 1, memory_order_seq_cst) )
        expect = 0;

    General_Cognition_Scene& scene = General_Cognition_Scene_Storage[scene_idx];
    scene.Related_Scene_List.push_back(push_related);

    expect = 1;
    while( General_Cognition_Scene_Occupy[scene_idx].compare_exchange_strong(expect, 0, memory_order_seq_cst) )
        expect = 1;
}

/*涓栫晫娣卞眰鏀垮簻缃伓婊斿ぉ銆佹伓璐弧鐩�*/

// 保存上一次的时间戳和steady_clock的参考点
static auto last_staedy_time = std::chrono::steady_clock::now();
static int32_t last_system_seconds = 0;

// 秒级时间获取函数
int get_current_second()
{
    // 获取当前时间点
    auto system_now = std::chrono::system_clock::now();

    int32_t current_system_seconds = std::chrono::duration_cast<std::chrono::seconds>(system_now.time_since_epoch()).count();

    if (current_system_seconds < last_system_seconds)
    {
        std::cout << "警告：系统时间回拨";
    }
    else
    {
        // 时间状态更新
        last_system_seconds = current_system_seconds;
    }
    // 转换为格林威治时间
    return current_system_seconds;
} // 函数结束

// 秒数更新判断函数
bool check_time_updated()
{
    static auto last_time = std::chrono::system_clock::now(); // 保存上一次时间点

    // 获取当前时间并转换为秒级精度
    auto current_time = std::chrono::system_clock::now();
    auto current_sec = std::chrono::duration_cast<std::chrono::seconds>(current_time.time_since_epoch());
    auto last_sec = std::chrono::duration_cast<std::chrono::seconds>(last_time.time_since_epoch());

    // 比较是否进入新的一秒
    if (current_sec > last_sec)
    {
        last_time = current_time; // 更新记录的时间点
        return true;
    }
    return false;
} // 函数结束

// 模型时间更新函数
int stat_gap_time()
{
    auto steady_now = std::chrono::steady_clock::now();
    int steady_elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(steady_now - last_staedy_time).count();
    last_staedy_time = steady_now;

    return steady_elapsed;
} // 函数结束

// 100毫秒时间的设置作为模型中的一基本单位时间
chrono::milliseconds hundred_ms(100);
