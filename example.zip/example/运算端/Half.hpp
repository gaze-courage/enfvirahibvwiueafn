#include <algorithm>
#include <cmath>
#include <cstring>
#include <math.h>
#include <stdexcept>
#include <cassert>
#include <thread>
#include <mutex>

#include "Basic.hpp"




// 图形数据存储


// 方向种类
static const char Dir_kind[32] = {0, 1,1, 2,2, 3,3, 4,4, 5,5, 6,6, 7,7, 8,8,
    9,9, 10,10, 11,11, 12,12, 13,13, 14,14, 15,15, 0};

// 对应方向数量：32方向 → 16方向 → 每象限4个(因为象限会正负)
static const float kBorder[8] = {0.1989f, 0.422f, 0.6682f, 1.0f, 1.4966f, 2.422f, 5.0273f, 9999.0f};

// 长度范围计算，用于映射的区间下限
vector<int> thresholds = { 0, 1, 2, 3, 4, 6, 8, 12, 16, 24, 32, 48, 64, 96, 128, 192 };

// 用于返回长度的区间值
vector<int> categories = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16 };

// 方向计算区间函数
char fast_dir(float x1, float y1) //与原点的差异
{
    if (x1 == 0 && y1 == 0)
        return 0;  // 0属于一个像素点

    // 确定象限偏移
    int base = 0;
    if (x1 < 0)
        base += 8; //左半球
    if (y1 < 0)
        base = 24 - base; //下半球

    float ax = fabsf(x1);
    float ay = fabsf(y1);

    // 决定 ratio
    float r;

    if (ax != 0)
        r = ay / ax;
    else if (y1 > 0)
        return 4;
    else if (y1 <= 0)
        return 12;

    int idx = 0;
    for ( ; idx <8; idx++)
        if (r <= kBorder[idx])
            break;

    // 如果在2、4象限，就需要旋转象限方向编号
    if ( (x1 < 0 && y1 > 0) || (x1 > 0 && y1 < 0) )
        idx = 7 - idx;

    char dir = base + idx;

    dir = Dir_kind[dir];

    return dir; // 方向 0~15
}//方向计算函数结束

// 长度查找函数
int Length_trans_Range(int value)//返回值所属的类别
{
    // 二分查找找到第一个大于等于value的阈值位置
    auto it = lower_bound(thresholds.begin(), thresholds.end(), value);

    // 返回对应的类别
    int index = distance(thresholds.begin(), it);

    return categories[index];
}

// 范围转长度函数
int Range_trans_Length(int value)
{
    // 二分查找找到第一个大于等于value的阈值位置
    auto it = lower_bound(categories.begin(), categories.end(), value);

    // 返回对应的类别
    int index = distance(categories.begin(), it);

    return thresholds[index];
}


//得到两点之间的方向距离
inline void get_two_point_direction_distance(int x0, int y0, int x1, int y1, 
    char& return_direction, char& return_distance)
{
    int dif_x = x1 - x0;
    int dif_y = y1 - y0;

    return_direction = fast_dir(dif_x, dif_y);
    return_distance = Length_trans_Range( sqrt(dif_x*dif_x + dif_y*dif_y) );
}

//得到在原点方向距离下的点
inline void get_another_point(int x0, int y0, char direction_range, char distance_range,
    int& return_x1, int& return_y1)
{
    // 方向角度转换弧度
    float angle = direction_range * 22.5 / (2 * 3.1415f); // 角度/2t=弧度

    int distance = Range_trans_Length(distance_range);
    int x_add = distance*0.7;

    // 计算斜率前置量
    float dx = cosf(angle);
    float dy = sinf(angle);

    // 水平角度情况
    if(fabsf(dx) < 1e-6f)
    {
        return_x1 += distance;
        return_y1 = y0; //差不多是原y

        return;
    }

    float slope = dy / dx;//斜率

    return_y1 = y0 + slope*(return_x1 - x0);

    char test_distance_range;
    char test_direction_range;
    get_two_point_direction_distance(x0, y0, return_x1, return_y1, test_direction_range, test_distance_range);

    while(test_distance_range < distance_range)
    {
        return_x1 += 1;
        return_y1 = y0 + slope*(return_x1 - x0);
        get_two_point_direction_distance(x0, y0, return_x1, return_y1, test_direction_range, test_distance_range);
    }
}


//四舍五入
int approximate(float value)
{
    int un_float = (int)value;

    if(value > 0)
    {
        if( value - un_float> 0.5 )
            return un_float + 1;
        else return un_float;
    } else {
        if( value - un_float> -0.5 )
            return un_float;
        else return un_float - 1;
    }
}


//连线计算函数
void two_point_to_line(
    unsigned short x0, unsigned short y0,
    unsigned short x1, unsigned short y1,
    vector<point_2d>& return_line)
{
    int dx = x0 - x1;
    int dy = y0 - y1;

    return_line.reserve( dx + dy);

    float slope = dy / dx;//斜率

    for(int q = 0; q < dx; q++)
    {
        float x = x0 + q;
        float y = y0 + slope*q;//y点值
        point_2d p2;

        if(x - (int)x < 0.5)//求近似
            p2.x = x;
        else p2.x = x + 1;

        if(y - (int)y < 0.5)
            p2.y = y;
        else p2.y = y + 1;

        return_line.push_back(p2);
    }

}
//函数结束


//矩形空间界限
struct rectangle_border {
    vector<point_2d> a_line;
    vector<point_2d> b_line;
    vector<point_2d> c_line;
    vector<point_2d> d_line;
};

// 区域划定函数
rectangle_border dir_extend_region(
    unsigned short x0, unsigned short y0,
    char min_dir, char max_dir,
    char min_len, char max_len)
{
    // 计算长度
    unsigned short min_length = Range_trans_Length(min_len);
    unsigned short max_length = Range_trans_Length(max_len);
    
    // 计算方向边界
    char min_direction = min_dir*2 - 1;
    char max_direction = max_dir*2 + 1;

    if(min_direction < 0);
        min_direction = 31;

    // 弧度 = 角度/2t
    float min_angle = min_direction*11.25 / (2 * 3.1415f);
    float max_angle = max_direction*11.25 / (2 * 3.1415f);

    // 计算斜率前置量
    float min_dx = cosf(min_angle);
    float min_dy = sinf(min_angle);
    float max_dx = cosf(max_angle);
    float max_dy = sinf(max_angle);

    int x1 = min_length*min_dx;
    int y1 = min_length*min_dy;

    int x2 = max_length*min_dx;
    int y2 = max_length*min_dy;

    int x3 = max_length*max_dx;
    int y3 = max_length*max_dy;

    int x4 = min_length*max_dx;
    int y4 = min_length*max_dy;

    rectangle_border result;

    two_point_to_line(x1, y1, x2, y2, result.a_line);
    two_point_to_line(x2, y2, x3, y3, result.b_line);
    two_point_to_line(x3, y3, x4, y4, result.c_line);
    two_point_to_line(x4, y4, x1, y1, result.d_line);

    //注意，边界非精准
    return result;
}
//函数结束


// 跨尺度空间特征
struct image_object_locate_info
{
    char direction; // 方向，0~15
    char distance;  // 距离，范围，在标准下0~15
    char relative_scale; // 相对大小，正数为当前尺度比对方大，负数为当前尺度比对方小，1为使用尺度相同
    char a;
};


//空间信息比较定位函数
image_object_locate_info image_object_locate(uint32_t self_idx, //本体
    uint32_t object_idx )//目标 
{
    // 返回相对比例以及相对位置
    image_object_locate_info info;

    Node_Image_Attribute object_attribute = read_a_Node_Image_Attribute(object_idx);
    Node_Image_Attribute self_attribute = read_a_Node_Image_Attribute(self_idx);

    char object_size = object_attribute.standard_size;
    char self_size = self_attribute.standard_size;

    get_two_point_direction_distance(
        self_attribute.x * self_size,
        self_attribute.y * self_size,
        object_attribute.x * object_size,
        object_attribute.y * object_size,
        info.direction, info.distance);
    
    if( object_size > self_size )
        info.relative_scale = -(object_size / self_size);
    else if ( object_size < self_size )
        info.relative_scale = self_size / object_size;
    else info.relative_scale = 1;

    return info;
}


//新节点生成函数
uint32_t new_road_node_generate(
    vector<uint32_t> material_node_list,
    char generate_kind, // 无属性1、空间属性2、文本属性3、时间属性4
    uint32_t scene_idx, char scene_kind) //图区1，文区2，通区3
{
    //填写上层节点的属性和下层连接

    char material_size = material_node_list.size();

    uint32_t new_idx = create_a_General_Cognition_Node();

    if(generate_kind == 1)
    {
        //概念属性

        General_Cognition_Node& new_node = General_Cognition_Node_Storage[new_idx];
        
        new_node.object_list.resize(material_size);

        for(int q = 0; q < material_size; q++)
        {
            uint32_t i = material_node_list[q];

            Link_Object_Attribute link_object;

            link_object.Link_Kind = 001;
            link_object.Link_Idx = i;
            link_object.Link_Value = 1;

            new_node.object_list[q].link_attribute = link_object;
        }

    } else if(generate_kind == 2) {

        //图像属性

        Map_Analysis_Scene& curr_map = Map_Analysis_Scene_Storage[scene_idx];

        //创建生成通路
        General_Cognition_Node& new_node = General_Cognition_Node_Storage[new_idx];

        int all_occupy = 0;
        int x_sum = 0;
        int y_sum = 0;

        // 空间坐标计算，使用平均位置，若未自定义定位点时
        for(int a = 0; a < material_size; a++)
        {
            uint32_t i = material_node_list[a];
            General_Cognition_Node& material_node = General_Cognition_Node_Storage[i];

            Link_Object_Attribute link_object;

            // 支持节点记录
            link_object.Link_Kind = 2;
            link_object.Link_Idx = new_idx;
            Flexible_Object flex = {.link_attribute = link_object};
            material_node.object_list.push_back(flex);

            // 来源节点记录
            link_object.Link_Kind = 1;
            link_object.Link_Idx = i;
            Flexible_Object flex_ = {.link_attribute = link_object};
            new_node.object_list.push_back(flex_);

            Node_Image_Attribute obj_att = read_a_Node_Image_Attribute(i);

            x_sum += obj_att.block_num * obj_att.x;
            y_sum += obj_att.block_num * obj_att.y;

            all_occupy += obj_att.block_num;
        }

        // 把之前省略的距离除总数补上
        x_sum = x_sum / all_occupy;
        y_sum = y_sum / all_occupy;

        Node_Image_Attribute add_att;// = Node_Image_Attribute_List[create_a_Node_Image_Attribute(new_idx)];
        add_att.block_num = all_occupy;
        add_att.x = x_sum;
        add_att.y = y_sum;
        new_node.complete = 1;

        // 计算内部距离
        for(int t = 0; t <material_size; t++)
        {
            uint32_t i = material_node_list[t];
            General_Cognition_Node& material_node = General_Cognition_Node_Storage[i];
            Node_Image_Attribute att = read_a_Node_Image_Attribute(i);

            int dif_x = x_sum - att.x;
            int dif_y = y_sum - att.y;

            add_att.contain_distance += sqrt( dif_x*dif_x + dif_y*dif_y );
        }

        // 添加去重
        curr_map.image_combo_hash.insert(material_node_list);

        // 网络记录添加
        curr_map.Image_Cover_Node_View.Image_Node_Idx_Record;

    } else if(generate_kind == 3) {

        //文本节点生成

        Text_Inference_Scene& curr_text = Text_Inference_Scene_Storage[scene_idx];

        vector< vector<uint32_t> > text_infer_node_list = curr_text.text_infer_node_list;

        //创建生成通路
        General_Cognition_Node& new_node = General_Cognition_Node_Storage[new_idx];

        int all_occupy = 0;
        int distance_sum = 0;

        // 空间坐标计算，使用平均位置，若未自定义定位点时
        for(int a = 0; a < material_size; a++)
        {
            uint32_t i = material_node_list[a];
            General_Cognition_Node& material_node = General_Cognition_Node_Storage[i];

            Link_Object_Attribute link_object;

            link_object.Link_Kind = 001;
            link_object.Link_Idx = new_idx;
            link_object.Link_Value = 1;
            Flexible_Object flex = {.link_attribute = link_object};

            // 生成节点记录
            material_node.object_list.push_back(flex);

            link_object.Link_Kind = 002;
            link_object.Link_Idx = i;
            link_object.Link_Value = 1;
            flex = {.link_attribute = link_object};

            // 来源节点记录
            new_node.object_list.push_back(flex);

            Node_Text_Attribute att = read_a_Node_Text_Attribute(i);
            distance_sum += att.block_num * att.index_position;
            all_occupy += att.block_num;
        }

        // 把之前省略的距离除总数补上
        distance_sum = distance_sum / all_occupy;

        create_a_Node_Text_Attribute(new_idx);
        Node_Text_Attribute add_att = read_a_Node_Text_Attribute(new_idx);
        add_att.block_num = all_occupy;
        add_att.index_position = distance_sum;

        // 添加去重


        //
        uint32_t add_pos = add_att.index_position;
        add_pos = add_pos / 8;

        text_infer_node_list[add_pos].push_back(new_idx);
        
    } else if(generate_kind == 4) {
        
        //时间相关节点生成

        //创建生成通路
        General_Cognition_Node& new_node = General_Cognition_Node_Storage[new_idx];

        int all_occupy = 0;
        int distance_sum = 0;

        // 时间坐标计算，使用平均位置，若未自定义定位点时
        for(int a = 0; a < material_size; a++)
        {
            uint32_t i = material_node_list[a];
            General_Cognition_Node& material_node = General_Cognition_Node_Storage[i];

            Link_Object_Attribute link_object;

            link_object.Link_Kind = 001;
            link_object.Link_Idx = new_idx;
            link_object.Link_Value = 1;
            Flexible_Object flex = {.link_attribute = link_object};

            // 生成节点记录
            material_node.object_list.push_back(flex);

            link_object.Link_Kind = 003;
            link_object.Link_Idx = i;
            link_object.Link_Value = 1;
            flex = {.link_attribute = link_object};

            // 来源节点记录
            new_node.object_list.push_back(flex);

            Node_Time_Attribute att = read_a_Node_Time_Attribute(i);

            long long reak_time = 0;

            att.self_time_back; // 时间的溢出和差异没有解决
            att.self_time_front;

            distance_sum += att.node_num * reak_time;
            all_occupy += att.node_num;
        }

        create_a_Node_Time_Attribute(new_idx);
        Node_Time_Attribute add_att = read_a_Node_Time_Attribute(new_idx);
        add_att.node_num = all_occupy;
        add_att.self_time_back = distance_sum;

        //
    }

return new_idx;
}


//新神经元记录生成函数
void new_neuro_generate_record(
    uint32_t target_node_idx, char generate_node_kind,
    float rich_rate)// 下级含有上级生成的几率
{
    //主要是填写来源神经元的合成规则
    unsigned char allow_value = 255*rich_rate;

    General_Cognition_Node& target_node = General_Cognition_Node_Storage[target_node_idx];
    
    vector<Flexible_Object>& upper_link_object_list = target_node.object_list;

    if(generate_node_kind == 1)
    {
        //图像

        // 创建神经元
        unsigned int get_id = neuro_create(1);
        target_node.self_id = get_id;


        Attribute_Head upper_attribute_head;
        upper_attribute_head.attribute_kind = 2;
        upper_attribute_head.condition_kind = 2;
        upper_attribute_head.result_kind = 2;

        vector<General_Condition> upper_general_condition_list;
        vector<General_Result> upper_general_result_list;


        vector<int> add_item;

        char lower_node_num = 0;

        // 对下级神经元填写来源
        for(int q = 0; q < upper_link_object_list.size(); q++)
        {
            Link_Object_Attribute la = upper_link_object_list[q].link_attribute;

            if(la.Link_Attribute != 2 && la.Link_Kind != 1)
                continue;
            
            uint32_t write_pos = la.Link_Idx;
            unsigned int material_id = General_Cognition_Node_Storage[write_pos].self_id;

            //是否在此处下级神经元生成上级神经元
            if(rand_0_to_255() < allow_value)
            {
                lower_node_num += 1;

                // 通过在此处建立聚合连接
                Attribute_Head lower_attribute_head;
                lower_attribute_head.attribute_kind = 2;
                lower_attribute_head.condition_kind = 2;
                lower_attribute_head.result_kind = 2;

                vector<General_Condition> lower_general_condition_list;
                vector<General_Result> lower_general_result_list;
                // 填写对象
                
                for(int w = 0; w < upper_link_object_list.size(); w++)
                {
                    if(la.Link_Attribute != 2 && la.Link_Kind != 1 && q == w) //过滤条件
                        continue;

                    uint32_t con_pos = upper_link_object_list[w].link_attribute.Link_Idx;

                    image_object_locate_info space_feature 
                        = image_object_locate(write_pos, con_pos);

                    Image_Item image_comdition;

                    image_comdition.direction = space_feature.direction;
                    image_comdition.distance = space_feature.distance;
                    image_comdition.related_scale = space_feature.relative_scale;
                    image_comdition.related_id = General_Cognition_Node_Storage[con_pos].self_id;

                    General_Condition condition = {.image_condition = image_comdition};
                    lower_general_condition_list.push_back(condition);

                    lower_attribute_head.condition_num += 1;
                }

                //生成上级
                Image_Item result_image;
                image_object_locate_info space_feature;
                space_feature = image_object_locate(write_pos, target_node_idx);

                result_image.direction = space_feature.direction;
                result_image.distance = space_feature.distance;
                result_image.related_scale = space_feature.relative_scale;
                result_image.related_id = get_id;

                General_Result result = {.image_result = result_image};
                lower_general_result_list.push_back(result);

                lower_attribute_head.result_num += 1;

                general_attribute_put(lower_attribute_head, add_item, lower_general_condition_list, lower_general_result_list);
                neuro_attribute_write(material_id, add_item, 0, 1);
            }
        }

        add_item.clear();

        //在上级神经元填写来源
        for(int a = 0; a < lower_node_num; a++)
        {
            general_attribute_put(upper_attribute_head, add_item, upper_general_condition_list, upper_general_result_list);
            neuro_attribute_write(get_id, add_item, 0, 1);
        }

        Search_General_Cognition_Node[get_id].push_back(target_node_idx);

    } else if(generate_node_kind == 2) {
        
        //文本

        // 创建神经元
        unsigned int get_id = neuro_create(2);
        target_node.self_id = get_id;


        Attribute_Head upper_attribute_head;
        upper_attribute_head.attribute_kind = 2;
        upper_attribute_head.condition_kind = 2;
        upper_attribute_head.result_kind = 2;

        vector<General_Condition> upper_general_condition_list;
        vector<General_Result> upper_general_result_list;


        vector<int> add_item;

        char lower_node_num = 0;

        //填写来源
        for(int q = 0; q < upper_link_object_list.size(); q++)
        {
            Link_Object_Attribute lo = upper_link_object_list[q].link_attribute;

            if(lo.Link_Kind != 1 && lo.Link_Attribute != 2)
                continue;
            
            uint32_t wri_pos = lo.Link_Idx;
            unsigned int material_id = General_Cognition_Node_Storage[wri_pos].self_id;

            if(rand_0_to_255() < allow_value)
            {
                lower_node_num += 1;

                // 通过在此处建立聚合连接
                Attribute_Head lower_attribute_head;
                lower_attribute_head.attribute_kind = 2;
                lower_attribute_head.condition_kind = 4;
                lower_attribute_head.result_kind = 4;

                vector<General_Condition> lower_general_condition_list;
                vector<General_Result> lower_general_result_list;
                
                for(int w = 0; w < upper_link_object_list.size(); w++)
                {
                    //过滤
                    if(upper_link_object_list[w].link_attribute.Link_Attribute == 2
                        && upper_link_object_list[w].link_attribute.Link_Kind == 1
                        && q != w) 
                        continue;

                    uint32_t con_pos = upper_link_object_list[w].link_attribute.Link_Idx;

                    Text_Item text_comdition;

                    text_comdition.left_distance;
                    text_comdition.right_distance;

                    General_Condition condition = {.text_condition = text_comdition};
                    lower_general_condition_list.push_back(condition);

                    lower_attribute_head.condition_num += 1;
                }

                //生成上级
                Text_Item text_result;

                General_Result result = {.text_result = text_result};
                lower_general_result_list.push_back(result);

                lower_attribute_head.result_num += 1;

                simple_neuro_attribute_write(material_id, 0, 1, lower_attribute_head,
                    lower_general_condition_list, lower_general_result_list);

                general_attribute_put(lower_attribute_head, add_item, lower_general_condition_list, lower_general_result_list);
                neuro_attribute_write(material_id, add_item, 0, 1);
            }
        }

        //在上级神经元填写来源

        for(int a = 0; a < lower_node_num; a++)
        {
            general_attribute_put(upper_attribute_head, add_item, upper_general_condition_list, upper_general_result_list);
            neuro_attribute_write(get_id, add_item, 0, 1);
        }

        Search_General_Cognition_Node[get_id].push_back(target_node_idx);

    } else if(generate_node_kind == 3) {
        //时间线

        // 创建神经元
        unsigned int get_id = neuro_create(2);
        target_node.self_id = get_id;


        Attribute_Head upper_attribute_head;
        upper_attribute_head.attribute_kind = 2;
        upper_attribute_head.condition_kind = 2;
        upper_attribute_head.result_kind = 2;

        vector<General_Condition> upper_general_condition_list;
        vector<General_Result> upper_general_result_list;

        vector<int> add_item;

        char lower_node_num = 0;

        //填写来源
        for(int q = 0; q < upper_link_object_list.size(); q++)
        {
            Link_Object_Attribute lo = upper_link_object_list[q].link_attribute;

            if(lo.Link_Kind != 1 && lo.Link_Attribute != 2)
                continue;
            
            uint32_t wri_pos = lo.Link_Idx;
            unsigned int material_id = General_Cognition_Node_Storage[wri_pos].self_id;

            if(rand_0_to_255() < allow_value)
            {
                lower_node_num += 1;

                // 通过在此处建立聚合连接
                Attribute_Head lower_attribute_head;
                lower_attribute_head.attribute_kind = 2;
                lower_attribute_head.condition_kind = 4;
                lower_attribute_head.result_kind = 4;

                vector<General_Condition> lower_general_condition_list;
                vector<General_Result> lower_general_result_list;
                
                for(int w = 0; w < upper_link_object_list.size(); w++)
                {
                    //过滤
                    if(upper_link_object_list[w].link_attribute.Link_Attribute == 2
                        && upper_link_object_list[w].link_attribute.Link_Kind == 1
                        && q != w) 
                        continue;

                    uint32_t con_pos = upper_link_object_list[w].link_attribute.Link_Idx;

                    Time_Item time_condition;

                    time_condition.time_logic;
                    time_condition;

                    General_Condition condition = {.time_condition = time_condition};
                    lower_general_condition_list.push_back(condition);

                    lower_attribute_head.condition_num += 1;
                }

                //生成上级
                Time_Item time_result;

                General_Result result = {.time_result = time_result};
                lower_general_result_list.push_back(result);

                lower_attribute_head.result_num += 1;

                simple_neuro_attribute_write(material_id, 0, 1, lower_attribute_head,
                    lower_general_condition_list, lower_general_result_list);

                general_attribute_put(lower_attribute_head, add_item, lower_general_condition_list, lower_general_result_list);
                neuro_attribute_write(material_id, add_item, 0, 1);
            }
        }

        //在上级神经元填写来源

        for(int a = 0; a < lower_node_num; a++)
        {
            general_attribute_put(upper_attribute_head, add_item, upper_general_condition_list, upper_general_result_list);
            neuro_attribute_write(get_id, add_item, 0, 1);
        }

        Search_General_Cognition_Node[get_id].push_back(target_node_idx);

    }

}
//函数结束


//图生成匹配模块函数
inline void Image_Match_Generate_Module(uint32_t curr_node_idx, uint32_t scene_idx, unsigned int self_id,
    short& fea, unsigned int*& first_ptr)
{
    Map_Analysis_Scene& curr_map = Map_Analysis_Scene_Storage[scene_idx];
    unordered_map<unsigned int, vector<uint32_t> >& Id_Find_Index = curr_map.Id_Find_Index;

    General_Cognition_Node curr_node = read_a_General_Cognition_Node(curr_node_idx);
    unsigned int curr_node_id = curr_node.self_id;

    Node_Image_Attribute image_attribute = read_a_Node_Image_Attribute(curr_node_idx);
    unsigned short x = image_attribute.x;
    unsigned short y = image_attribute.y;

    // 检查每一条属性
    Attribute_Head attribute_head = attribute_head_get(first_ptr);
    char condition_size = attribute_head.condition_size;
    char condition_num = attribute_head.condition_num;
    char un_condition_num = attribute_head.un_condition_num;

    unsigned int result_generate_id = *(first_ptr + 3 + condition_size *
        (condition_num + un_condition_num) + attribute_head.result_size);
    
    int matchCount = condition_num;
    uint32_t match_idx = create_a_Scene_Inside_Image_Match(curr_map.Image_Match_List, curr_map.Free_Image_Match_Index);
    Image_Match& image_match = curr_map.Image_Match_List[match_idx];
    vector<uint32_t> combo_of;

    //自动化原属性更新，更新统计属性
    *(first_ptr + 1) += 1;

    //生成
    if(attribute_head.attribute_kind == 2)
    {
        //上图的注意对象遗传，未完成

        // 1、进行相关条件检测
        for (char a = 0; a < condition_num; a += 1)
        {
            Image_Item image_condition = *(Image_Item*)(first_ptr + 2 + a*2);
            unsigned int need_id = image_condition.related_id;
            char logic = image_condition.logic;

            // 无该存在对象
            if( !Id_Find_Index.count(need_id) )
            {
                matchCount--;

                image_match.need_condition_list[image_match.total_need] = image_condition;
                image_match.total_need += 1;
                image_match.result_generate_id = result_generate_id;
                continue;
            }

            char candidate_amount = Id_Find_Index[need_id].size();

            if(logic == 1)//图像生成
            {
                char o_direction = image_condition.direction;
                char o_distance = image_condition.distance;
                char o_related_scale = image_condition.related_scale;

                // 1-1、检查每个 符合特征 的位置
                for(unsigned char b = 0; b < candidate_amount; b++)
                {
                    uint32_t target_idx = Id_Find_Index[need_id][b];

                    Node_Image_Attribute target_image_attritube = read_a_Node_Image_Attribute(target_idx);
                    // 求解空间方位，允许规定误差
                    char dif_x = target_image_attritube.x - x;
                    char dif_y = target_image_attritube.y - y;
                    char distance = fast_dir(dif_x, dif_y);
                    char direction = Length_trans_Range(sqrt( dif_x*dif_x + dif_y*dif_y ));

                    //方向和距离检测 精度可调
                    if ( abs(distance - o_distance) <= 0 &&
                        abs(direction - o_direction) <= 1)
                    {
                        combo_of.push_back(target_idx);
                        break;

                    } else if ( b == (candidate_amount - 1) ) {
                        // 1-2、检测失败，添入待匹配
                        image_match.need_condition_list[image_match.total_need] = image_condition;
                        image_match.total_need += 1;
                        image_match.result_generate_id = result_generate_id;

                        matchCount--;
                    }
                }

            } else {//概念生成

                if( Id_Find_Index.count( *(first_ptr + 3 + a) ))
                {
                    combo_of.push_back(  Id_Find_Index[*(first_ptr + 2*a + 1)][0]   );
                    break;

                } else {
                    // 1-2、检测失败，添加待匹配
                    image_match.need_condition_list[image_match.total_need] = image_condition;
                    image_match.total_need += 1;
                    image_match.result_generate_id = result_generate_id;

                    matchCount--;
                }
            }
        }

        combo_of.push_back( self_id );
        combo_of.push_back( *(first_ptr + 9) );
        sort( combo_of.begin(), combo_of.end() );

        // 1-3、去重检测
        if ( curr_map.image_combo_hash.count(combo_of) )
        {
            //空间方位若一致，未完成
            // if()
            {
                fea += attribute_head.item_num;
                first_ptr += attribute_head.item_num;
                return;
            }
        }

        // 条件不满足，则跳过
        if (matchCount < condition_num)
        {
            fea += attribute_head.item_num;
            first_ptr += attribute_head.item_num;
            return;
        }

        // 2、节点添加 记载
        char node_kind = *( (char*)(first_ptr + 2 + condition_size *
            (condition_num + un_condition_num) + attribute_head.result_size) );
        
        uint32_t add_idx = new_road_node_generate( combo_of, node_kind, scene_idx, 1);
        combo_of.clear();
        General_Cognition_Node& add_node = General_Cognition_Node_Storage[add_idx];
        add_node.complete = matchCount / condition_num;

        unsigned int id = *(first_ptr + 3 + condition_size *
            (condition_num + un_condition_num) + attribute_head.result_size);
        
        add_node.self_id = id;
        curr_map.Id_Find_Index[id].push_back(add_idx);

        int image_match_num = 0;
        vector<Image_Match>& Image_Match_vector = curr_map.Image_Match_List;

        // 3、匹配激活
        if( curr_map.Find_Image_Match.count( add_node.self_id ) )
        {
            vector<uint32_t>& match_idx = curr_map.Find_Image_Match[add_node.self_id];
            image_match_num = match_idx.size();

            //挨个匹配列表中的匹配
            for(int q = 0; q < image_match_num; q++)
            {
                if(match_idx[q] == -1)
                    continue;

                Image_Match image_match = Image_Match_vector[ match_idx[q] ];
                int i = 0;

                for( ; i<5 && image_match.need_condition_list[i].related_id != add_node.self_id; i++ )
                    ;
                Image_Item oritation_condition = image_match.need_condition_list[i];

                if(oritation_condition.logic == 1)//图像
                {
                    oritation_condition.related_scale;
                    oritation_condition.direction;
                    oritation_condition.distance;

                    //if() 匹配通过
                    {
                        image_match.need_condition_list[i].related_id = 0;
                        match_idx[q] = -1;
                        image_match.total_need -= 1;

                        if(image_match.total_need == 0) // 若全部条件满足，生成该节点
                        {
                            vector<uint32_t> source_node;
                            source_node.reserve(image_match.node_num);

                            for(int a = 0; a < image_match.node_num; a++ )
                                source_node.push_back(image_match.node_idx_from_list[a]);

                            add_idx = new_road_node_generate(source_node, image_match.generate_kind, scene_idx, 1);
                            General_Cognition_Node& new_node = General_Cognition_Node_Storage[add_idx];
                            unsigned int id = image_match.result_generate_id;
                            new_node.self_id = id;
                            curr_map.Id_Find_Index[id].push_back(add_idx);
                        }
                    }

                } else {//概念
                    //同上
                }
            }

        }
    }
    

    //统计
    if(attribute_head.attribute_kind == 1)
    {
        curr_map.Image_Match_List.push_back(image_match);

        for (char a = 0; a < condition_num; a += 1)
        {
            Image_Item image_item = *(Image_Item*)(first_ptr + 2 + 2*a);
            unsigned int need_id = image_item.related_id;
            char logic = image_item.logic;

            // 无该存在对象
            if( !Id_Find_Index.count(need_id) )
            {
                matchCount--;

                //主要是负责反馈的部分，或许我可以把这部分设置专门的
                image_match.need_condition_list[image_match.total_need] = image_item;
                image_match.node_idx_from_list[image_match.total_need] = curr_node_idx;
                image_match.total_need += 1;
                image_match.generate_kind = 0;
                continue;

            } else {
                //有，但要确定位置

                vector<uint32_t> possible_object = Id_Find_Index[need_id];
                int possible_object_size = possible_object.size();
                
                for(int b = 0; b < possible_object_size; b++)
                {
                    uint32_t possible_object_idx = possible_object[b];
                    Node_Image_Attribute object_image_attribute = read_a_Node_Image_Attribute(possible_object_idx);
                    
                    char compare_direction;
                    char compare_distance;

                    get_two_point_direction_distance(x, y, object_image_attribute.x, 
                        object_image_attribute.y, compare_direction, compare_distance);

                    char diff_direction = abs(compare_direction - image_item.direction);
                    char diff_distance = abs(compare_distance - image_item.distance);

                    if(diff_direction < image_item.direction_scale && diff_distance < image_item.distance_scale)
                    {
                        *(first_ptr + 2) += 1;
                        break;
                    }
                }

                //无对象，则有此步
                matchCount--;

                image_match.need_condition_list[image_match.total_need] = image_item;
                image_match.node_idx_from_list[image_match.total_need] = curr_node_idx;
                image_match.total_need += 1;
                image_match.generate_kind = 0;
                continue;

                curr_map.Find_Image_Match[need_id].push_back(match_idx);
            }
            //存在对象搜索结束
            
        }

        
    }

    fea += attribute_head.item_num;
    first_ptr += attribute_head.item_num;
    //该属性 匹配激活相关 结束
    //但中途在匹配中途生成会怎么样

}

//文生成匹配模块函数
inline void Text_Match_Generate_Module(unsigned int*& ptr, uint32_t pos_idx,
    short& a, uint32_t scene_idx)
{
    Text_Inference_Scene& curr_text_network = Text_Inference_Scene_Storage[scene_idx];
    vector<uint32_t>& original_text_list = curr_text_network.original_text_list;
    vector< vector<uint32_t> >& text_infer_node_list = curr_text_network.text_infer_node_list;

    Attribute_Head item_head = attribute_head_get(ptr);
    char attribute_kind = item_head.attribute_kind;

    int original_text_size = original_text_list.size();

    Text_Match text_match;

    // 2-1、文本统计
    if (attribute_kind == 1)
    {
        Text_Item text_condition = *(Text_Item*)(ptr + 3);
        
        unsigned int neighbor_id = text_condition.target_id;

        //统计属性更新
        *(ptr + 1) += 1;

        int left_distance = text_condition.left_distance;
        int right_distance = text_condition.right_distance;
        int distance_scale = text_condition.distance_scale;

        int front_boundary = pos_idx + left_distance * distance_scale;
        int back_boundary = pos_idx + right_distance * distance_scale;

        if(front_boundary < 0)
            front_boundary = 0;

        if(back_boundary > original_text_size - 1)
            back_boundary = original_text_size - 1;

        char num = 0;

        //统计对象检测
        if(text_condition.logic == 1)
        {
            //此时做字符检测
            for(int b = front_boundary; b <= back_boundary ; b++)
            {
                if(neighbor_id = General_Cognition_Node_Storage[original_text_list[b]].self_id)
                    num += 1;

                if(num)
                {
                    *(ptr + 2) += 1;
                    //何不加num，这可能是一种新方向
                    break;
                }
            }

            //若无

        } else if(text_condition.logic == 2) {
        
            //此时做字符串检测
            uint32_t front_idx = front_boundary / 8;
            uint32_t back_idx = back_boundary / 8;

            //1、开头检验
            int b = front_idx;
            vector<uint32_t>& inside_list = text_infer_node_list[b];
            int inside_size = inside_list.size();

            for(int b = 0; b < inside_size; b++)
            {
                Node_Text_Attribute scan_object_attribute = read_a_Node_Text_Attribute(b);
                //坐标合理
                int space_pos = scan_object_attribute.index_position;
                    
                if(space_pos < front_boundary && front_boundary > back_boundary)
                    continue;

                if(neighbor_id == General_Cognition_Node_Storage[inside_list[b]].self_id)
                    num += 1;
            }

            
            //2、中间检测
            for(b = front_idx + 1; b <= back_idx - 1; b++)
            {
                vector<uint32_t>& inside_list = text_infer_node_list[b];

                inside_size = inside_list.size();

                for(int c = 0; c < inside_size; c++)
                {
                    if(neighbor_id = General_Cognition_Node_Storage[inside_list[c]].self_id)
                        num += 1;
                }
            }

            //3、结尾检验
            if(back_idx != front_idx)
            {
                b = back_idx;
                vector<uint32_t>& inside_list = text_infer_node_list[b];
                int inside_size = inside_list.size();

                for(int b = 0; b < inside_size; b++)
                {
                    Node_Text_Attribute scan_object_attribute = read_a_Node_Text_Attribute(b);
                    //坐标合理
                    int space_pos = scan_object_attribute.index_position;
                        
                    if(space_pos < front_boundary && front_boundary > back_boundary)
                        continue;

                    if(neighbor_id == General_Cognition_Node_Storage[inside_list[b]].self_id)
                        num += 1;
                }
            }
        }


        if(num)
        {
            *(ptr + 2) += 1;
        }

    } else if(attribute_kind == 2) {

        // 2-2、文本聚合
    
        //统计属性更新
        *(ptr + 1) += 1;

        Text_Item result_item = *(Text_Item*)(ptr + 3 + item_head.condition_num*2 + 1);

        vector<uint32_t> condition_node_list;

        char match_count = 0;

        for(int b = 0; b < item_head.condition_num; b++)
        {
            //搜索设置
            Text_Item text_condition_item = *(Text_Item*)(ptr + 3 + b*2);
            unsigned int need_id = text_condition_item.target_id;

            //搜索匹配
            int front_boundary = pos_idx + text_condition_item.left_distance;
            int back_boundary = pos_idx + text_condition_item.right_distance;
            
            if(front_boundary < 0)
                front_boundary = 0;

            if(back_boundary > original_text_size - 1)
                back_boundary = original_text_size - 1;

            int first_position = front_boundary;

            //开始搜索
            if(text_condition_item.logic == 1)
            {
                //
                for(int b = front_boundary; b <=back_boundary; b++)
                {
                    uint32_t i = original_text_list[b];

                    uint32_t object_id;

                    if(object_id == text_condition_item.target_id)
                    {
                        match_count++;
                        original_text_list;
                    }
                }

                //若无对应
                {
                    ;
                    // 待匹配项加一
                }
            } else {
                //起始界检查
                int b = front_boundary;
                vector<uint32_t>& inside_list = text_infer_node_list[b];
                int inside_size = inside_list.size();

                for(int b = 0; b < inside_size; b++)
                {
                    //坐标合理
                    int space_pos;

                    if(space_pos < front_boundary && front_boundary > back_boundary)
                        continue;

                    if(need_id == General_Cognition_Node_Storage[inside_list[b]].self_id)
                    {
                        match_count += 1;
                        break;
                    }
                }

                //中间检查
                for(b = front_boundary + 1; b < back_boundary; b++)
                {
                    inside_list = text_infer_node_list[b];
                    inside_size = inside_list.size();

                    uint32_t i = original_text_list[b];

                    uint32_t object_id;

                    if(object_id == text_condition_item.target_id)
                    {
                        match_count++;
                        original_text_list;
                    }
                }

                //终止界检查
                b = back_boundary;
                inside_list = text_infer_node_list[b];
                inside_size = inside_list.size();

                for(int b = 0; b < inside_size; b++)
                {
                    //坐标合理
                    int space_pos;

                    if(space_pos < front_boundary && front_boundary > back_boundary)
                        continue;

                    if(need_id == General_Cognition_Node_Storage[inside_list[b]].self_id)
                    {
                        match_count += 1;
                        break;
                    }
                }

                //若无对应
                {
                    ;
                    // 待匹配项加一
                }
            }
            
        }

        //节点，生成
        if(match_count == item_head.condition_num)
        {
            //条件满足
            if(item_head.result_kind == 4)
            {
                //生成文本节点
                new_road_node_generate(condition_node_list, 3, scene_idx, 2);
                
            } else if (item_head.result_kind == 1) {
                //生成概念节点
                // new_road_node_generate();
            }
        }

        //匹配可能需求的节点

    }

    ptr += item_head.item_num;
    a += item_head.item_num;
}


//神经元属性激活函数
vector<uint32_t> General_A_Neuro_Active(
    uint32_t curr_node_idx, uint32_t scene_idx,
    char deal_state,  // 图像1，文本2，统计3
    char generate_state = 1) // 默认1，模拟2，行动3
{
    vector<uint32_t> generate_node_idx_list; //生成特征
    generate_node_idx_list.reserve(32);

    if(curr_node_idx == 0)
        return generate_node_idx_list;

    General_Cognition_Node& curr_node = General_Cognition_Node_Storage[curr_node_idx];

    unsigned int self_id = curr_node.self_id;

    //激活拦截
    if(self_id == 0 || curr_node.node_attention < 10)
        return generate_node_idx_list;

    unsigned int* first_ptr = node_find(self_id); // 头部位置指针
    unsigned int* ptr = first_ptr;

    Neuro_Head_Attribute neuro_head = neuro_head_read(*ptr);
    ptr += 16; // 指针转入特征位置

    //修改神经元描述用
    (first_ptr);


    //未完成节点检索时的注意力继承操作

    //模拟工作，允许生成所有客观节点
    //行动工作，允许生成主观行动节点

    //无条件生成节点，只是会含统计概率

    General_Cognition_Scene& stat_scene = General_Cognition_Scene_Storage[scene_idx];

    uint32_t simu_network_idx ;
    General_Cognition_Scene& simu_network = General_Cognition_Scene_Storage[simu_network_idx];


    // 1、图像工作，生成节点
    if(deal_state == 1)
    {
        // 遍历检索属性
        
            if(generate_state == 1)
            {
                for (short fea = 0; fea < neuro_head.used_item_num; )
                {
                    Image_Match_Generate_Module( scene_idx, curr_node_idx, self_id, fea, ptr);
                }//该神经元检索结束
                
            } else if(generate_state == 2) {
                ;
            } else if(generate_state == 3) {
                ;
            }
            

        
    }


    // 2、文本工作，生成节点
    if(deal_state == 2)
    {
        vector< vector<Text_Match> > text_match;

        //curr_node_idx
        //
        uint32_t pos_idx;

        //2、遍历神经元属性
        for (short a = 0; a < neuro_head.used_item_num; )
        {
            Text_Match_Generate_Module(ptr, pos_idx, a, scene_idx);
        }
        //单神经元 属性遍历结束

    }


    // 3、统计工作，优化神经元
    if(deal_state == 3)
    {
        // 这个主要是评估，去除低质连接，减少无意义冗余消耗
        // 评估连接需求 升级/降级/删除
        // 生成的时候应生成待验证列，遍历查找验证列，匹配和待验证

        //该预测不存在、存在，有(时间性错误、条件性错误)
        //这种应该在专用预测统计函数
        //链接强度评测·预测可替代性
        //重复预测 模糊预测 过度预测 无用预测

        unsigned int curr_node_id = curr_node.self_id;
        
        //更新原记录数据

        //若包被删除
        if(ptr == 0)
        {
            add_to_Will_Read_Neuro_Queue(curr_node_id);

            //填入待做任务，未完成

            return generate_node_idx_list;
        }

        //遍历元连接
        for(int f = 0; f < neuro_head.used_item_num; f++)
        {
            Attribute_Head origin_attribute_head = attribute_head_get(first_ptr);

            //不可升级
            if (origin_attribute_head.able_update = 0)
            {
                first_ptr += origin_attribute_head.item_num;
                f += origin_attribute_head.item_num;
                continue;
            }

            char attribute_kind = origin_attribute_head.attribute_kind;

            //未实现其他属性的机制
            
            int active_stat_num = *(ptr + 1);    // 激活、统计的次数
            int succss_realize_num = *(ptr + 2); // 生成、实现的次数

            float rate = succss_realize_num / active_stat_num;

            unsigned int result_id = *(ptr + origin_attribute_head.item_num - 1);

            //文本精度 空间精度 时间精度
            //条件精度 结果精度
            //都可以调
            //但结果一般是固定精度

            if(origin_attribute_head.condition_kind == 2) //图像条件
            {
                //升级(精细化)
                if(rate > 0.5 && origin_attribute_head.attribute_kind == 1  && active_stat_num > 12)
                {
                    Attribute_Head new_attribute_head;
                    new_attribute_head.attribute_kind = 1;
                    new_attribute_head.condition_kind = 2;
                    new_attribute_head.result_kind = 2;

                    Image_Item origin_image_condition = *(Image_Item*)(ptr + 3);

                    char direction_scale = origin_image_condition.direction_scale;
                    char distance_scale = origin_image_condition.distance_scale;

                    Image_Item new_image_item;

                    if(direction_scale > 1)
                        new_image_item.direction_scale = direction_scale - 1;

                    if(distance_scale > 1)
                        new_image_item.distance_scale = distance_scale - 1;

                    //标记已升级，后续不可重复升级
                    new_attribute_head.able_update = 2;

                    vector<General_Condition> general_condition_list;
                    vector<General_Result> general_result_list;

                    simple_neuro_attribute_write(curr_node_id, 0, 1,
                        new_attribute_head, general_condition_list, general_result_list);
                }

                //图像的精细化一般会产生多种条件下的结果，先生成，再根据检验剔除

                //升级(节点化)
                if(rate > 0.8 && origin_attribute_head.attribute_kind != 2 && active_stat_num > 12)
                {
                    Attribute_Head new_attribute_head;
                    new_attribute_head.attribute_kind = 2;
                    new_attribute_head.condition_kind = 2;
                    new_attribute_head.result_kind = 2;

                    Image_Item origin_image_condition = *(Image_Item*)(ptr + 3);

                    char direction_scale = origin_image_condition.direction_scale;
                    char distance_scale = origin_image_condition.distance_scale;

                    Image_Item new_image_condition;

                    //内部方向精确
                    if(direction_scale > 1)
                        new_image_condition.direction_scale = direction_scale - 1;

                    //内部距离精确
                    if(distance_scale > 1)
                        new_image_condition.distance_scale = distance_scale - 1;

                    //遍历演化方向
                    for(int a = 0; a < 2; a++)
                    {
                        direction_scale;
                        origin_image_condition.direction;

                        //
                        for(int b = 0; b < 2; b++)
                        {
                            distance_scale;
                            origin_image_condition.distance;
                        }
                    }


                    //标记已升级，后续不可重复升级
                    new_attribute_head.able_update = 2;

                    vector<General_Condition> general_condition_list;
                    vector<General_Result> general_result_list;

                    neuro_item_delete(curr_node_id, f, origin_attribute_head.item_num);

                    simple_neuro_attribute_write(curr_node_id, 0, 1,
                        new_attribute_head, general_condition_list, general_result_list);
                }

                //降级(删除)
                if(rate < 0.1 && origin_attribute_head.attribute_kind == 1 && active_stat_num > 12)
                {
                    neuro_item_delete(curr_node_id, f, origin_attribute_head.item_num);
                }

                //降级(去节点化)
                if(rate < 0.3 && origin_attribute_head.attribute_kind == 2  && active_stat_num > 12)
                {
                    Attribute_Head new_item_head;
                    new_item_head.attribute_kind = 2;
                    new_item_head.condition_kind = 2;
                    new_item_head.result_kind = 2;

                    Time_Item image_item_II;

                    for(int a = 0; a < origin_attribute_head.condition_num; a++)
                    {
                        image_item_II = *(Time_Item*)(ptr + 3 + 3*a);
                    }
                    
                    vector<General_Condition> general_condition_list;
                    vector<General_Result> general_result_list;

                    neuro_item_delete(curr_node_id, f, new_item_head.item_num);

                    simple_neuro_attribute_write(curr_node_id, 0, 1,
                        new_item_head, general_condition_list, general_result_list);
                }

            } else if(origin_attribute_head.condition_kind == 3) { //时间条件
                
                //升级（精细化）
                if(rate > 0.5 && origin_attribute_head.attribute_kind == 1)
                {
                    Attribute_Head new_attribute_head;
                    new_attribute_head.attribute_kind = 1;
                    new_attribute_head.condition_kind = 2;
                    new_attribute_head.result_kind = 2;

                    Time_Item origin_time_condition;
                    origin_time_condition.time_range;
                    origin_time_condition.time_scale;

                    char time_range = origin_time_condition.time_range;
                    char time_scale = origin_time_condition.time_scale;

                    Time_Item new_time_condition;

                    if(time_range > 1)
                        new_time_condition.time_range = time_range;

                    if(time_scale > 1)
                        new_time_condition.time_scale = time_scale - 1;

                    //标记已升级，后续不可重复升级
                    new_attribute_head.able_update = 2;

                    vector<General_Condition> general_condition_list;
                    vector<General_Result> general_result_list;

                    simple_neuro_attribute_write(curr_node_id, 0, 1,
                        new_attribute_head, general_condition_list, general_result_list);
                }

                //精细化会产生多种条件，先生成，再根据检验剔除


                //升级（节点化）
                if(rate > 0.8 && origin_attribute_head.attribute_kind == 1  && active_stat_num > 20)
                {
                    Attribute_Head new_attribute_head;
                    new_attribute_head.attribute_kind = 2;
                    new_attribute_head.condition_kind = 2;
                    new_attribute_head.result_kind = 2;

                    Time_Item origin_time_condition = *(Time_Item*)(ptr + 3);

                    char time_range = origin_time_condition.time_range;
                    char time_scale = origin_time_condition.time_scale;

                    Time_Item new_image_condition;

                    // //内部方向精确
                    // if(direction_scale > 1)
                    //     new_image_condition.direction_scale = direction_scale - 1;

                    // //内部距离精确
                    // if(distance_scale > 1)
                    //     new_image_condition.distance_scale = distance_scale - 1;

                    //遍历演化方向
                    for(int a = 0; a < 2; a++)
                    {
                        // direction_scale;
                        // origin_time_condition.direction;

                        // //
                        // for(int b = 0; b < 2; b++)
                        // {
                        //     distance_scale;
                        //     origin_time_condition.distance;
                        // }
                    }


                    //标记已升级，后续不可重复升级
                    new_attribute_head.able_update = 2;

                    vector<General_Condition> general_condition_list;
                    vector<General_Result> general_result_list;

                    neuro_item_delete(curr_node_id, f, origin_attribute_head.item_num);

                    simple_neuro_attribute_write(curr_node_id, 0, 1,
                        new_attribute_head, general_condition_list, general_result_list);
                }


                //降级（删除）
                if(rate < 0.4 && origin_attribute_head.attribute_kind == 1  && active_stat_num > 12)
                {
                    neuro_item_delete(curr_node_id, f, origin_attribute_head.item_num);;
                }


                //降级（去节点化）
                if(rate < 0.4 && origin_attribute_head.attribute_kind == 2  && active_stat_num > 30)
                {
                    Attribute_Head new_item_head;
                    new_item_head.attribute_kind = 2;
                    new_item_head.condition_kind = 2;
                    new_item_head.result_kind = 2;

                    Time_Item time_condition;

                    for(int a = 0; a < origin_attribute_head.condition_num; a++)
                    {
                        time_condition = *(Time_Item*)(ptr + 3 + 3*a);
                    }
                    
                    vector<General_Condition> general_condition_list;
                    vector<General_Result> general_result_list;

                    neuro_item_delete(curr_node_id, f, new_item_head.item_num);

                    simple_neuro_attribute_write(curr_node_id, 0, 1,
                        new_item_head, general_condition_list, general_result_list);
                }
                
            } else if(origin_attribute_head.condition_kind == 4) { //文本条件
                
                //升级(精细化)
                if(rate > 0.5 && origin_attribute_head.attribute_kind == 1)
                {
                    Attribute_Head new_attribute_head;
                    new_attribute_head.attribute_kind = 1;
                    new_attribute_head.condition_kind = 3;
                    new_attribute_head.result_kind = 3;

                    Text_Item text_item = *(Text_Item*)(ptr + 3);

                    char distance_scale = text_item.distance_scale;

                    Text_Item new_text_item;

                    if(distance_scale > 1)
                        new_text_item.distance_scale = distance_scale - 1;

                    //生成多种条目结果

                    //标记已升级，后续不可升级
                    new_attribute_head.able_update = 2;

                    vector<General_Condition> general_condition_list;
                    vector<General_Result> general_result_list;

                    simple_neuro_attribute_write(curr_node_id, 0, 1,
                        new_attribute_head, general_condition_list, general_result_list);
                }

                //降级(删除)
                if(rate < 0.1 && origin_attribute_head.attribute_kind == 1)
                {
                    neuro_item_delete(curr_node_id, f, origin_attribute_head.item_num);
                }

                //降级(去节点化)
                if(rate < 0.3 && origin_attribute_head.attribute_kind == 2)
                {
                    Attribute_Head new_item_head;
                    new_item_head.attribute_kind = 1;
                    new_item_head.condition_kind = 3;
                    new_item_head.result_kind = 3;

                    vector<General_Condition> general_condition_list;
                    vector<General_Result> general_result_list;

                    //原条件其实不用改，但没写别的写入函数
                    Text_Item origin_text_condition;

                    for(int a = 0; a < origin_attribute_head.condition_num; a++)
                    {
                        origin_text_condition = *(Text_Item*)(ptr + 3 + 3*a);
                        General_Condition condition = {.text_condition = origin_text_condition};
                        general_condition_list.push_back(condition);
                    }

                    unsigned int delete_id = *(ptr + origin_attribute_head.item_num - 1);
                    
                    neuro_item_delete(curr_node_id, f, new_item_head.item_num);

                    simple_neuro_attribute_write(curr_node_id, 0, 1,
                        new_item_head, general_condition_list, general_result_list);

                    neuro_delete(delete_id);
                }
            }


            first_ptr += origin_attribute_head.item_num;
            f += origin_attribute_head.item_num;
            
        }//连接剔除结束
    }


return generate_node_idx_list;
}
//神经元属性激活函数结束



// 线条 本体特征
struct Line_Object_Feature
{
    unsigned char red; // 自身色彩
    unsigned char green;
    unsigned char blue;

    unsigned char direction; // 朝向方向
    unsigned char length;    // 长度级别
};


// 线段检索结构，对应线段的神经元连接
vector<unsigned int> FULL_ENTER_LINE_SORT;  // r值8个* g值8个* b值8个 * d值16个 * l值16个

// 形态检索结构，对应形态的神经元连接
vector<unsigned int> FORM_ENTER_LINE_SORT;  // d值16个 * l值16个

// 色彩检索结构，对应色彩的神经元连接
vector<unsigned int> COLOUR_ENTER_LINE_SORT;// r值8个* g值8个* b值8个

// 启动文件 转 线段检索结构 函数
void init_image_enter_line()
{
    FULL_ENTER_LINE_SORT.resize(8*8*8*16*16);
    FORM_ENTER_LINE_SORT.resize(16*16);
    COLOUR_ENTER_LINE_SORT.resize(8*8*8);

    FILE *fp = fopen("Record_enter_line.rec", "r");
    if(fp)
    {
        fread(FULL_ENTER_LINE_SORT.data(), (8*8*8*16*16)*4, 1, fp);

        fseek(fp, (8*8*8*16*16)*4, 1);
        fread(FORM_ENTER_LINE_SORT.data(), (16*16)*4, 1, fp);

        fseek(fp, (16*16)*4, 1);
        fread(COLOUR_ENTER_LINE_SORT.data(), (8*8*8)*4, 1, fp);

        fclose(fp);
    }

}
//函数结束


// 保存启动文件
void save_init_line_file()
{
    FILE *fp = fopen("Record_enter_line.rec", "w");
    fwrite(FULL_ENTER_LINE_SORT.data(), (8*8*8*16*16)*4, 1, fp);

    fseek(fp, (8*8*8*16*16)*4, 1);
    fwrite(FORM_ENTER_LINE_SORT.data(), (16*16)*4, 1, fp);

    fseek(fp, (16*16)*4, 1);
    fwrite(COLOUR_ENTER_LINE_SORT.data(), (8*8*8)*4, 1, fp);

    fclose(fp);
}
//函数结束


// 新有色边缘记录函数
void new_colour_line_record(Line_Object curr_line)
{
    // 创建神经元
    unsigned int id = neuro_create(1, 1);

    FULL_ENTER_LINE_SORT[curr_line.red*8*8*16*16 + curr_line.green*8*16*16 +
    curr_line.blue*16*16 + curr_line.length*16 + curr_line.direction] = id;
    
    unsigned int* ptr = node_find(id);

    //神经元描述 未完成
}


// 新边缘形态记录生成函数
void new_line_form_record(char length, char direction)
{
    // 创建神经元
    unsigned int id = neuro_create(12);
    FORM_ENTER_LINE_SORT[length * 16 + direction] = id;
    
    unsigned int* ptr = node_find(id);

    //神经元描述 未完成
}


//单线段节点生成函数
void image_a_line_retrieve_generate(
    uint32_t map_idx, uint32_t exp_idx,
    Line_Object& Line)
{
    Map_Analysis_Scene& top_map = Map_Analysis_Scene_Storage[map_idx];
    Image_Cover_Explain_Network& explain_View = top_map.Image_Cover_Explain_View[exp_idx];
    unsigned short width = explain_View.self_width;

    //线段点添加
    uint32_t add_node_c_idx = create_a_General_Cognition_Node();
    uint32_t add_node_f_idx = create_a_General_Cognition_Node();
    General_Cognition_Node& add_node_c = General_Cognition_Node_Storage[add_node_c_idx];
    General_Cognition_Node& add_node_f = General_Cognition_Node_Storage[add_node_f_idx];

    
    //创建图像数据环节
    create_a_Node_Image_Attribute(add_node_c_idx);
    create_a_Node_Image_Attribute(add_node_f_idx);

    int colour_idx = Line.red * 8 * 8 * 16 * 16 + Line.green * 8 * 16 * 16
        + Line.blue * 16 * 16 + Line.length * 16 + Line.direction;

    int form_idx = Line.length * 16 + Line.direction;

    add_node_c.self_id = FULL_ENTER_LINE_SORT[colour_idx];
    add_node_f.self_id = FORM_ENTER_LINE_SORT[form_idx];

    // 若该条边未记录
    if (add_node_c.self_id == 0)
    {
        new_colour_line_record(Line); // 进行记录

        // 若该形态未记录
        if (add_node_f.self_id == 0)
        {
            new_line_form_record(Line.length, Line.direction);// 进行记录
        }
    }

    // 未存储内存，装入读取任务队列
    if (pack_index_find(add_node_c.self_id) == 0)
    {
        add_to_Will_Read_Neuro_Queue(add_node_c.self_id);
        //加入未读取，准备后续查找
    }

    // 未存储内存，装入读取任务队列
    if (pack_index_find(add_node_f.self_id) == 0)
    {
        add_to_Will_Read_Neuro_Queue(add_node_f.self_id);
    }

    //线段数据写入
    Node_Image_Attribute node_image_c_attribute;
    node_image_c_attribute.block_num = Line.block_num;
    node_image_c_attribute.x = Line.middle_coordinate.x;
    node_image_c_attribute.y = Line.middle_coordinate.y;

    Node_Image_Attribute node_image_f_attribute;
    node_image_f_attribute.block_num = Line.block_num;
    node_image_f_attribute.x = Line.middle_coordinate.x;
    node_image_f_attribute.y = Line.middle_coordinate.y;

    top_map.Id_Find_Index[add_node_c.self_id].push_back(add_node_c_idx);

    top_map.Id_Find_Index[add_node_f.self_id].push_back(add_node_f_idx);

    Image_Cover_Node_Network& Storage_View = top_map.Image_Cover_Node_View;

    int Retrieval_distance = Storage_View.record_distance;
    int general_idx = Line.middle_coordinate.y / Retrieval_distance*width +
    Line.middle_coordinate.x / Retrieval_distance;

    Storage_View.Image_Node_Idx_Record[general_idx].push_back(add_node_c_idx);
    Storage_View.Image_Node_Idx_Record[general_idx].push_back(add_node_f_idx);
}
//线段节点生成函数结束


//自然注意力区域生成函数，图像差异标注
void map_nature_attention_generate(
    uint32_t last_Map_idx, uint32_t current_Map_idx)
{
    Map_Analysis_Scene& last_Map = Map_Analysis_Scene_Storage[last_Map_idx];
    Map_Analysis_Scene& current_Map = Map_Analysis_Scene_Storage[current_Map_idx];

    //注意力值图
    current_Map.Block_Attention_List.reserve(5);
    
    // 1、原图相关图像注意生成
    unsigned short curr_width = current_Map.width;
    unsigned short curr_height = current_Map.height;

    Rigion_Value_Stat basic;
    basic.width_unit_size = 1;
    basic.width = curr_width;
    basic.height_unit_size = 1;
    basic.height = curr_height;
    basic.attention_unit_list.resize( curr_width*curr_height );
    

    auto* last_rgb_ptr = last_Map.RGB_Map.data();
    auto* curr_rgb_ptr = current_Map.RGB_Map.data();

    auto* last_att_ptr = last_Map.Block_Attention_List[0].attention_unit_list.data();
    auto* curr_att_ptr = basic.attention_unit_list.data();
    int total_att = 0;

    if(current_Map.is_lock_occupy)
        return;

    //依据 惯性注意力与变动注意力
    for(int n=0; n <last_Map.RGB_Map.size(); n++)
    {
        int att = last_att_ptr[n];

        //图像前后变化程度比对
        int diff_r = last_rgb_ptr[n].r - curr_rgb_ptr[n].r;
        int diff_g = last_rgb_ptr[n].g - curr_rgb_ptr[n].g;
        int diff_b = last_rgb_ptr[n].b - curr_rgb_ptr[n].b;

        diff_r = (diff_r >= 0 ? diff_r : -diff_r);
        diff_g = (diff_g >= 0 ? diff_g : -diff_g);
        diff_b = (diff_b >= 0 ? diff_b : -diff_b);

        int diff_strength = (diff_r + diff_g + diff_b)/16; // 0~45
        att = att/2 + diff_strength;

        total_att += att;
        curr_att_ptr[n] = att;//继承和判断
    }

    current_Map.sum_nature_attention = total_att;
    current_Map.Block_Attention_List.push_back(basic);

    // 2、区块注意力缩略统和
    vector<unsigned short> width_s(5);
    vector<unsigned short> height_s(5);

    width_s[0] = curr_width;
    height_s[0] = curr_height;

    char count_a = 1;

    //去除大尺寸屏幕，
    while(curr_width > 1920 || curr_height > 1080)
    {
        ;//压缩 至 合适尺寸
    }

    //1920*1080 (1)，960*540 (2)，480*270 (4)，240*135(8)否
    while(curr_width > 480 && curr_height > 270 && count_a < 5)
    {
        curr_height = curr_height / 2;
        curr_width = curr_width / 2;
        width_s[count_a] = curr_width;
        height_s[count_a] = curr_height;
        count_a += 1;
    }
    //未适用其他屏幕的尺寸


    //遍历生成注意力
    for(int a = 1; a < width_s.size(); a++)
    {
        //填入基础值
        Rigion_Value_Stat RVS;
        RVS.width = width_s[a];
        RVS.width_unit_size = current_Map.width / RVS.width;
        RVS.height = height_s[a];
        RVS.height_unit_size = current_Map.height / RVS.height;
        RVS.attention_unit_list.resize(RVS.width * RVS.height);

        current_Map.Block_Attention_List.push_back(RVS);

        Rigion_Value_Stat& target_area = current_Map.Block_Attention_List[a];
        target_area.attention_unit_list.resize(target_area.width * target_area.height);
        Rigion_Value_Stat& origin_area = current_Map.Block_Attention_List[a - 1];

        //将原坐标值映射到新坐标
        auto& origin_unit_attention_list = target_area.attention_unit_list;
        auto& target_unit_attention_list = origin_area.attention_unit_list;
        int origin_width = origin_area.width;
        int target_width = target_area.width;

        int origin_idx = 0;
        int target_idx = 0;
        int origin_y = 0;
        int target_x = 0;

        int target_unit_num = target_area.attention_unit_list.size();
        int size_occupy_height = target_area.height_unit_size / origin_area.height_unit_size;
        int size_occupy_width = target_area.width_unit_size / origin_area.width_unit_size;
        int gap_idx = size_occupy_height * origin_width;

        int origin_left_idx = 0;
        int origin_const_left_idx = 0;
        int origin_right_idx;
        int origin_top = size_occupy_height;

        //将原坐标值映射到新坐标
        while (target_idx < target_unit_num)
        {
            origin_left_idx = origin_const_left_idx;
            origin_right_idx = origin_left_idx + size_occupy_width;

            origin_idx = origin_left_idx;

            //遍历·本块
            while(origin_y <= origin_top)
            {
                //注意力求和
                origin_unit_attention_list[target_idx]
                += target_unit_attention_list[origin_idx];

                origin_idx += 1;

                if(origin_idx == origin_right_idx)
                {
                    origin_y += 1;
                    origin_left_idx += origin_width;
                    origin_idx = origin_left_idx;
                    origin_right_idx += origin_width;
                }
            }

            //选择下一个块
            target_idx += 1;
            target_x += 1;
            origin_const_left_idx += size_occupy_width;

            if(target_x == target_width)
            {
                origin_const_left_idx += gap_idx;
                origin_top += size_occupy_height;
                target_x = 0;
            }

        }//一个图遍历完成

    }//全部图遍历完成，区块注意力统和结束


}//自然注意力区域生成函数 结束


//解释视角生成函数
void map_explain_view_generate(
    uint32_t current_Map_idx, char standard_size)
{
    Map_Analysis_Scene& curr_map = Map_Analysis_Scene_Storage[current_Map_idx];

    // 1、生成粗粒化视图
    
    //选取原图
    unsigned char suit_one = standard_size / 2;
    char choose_idx = -1;
    char quit = 0;
    int history_choose;

    for(int i = 0; i < curr_map.Image_Cover_Explain_View.size(); i++)
    {
        int history_diff;
        int diff = standard_size - curr_map.Image_Cover_Explain_View[i].standard_size;

        if(diff >= suit_one)
        {
            if( diff < history_diff )
            {
                history_diff = diff;
                choose_idx = i;
            }

            if( diff == suit_one )//若接取
            choose_idx = i;

        } else if (diff == 0)
            quit = 1;
    }

    if(quit = 1)//若有同等视角取消
        return;

    unsigned short from_width = curr_map.Image_Cover_Explain_View[choose_idx].self_width;
    unsigned short from_height = curr_map.Image_Cover_Explain_View[choose_idx].self_height;
    vector<Image_Cover_Explain_Block> From_Cover_Block_List = curr_map.Image_Cover_Explain_View[choose_idx].Cover_Block_List;
    //原图选取结束


    unsigned short origin_width = curr_map.width;
    unsigned short origin_height = curr_map.height;
    vector<RGB_Unit>& origin_rgb_map = curr_map.RGB_Map;

    Image_Cover_Explain_Network generate_view;
    generate_view.standard_size = standard_size;
    generate_view.colour_number_distribution.assign(512, 0); // 8*8*8
    vector<int>& colour_number_distribution = generate_view.colour_number_distribution;

    int target_width = origin_width / standard_size;
    int target_height = origin_height / standard_size;
    generate_view.self_width = target_width;
    generate_view.self_height = target_height;

    generate_view.Cover_Block_List.resize( origin_width*origin_height );

    auto& Cover_Block_List = generate_view.Cover_Block_List;

    long size = generate_view.self_width * generate_view.self_height;


    //填入基础值

    //将原坐标值映射到新坐标
    int origin_idx = 0;
    int target_idx = 0;
    int origin_y = 0;
    int target_x = 0;

    int target_unit_num = Cover_Block_List.size();
    int size_occupy_height = from_height / target_height;
    int size_occupy_width = from_width / target_width;
    int gap_idx = size_occupy_height * origin_width;

    int origin_left_idx = 0;
    int origin_const_left_idx = 0;
    int origin_right_idx;
    int origin_top = size_occupy_height;

    int sum_r = 0;
    int sum_g = 0;
    int sum_b = 0;
    unsigned char ave_r;
    unsigned char ave_g;
    unsigned char ave_b;

    int size_block_num = size_occupy_height*size_occupy_width;

    //将原坐标值映射到新坐标
    while (target_idx < target_unit_num)
    {
        origin_left_idx = origin_const_left_idx;
        origin_right_idx = origin_left_idx + size_occupy_width;

        origin_idx = origin_left_idx;

        //遍历·本块
        while(origin_y <= origin_top)
        {
            Image_Cover_Explain_Block& origin_block
            = From_Cover_Block_List[origin_idx];

            //色彩力求值
            sum_b += origin_block.ave_b;
            sum_g += origin_block.ave_g;
            sum_r += origin_block.ave_r;

            origin_idx += 1;

            if(origin_idx == origin_right_idx)
            {
                origin_y += 1;
                origin_left_idx += origin_width;
                origin_idx = origin_left_idx;
                origin_right_idx += origin_width;
            }
        }

        //色彩力求均
        auto& target_block = Cover_Block_List[target_idx];
        ave_r = sum_r / size_block_num;
        ave_g = sum_g / size_block_num;
        ave_b = sum_b / size_block_num;
        target_block.ave_r = ave_r;
        target_block.ave_g = ave_g;
        target_block.ave_b = ave_b;

        colour_number_distribution[ave_r*64 + ave_g*8 + ave_b] += 1;

        //选择下一个块
        target_idx += 1;
        target_x += 1;
        origin_const_left_idx += size_occupy_width;

        sum_b = 0;
        sum_g = 0;
        sum_r = 0;

        if(target_x == from_width)
        {
            origin_const_left_idx += gap_idx;
            origin_top += size_occupy_height;
            target_x = 0;
        }

    }//一个图遍历完成

    // 2、区块预处理 区块属性生成

    uint32_t att_idx = 0;
    
    //选取注意力图
    while(curr_map.Block_Attention_List[att_idx].height_unit_size != standard_size &&
        curr_map.Block_Attention_List[att_idx].width_unit_size != standard_size)
    {
        att_idx++;

        if(curr_map.Block_Attention_List.size() <= att_idx)
            ;//没有相关大小的注意力图，当前图像应该要是已生成自然注意力的
    }

    vector<int>& attention_unit_list = curr_map.Block_Attention_List[att_idx].attention_unit_list;

    int origin_pos = 0;

    // 确定区块属性
    for (int y = 0; y < target_height; y++)
    {
        for (int x = 0; x < target_width; x++)
        {
            unsigned char r, g, b;
            auto& origin_block = Cover_Block_List[origin_pos];
            origin_block.proc_stage = 1;

            r = origin_block.ave_r;
            g = origin_block.ave_g;
            b = origin_block.ave_b;

            unsigned char neighbor_r;
            unsigned char neighbor_g;
            unsigned char neighbor_b;

            auto& diff_colour = origin_block.diff_colour;
            auto& edge_kind = origin_block.proc_stage;
            auto& block_attention = attention_unit_list[origin_pos];
            auto& unexplain_line = origin_block.unexplain_line;

            // 左
            if (x > 0)
            {
                auto neighbor_block = Cover_Block_List[origin_pos - 1];
                neighbor_r = neighbor_block.ave_r;
                neighbor_g = neighbor_block.ave_g;
                neighbor_b = neighbor_block.ave_b;

                if (abs(r - neighbor_r) > 32
                    || abs(g - neighbor_g) > 32
                    || abs(b - neighbor_b) > 32)
                {
                    diff_colour |= (1 << 4);
                    edge_kind = 2;
                    block_attention += 15;
                }
            }

            // 右
            if (x < target_width-1)
            {
                auto neighbor_block = Cover_Block_List[origin_pos + 1];
                neighbor_r = neighbor_block.ave_r;
                neighbor_g = neighbor_block.ave_g;
                neighbor_b = neighbor_block.ave_b;

                if (abs(r - neighbor_r) > 32
                    || abs(g - neighbor_g) > 32
                    || abs(b - neighbor_b) > 32)
                {
                    diff_colour |= (1 << 0);
                    edge_kind = 2;
                    block_attention += 15;
                }
            }

            // 上
            if (y > 0)
            {
                auto neighbor_block = Cover_Block_List[origin_pos - target_width];
                neighbor_r = neighbor_block.ave_r;
                neighbor_g = neighbor_block.ave_g;
                neighbor_b = neighbor_block.ave_b;

                if (abs(r - neighbor_r) > 32
                    || abs(g - neighbor_g) > 32
                    || abs(b - neighbor_b) > 32)
                {
                    diff_colour |= (1 << 2);
                    edge_kind = 2;
                    block_attention += 15;
                }
            }

            // 下
            if (y < target_height - 1)
            {
                auto neighbor_block = Cover_Block_List[origin_pos + target_width];
                neighbor_r = neighbor_block.ave_r;
                neighbor_g = neighbor_block.ave_g;
                neighbor_b = neighbor_block.ave_b;

                if (abs(r - neighbor_r) > 32
                    || abs(g - neighbor_g) > 32
                    || abs(b - neighbor_b) > 32)
                {
                    diff_colour |= (1 << 6);
                    edge_kind = 2;
                    block_attention += 15;
                }
            }

            // 左上
            if (x>0 && y>0 )
            {
                auto neighbor_block = Cover_Block_List[origin_pos - target_width - 1];
                neighbor_r = neighbor_block.ave_r;
                neighbor_g = neighbor_block.ave_g;
                neighbor_b = neighbor_block.ave_b;

                if (abs(r - neighbor_r) > 32
                    || abs(g - neighbor_g) > 32
                    || abs(b - neighbor_b) > 32)
                {
                    diff_colour |= (1 << 3);
                    edge_kind = 2;
                    block_attention += 10;
                }
            }

            // 右上
            if ( x <target_width-1 && y>0 )
            {
                auto neighbor_block = Cover_Block_List[origin_pos - target_width + 1];
                neighbor_r = neighbor_block.ave_r;
                neighbor_g = neighbor_block.ave_g;
                neighbor_b = neighbor_block.ave_b;

                if (abs(r - neighbor_r) > 32
                    || abs(g - neighbor_g) > 32
                    || abs(b - neighbor_b) > 32)
                {
                    diff_colour |= (1 << 1);
                    edge_kind = 2;
                    block_attention += 10;
                }
            }

            // 左下
            if ( x>0 && y <target_height-1 )
            {
                auto neighbor_block = Cover_Block_List[origin_pos + target_width - 1];
                neighbor_r = neighbor_block.ave_r;
                neighbor_g = neighbor_block.ave_g;
                neighbor_b = neighbor_block.ave_b;

                if (abs(r - neighbor_r) > 32
                    || abs(g - neighbor_g) > 32
                    || abs(b - neighbor_b) > 32)
                {
                    diff_colour |= (1 << 5);
                    edge_kind = 2;
                    block_attention += 10;
                }
            }

            // 右下
            if ( x <target_width-1 && y <target_height-1 )
            {
                auto neighbor_block = Cover_Block_List[origin_pos + target_width + 1];
                neighbor_r = neighbor_block.ave_r;
                neighbor_g = neighbor_block.ave_g;
                neighbor_b = neighbor_block.ave_b;

                if (abs(r - neighbor_r) > 32
                    || abs(g - neighbor_g) > 32
                    || abs(b - neighbor_b) > 32)
                {
                    diff_colour |= (1 << 7);
                    edge_kind = 2;
                    block_attention += 10;
                }
            }

            origin_pos += 1;

        } // x结束
    } // y结束

    generate_view.is_init = 1;

    // 区块属性生成结束

    curr_map.Image_Cover_Explain_View.push_back(generate_view);

}//边界拟合函数结束


//图需求生成函数
void init_map_require(
    uint32_t current_Map_idx, vector< vector<int> >& require_list,
    char require_kind,//检索是1
    char base_value = 10)
{
    Map_Analysis_Scene& curr_map = Map_Analysis_Scene_Storage[current_Map_idx];
    int height = curr_map.height;
    int width = curr_map.width;

    int need_height_size = height;
    int need_width_size = width;

    int need_height_layer = 0;
    int need_width_layer = 0;

    while(need_height_size >= 8)// 计算所需层数
    {
        need_height_size /= 8;
        need_height_layer += 1;
    }

    while(need_width_size >= 8)// 计算所需层数
    {
        need_width_size /= 8;
        need_width_layer += 1;
    }

    bool high_or_wight_bigger = 0;
    int chose_calcul_value;
    int need_layer;

    if(need_height_layer > need_width_layer)
    {
        require_list.resize(need_height_layer);
        high_or_wight_bigger = 1;
        need_layer = need_height_layer;
        chose_calcul_value  = need_height_size;
    } else {
        require_list.resize(need_width_layer);
        high_or_wight_bigger = 2;
        need_layer = need_width_layer;
        chose_calcul_value  = need_width_size;
    }

    //填入基础值 复制注意力
    if(require_kind == 1)
    {
        require_list[0].resize(width * height);
        require_list[0] = curr_map.Block_Attention_List[0].attention_unit_list;

    } else {
        require_list[0].assign(width * height, base_value);
    }
    
    int origin_width = width;
    int origin_height = height;
    int target_width = width;
    int target_height = height;

    int target_stat_idx = 0;

    int width_more_value = 0;
    int height_more_value = 0;

    int origin_width_limit;
    int origin_heigth_limit;

    bool have_right_more = 0;
    bool have_top_more = 0;

    //处理汇总
    while(target_stat_idx < need_layer)
    {
        chose_calcul_value /= 8;

        target_stat_idx += 1;
        origin_width = target_width;

        if(target_width >= 8)
        {
            width_more_value = target_width % 8;
            if(width_more_value > 0)
            {
                target_width /= 8;
                origin_width_limit = target_width*8;
                target_width += 1; //余数处理
            }
            else target_width /= 8;
        }
        else target_width = 1;

        origin_height = target_height;
        if(target_height >= 8)
        {
            height_more_value = target_height % 8;
            if(height_more_value > 0)
            {
                target_height /= 8;
                origin_heigth_limit = target_height*8 ;
                target_height += 1;
            }
            else target_height /= 8;
        }
        else target_height = 1;
        

        vector<int>& target_stat = require_list[target_stat_idx];
        
        target_stat.resize(target_width * target_height);
        vector<int>& origin_stat = require_list[target_stat_idx - 1];


        //将原坐标值映射到新坐标
        int origin_idx = 0;
        int target_idx = 0;
        int origin_y = 0;
        int origin_x = 0;
        int target_x = 0;

        int target_unit_num = target_stat.size();
        int size_occupy_height = 8;
        int size_occupy_width = 8;
        int gap_idx = size_occupy_height * origin_width;

        int origin_left_idx = 0;
        int origin_const_left_idx = 0;
        int origin_right_idx;
        int origin_top = size_occupy_height;

        //将原坐标值映射到新坐标
        while (target_idx < target_unit_num)
        {
            origin_left_idx = origin_const_left_idx;

            if(width_more_value  && origin_x == origin_width_limit) // 右界
            {
                origin_right_idx = origin_left_idx + width_more_value;
                have_right_more = 1;
            }
            else origin_right_idx = origin_left_idx + size_occupy_width;

            origin_idx = origin_left_idx;

            //遍历本块
            if(have_right_more == 0 && have_top_more == 0) //完整块
            {
                while(origin_y <= origin_top)
                {
                    //检索力求和
                    target_stat[target_idx] += origin_stat[origin_idx];

                    origin_idx += 1;

                    if(origin_idx == origin_right_idx)
                    {
                        origin_y += 1;
                        origin_left_idx += origin_width;
                        origin_idx = origin_left_idx;
                        origin_right_idx += origin_width;
                    }
                }

            } else {//余数块

                while(origin_y <= origin_top)
                {
                    //检索需求求和
                    target_stat[target_idx] += origin_stat[origin_idx];

                    origin_idx += 1;

                    if(origin_idx == origin_right_idx)
                    {
                        if(have_right_more == 0)
                        {
                            origin_y += 1;
                            origin_left_idx += origin_width;
                            origin_idx = origin_left_idx;
                            origin_right_idx += width_more_value; // 改动
                        }
                    }
                }
            }

            //选择下一个块
            target_idx += 1;
            target_x += 1;
            origin_const_left_idx += size_occupy_width;
            have_right_more = 0;
            
            if(target_x == target_width)
            {
                origin_const_left_idx += gap_idx;

                if(width_more_value && origin_top == origin_heigth_limit)
                {
                    origin_top += height_more_value;
                    have_top_more = 1;
                }
                else origin_top += size_occupy_height;

                target_x = 0;
            }

        }//一层需求遍历完成

    }//需求汇总生成完毕

    //计算总需求度
    char max_idx = require_list.size() - 1;
    auto& max_retrieval_require_list = require_list[max_idx];
    int max_size = require_list[max_idx].size();
    int total_retrieval_require = 0;

    for(int a = 0; a < max_size; a++)
        total_retrieval_require += max_retrieval_require_list[a];

    curr_map.sum_retrieve_require = total_retrieval_require;

}

//视觉需要一个观测的起始点位
//
void observation_judge(
    uint32_t map_idx, uint32_t exp_idx, 
    int& return_x, int& return_y)
{
    //1、以色彩为目的 搜索
        //最大色彩与最大注意力权重色彩(不去导致为0)
    //2、以空间为目的 搜索
        //均衡起始点
    //3、以对象为目的 搜索
        //旧对象传播关注
    //4、以形体连续性为目的 搜索
        //判断此刻的注意力
    
    //未加入注意力的色彩空间均衡
    Map_Analysis_Scene& curr_map = Map_Analysis_Scene_Storage[map_idx];
    Image_Cover_Explain_Network& explain_View = curr_map.Image_Cover_Explain_View[exp_idx];

    random_device Colour_RD;
    mt19937 Colour_Gen(Colour_RD());

    discrete_distribution<int> colour_dist(explain_View.colour_number_distribution.begin(),
        explain_View.colour_number_distribution.end() );
    
    int colour_chose = colour_dist(Colour_Gen);

    return_x = explain_View.colour_x_distribution[colour_chose] / explain_View.colour_number_distribution[colour_chose];
    return_y = explain_View.colour_y_distribution[colour_chose] / explain_View.colour_number_distribution[colour_chose];
}



//线段价值评测函数
void line_appraise(
    Line_Object& curr_line)
{
    int point_number = curr_line.Inside_Point.size() ;

    point_2d begin_point = curr_line.base_point;

    float ave_x = (curr_line.x_sum - begin_point.x*point_number) / point_number; // x均值
    float ave_y = (curr_line.y_sum - begin_point.y*point_number) / point_number; // y均值 相对于初始坐标的误差

    int dx = (begin_point.x - ave_x)*2;
    int dy = (begin_point.y - ave_y)*2;

    char gradient = fast_dir( ave_x - begin_point.x, ave_y - begin_point.y);

    curr_line.direction = gradient;
    curr_line.length = sqrt(dx*dx + dy*dy);
    curr_line.block_num = point_number;

    float abs_diff_value = 0; //误差量
    float sum_diff_value = 0;

    // 计算拟合奖励率
    if(ave_y != 0)
    {
        float slope = ave_y/ave_x;

        for (int i = 0; i < point_number; i++)
        {
            point_2d this_point = curr_line.Inside_Point[i];
            float dif_value = this_point.y - slope*this_point.x;
            if( dif_value> 0.6) {
                abs_diff_value += dif_value;
                sum_diff_value += dif_value;

            } if ( dif_value< -0.6) {
                abs_diff_value += -dif_value;
                sum_diff_value += dif_value;
            }
        }

    } else {//防止slope为0

        for (int i = 0; i < point_number; i++)
        {
            point_2d this_point = curr_line.Inside_Point[i];
            float dif_value = this_point.y - ave_y;
            if( dif_value> 0.6) {
                abs_diff_value += dif_value;
                sum_diff_value += dif_value;

            } if ( dif_value< -0.6) {
                abs_diff_value += -dif_value;
                sum_diff_value += dif_value;
            }
        }
    }

    char reward_level;

    if(gradient%4 == 0)
        reward_level = 10;
    else if(gradient%4 == 2)
        reward_level = 9;
    else if(gradient%4 == 1 || gradient%4 == 3)
        reward_level = 8;


    curr_line.abs_diff_value = abs_diff_value;
    curr_line.ave_diff_rate = abs_diff_value / point_number;
    curr_line.reward_rate = (1 - (curr_line.ave_diff_rate)) * reward_level;
    curr_line.reward_value = curr_line.reward_rate * curr_line.block_num;
}
//结束函数


// 线段相似性鉴定函数
float line_similarity_dectect(Line_Object_Feature a, Line_Object_Feature b)
{
    float similarity = ( abs(a.red - b.red) + abs(a.green - b.green) + abs(a.blue - b.blue) // 0~21
        + abs(a.direction - b.direction) + abs(a.length - b.length) );  // 0~30
    
    similarity = 1 - (similarity / 51);

    return similarity;
}



//线段延伸单点检测函数
void line_single_extend(
    vector<point_2d>& return_result, vector<uint32_t>& return_index, vector<char>& return_direction, 
    uint32_t exp_idx, uint32_t map_idx,
    int x0, int y0)
{
    Map_Analysis_Scene& curr_map = Map_Analysis_Scene_Storage[map_idx];
    Image_Cover_Explain_Network& explain_View = curr_map.Image_Cover_Explain_View[exp_idx];

    int width = explain_View.self_width;
    int height = explain_View.self_height;
    int origin_idx = x0 + y0*width;
    vector<Image_Cover_Explain_Block>& Cover_Block_List = explain_View.Cover_Block_List;
    return_result.clear();
    return_index.clear();
    return_direction.clear();

    // 左直线检测
    if (x0 > 0)
    {
        int target_index = origin_idx - 1;
        Image_Cover_Explain_Block& Target_Block = Cover_Block_List[target_index];

        if ( Target_Block.proc_stage == 2
            && ( (Target_Block.diff_colour >> 4) & 1) != 1)
        {
            point_2d add_point;
            add_point.x = (x0 - 1);
            add_point.y = y0;
            return_result.push_back(add_point);
            return_index.push_back(target_index);
        }
    } //左直线检测结束

    // 上直线检测
    if (y0 > 0)
    {
        int target_index = origin_idx - width;
        Image_Cover_Explain_Block& Target_Block = Cover_Block_List[target_index];

        if ( Cover_Block_List[target_index].proc_stage == 2
            && ( (Cover_Block_List[origin_idx].diff_colour >> 2) & 1) != 1)
        {
            point_2d add_point;
            add_point.x = x0;
            add_point.y = (y0 - 1);
            return_result.push_back(add_point);
            return_index.push_back(target_index);
        }
    } //上直线检测结束

    // 左上斜线检测
    if (x0 > 0 && y0 > 0)
    {
        int target_index = origin_idx - width - 1;
        Image_Cover_Explain_Block& Target_Block = Cover_Block_List[target_index];

        if (Cover_Block_List[target_index].proc_stage == 2
            && ((Cover_Block_List[origin_idx].diff_colour >> 3) & 1) != 1)
        {
            point_2d add_point;
            add_point.x = (x0 - 1);
            add_point.y = (y0 - 1);
            return_index.push_back(target_index);
        }
    }// 左上斜线检测结束

    // 右上斜线检测
    if (x0 > 0 && y0 < height - 1)
    {
        int target_index = origin_idx - width + 1;
        Image_Cover_Explain_Block& Target_Block = Cover_Block_List[target_index];

        if (Cover_Block_List[target_index].proc_stage == 2
            && ((Cover_Block_List[origin_idx].diff_colour >> 1) & 1) != 1)
        {
            point_2d add_point;
            add_point.x = (x0 + 1);
            add_point.y = (y0 - 1);
            return_result.push_back(add_point);
            return_index.push_back(target_index);
        }
    }// 右上斜线检测结束

    // 右直线检测
    if (x0 < width - 1)
    {
        int target_index = origin_idx + 1;
        Image_Cover_Explain_Block& Target_Block = Cover_Block_List[target_index];

        if ( Target_Block.proc_stage == 2
            && ( (Target_Block.diff_colour >> 0) & 1) != 1)
        {
            point_2d add_point;
            add_point.x = (x0 + 1);
            add_point.y = y0;
            return_result.push_back(add_point);
            return_index.push_back(target_index);
        }
    } //右直线检测结束

    // 下直线检测
    if (y0 < height - 1)// 垂直线段构造
    {
        int target_index = origin_idx + width;
        Image_Cover_Explain_Block& Target_Block = Cover_Block_List[target_index];

        if ( Target_Block.proc_stage == 2
            && ( (Target_Block.diff_colour >> 6) & 1) != 1)
        {
            point_2d add_point;
            add_point.x = x0;
            add_point.y = (y0 + 1);
            return_result.push_back(add_point);
            return_index.push_back(target_index);
        }
    }//下直线检测结束

    // 左下斜线检测
    if (x0 < width && y0 < height - 1)// 线段构造
    {
        int target_index = origin_idx + width - 1;
        Image_Cover_Explain_Block& Target_Block = Cover_Block_List[target_index];

        if (Target_Block.proc_stage == 2
            && ((Target_Block.diff_colour >> 5) & 1) != 1)
        {
            point_2d add_point;
            add_point.x = (x0 - 1);
            add_point.y = (y0 + 1);
            return_result.push_back(add_point);
            return_index.push_back(target_index);
        }
    }// 左下斜线检测结束

    // 右下斜线检测
    if (x0 > 0 && y0 < height - 1)// 线段构造
    {
        int target_index = origin_idx + width + 1;
        Image_Cover_Explain_Block& Target_Block = Cover_Block_List[target_index];

        if (Target_Block.proc_stage == 2
            && ((Target_Block.diff_colour >> 7) & 1) != 1)
        {
            point_2d add_point;
            add_point.x = (x0 + 1);
            add_point.y = (y0 + 1);
            return_result.push_back(add_point);
            return_index.push_back(target_index);
        }
    }// 右下斜线检测结束

}
//函数结束


//主动线段拟合
//线段固定方向延展函数
void line_fixed_extend(
    vector<point_2d>& return_result,
    uint32_t exp_idx, uint32_t map_idx,
    int x0, int y0, char extend_direction)
{
    Map_Analysis_Scene& curr_map = Map_Analysis_Scene_Storage[map_idx];
    Image_Cover_Explain_Network& explain_View = curr_map.Image_Cover_Explain_View[exp_idx];

    int width = explain_View.self_width;
    int height = explain_View.self_height;
    vector<Image_Cover_Explain_Block>& Cover_Block_List = explain_View.Cover_Block_List;
    int origin_index = width * y0 + x0;
    return_result.clear();

    char turn_on = 1;

    while(turn_on)
    {
        switch(extend_direction)//重改
        {
            case 4:
                // 左直线检测
                if (x0 > 0)
                {
                    int target_index = origin_index - 1;

                    if ( Cover_Block_List[target_index].proc_stage == 2
                        && ( (Cover_Block_List[origin_index].diff_colour >> 4) & 1) != 1)
                    {
                        point_2d add_point;
                        add_point.x = (x0 - 1);
                        add_point.y = y0;
                        return_result.push_back(add_point);
                    } else turn_on = 0;
                } else turn_on = 0;
                break;//左直线检测结束

            case 2:
                // 上直线检测
                if (y0 > 0)
                {
                    int target_index = origin_index - width;

                    if ( Cover_Block_List[target_index].proc_stage == 2
                        && ( (Cover_Block_List[origin_index].diff_colour >> 2) & 1) != 1)
                    {
                        point_2d add_point;
                        add_point.x = x0;
                        add_point.y = (y0 - 1);
                        return_result.push_back(add_point);
                    } else turn_on = 0;
                } else turn_on = 0;
                break;//上直线检测结束

            case 3:
                // 左上斜线检测
                if (x0 > 0 && y0 > 0)
                {
                    int target_index = origin_index - width - 1;

                    if (Cover_Block_List[target_index].proc_stage == 2
                        && ((Cover_Block_List[origin_index].diff_colour >> 3) & 1) != 1)
                    {
                        point_2d add_point;
                        add_point.x = (x0 - 1);
                        add_point.y = (y0 - 1);
                        return_result.push_back(add_point);
                    } else turn_on = 0;
                } else turn_on = 0;
                break;// 左上斜线检测结束

            case 1:
                // 右上斜线检测
                if (x0 > 0 && y0 < height - 1)
                {
                    int target_index = origin_index - width + 1;

                    if (Cover_Block_List[target_index].proc_stage == 2
                        && ((Cover_Block_List[origin_index].diff_colour >> 1) & 1) != 1)
                    {
                        point_2d add_point;
                        add_point.x = (x0 + 1);
                        add_point.y = (y0 - 1);
                        return_result.push_back(add_point);
                    } else turn_on = 0;
                } else turn_on = 0;
                break;// 右上斜线检测结束

            case 0:
                // 右直线检测
                if (x0 < width - 1)
                {
                    int target_index = origin_index + 1;

                    if ( Cover_Block_List[target_index].proc_stage == 2
                        && ( (Cover_Block_List[origin_index].diff_colour >> 0) & 1) != 1)
                    {
                        point_2d add_point;
                        add_point.x = (x0 + 1);
                        add_point.y = y0;
                        return_result.push_back(add_point);
                    } else turn_on = 0;
                } else turn_on = 0;
                break;//右直线检测结束

            case 6:
                // 下直线检测
                if (y0 < height - 1)// 垂直线段构造
                {
                    int target_index = origin_index + width;

                    if ( Cover_Block_List[target_index].proc_stage == 2
                        && ( (Cover_Block_List[origin_index].diff_colour >> 6) & 1) != 1)
                    {
                        point_2d add_point;
                        add_point.x = x0;
                        add_point.y = (y0 + 1);
                        return_result.push_back(add_point);
                    } else turn_on = 0;
                } else turn_on = 0;
                break;//下直线检测结束

            case 5:
                // 左下斜线检测
                if (x0 < width && y0 < height - 1)// 线段构造
                {
                    int target_index = origin_index + width - 1;

                    if (Cover_Block_List[target_index].proc_stage == 2
                        && ((Cover_Block_List[origin_index].diff_colour >> 5) & 1) != 1)
                    {
                        point_2d add_point;
                        add_point.x = (x0 - 1);
                        add_point.y = (y0 + 1);
                        return_result.push_back(add_point);
                    } else turn_on = 0;
                } else turn_on = 0;
                break;// 左下斜线检测结束

            case 7:
                // 右下斜线检测
                if (x0 > 0 && y0 < height - 1)// 线段构造
                {
                    int target_index = origin_index + width + 1;

                    if (Cover_Block_List[target_index].proc_stage == 2
                        && ((Cover_Block_List[origin_index].diff_colour >> 7) & 1) != 1)
                    {
                        point_2d add_point;
                        add_point.x = (x0 + 1);
                        add_point.y = (y0 + 1);
                        return_result.push_back(add_point);
                    } else turn_on = 0;
                } else turn_on = 0;
                break;// 右下斜线检测结束
        }
    }
}
//函数结束


//主动线段拟合函数 未完成
void line_initiative_fit(
    uint32_t map_idx, uint32_t exp_idx,
    int x0, int y0, // 出发点
    char direction // 方向
){}

//主动线段搜索函数

//主动形态搜索函数
void line_initiative_fit_II(
   uint32_t exp_idx, uint32_t map_idx,
    unsigned char length, //长度
    char direction // 方向
){}



/*锛屾墦鍊掍笘鐣屾繁灞傛斂搴滐紝鍏ㄤ汉绫诲喅涓嶆帴鍙楅《灞傜簿鑻辩殑濂村焦*/




//基本内存清理流程，未完成
void time_out_clean()
{
    for(int d = 0 ; d < General_Cognition_Scene_Storage.size(); d++)
    {
        // General_Cognition_Scene;
    }

    for(int b = 0 ;b < Text_Inference_Scene_Storage.size(); b++)
    {
        if(Text_Inference_Scene_Storage[b].text_derive_attention < 10
            || Text_Inference_Scene_Storage[b].input_time > 60000)
            clear_a_Text_Inference(b);
    }

    for(int a = 0; a < Map_Analysis_Scene_Storage.size(); a++)
    {
        if(Map_Analysis_Scene_Storage[a].attention < 10
            || CURRENT_MODEL_TIME - Map_Analysis_Scene_Storage[a].input_time > 3200)
            clear_a_Map_Analysis(a);
    }

}




//文本基础函数


//字符索引文件存储格式
struct text_file_unit
{
    int ch;//当前文本字符
    unsigned int link_id;//对应的文本节点
};

// 全局字符索引
unordered_map<int, unsigned int> Charter_To_Id;//数据量与错序问题，不能用vector
unordered_map<unsigned int, int> Id_To_Charter;

// 初始索引字符存储
vector<text_file_unit> Enter_CH_Storage;


// 初始索引字符查找表 载入函数
void text_enter_ch_load()
{
    Enter_CH_Storage.resize(ALL_NUM_OF_CH);

    Charter_To_Id.reserve(ALL_NUM_OF_CH * 1.5);
    Charter_To_Id.max_load_factor(0.7);

    Id_To_Charter.reserve(ALL_NUM_OF_CH * 1.5);
    Id_To_Charter.max_load_factor(0.7);
    
    FILE *fp = fopen("Record_enter_ch.rec", "r");
    if(fp)
    {
        fread(Enter_CH_Storage.data(), ALL_NUM_OF_CH * 8, 1, fp);
        fclose(fp);
    }
    

    //字符索引搜索载入
    for(int a = 0; a < ALL_NUM_OF_CH; a++)//utf-8上限11 4112字
    {   
        Charter_To_Id[ Enter_CH_Storage[a].ch ] = Enter_CH_Storage[a].link_id;
        Id_To_Charter[ Enter_CH_Storage[a].link_id ] = Enter_CH_Storage[a].ch;
    }

}
// 函数结束

// 保存 初始索引字符查找表
void save_init_text_file()
{
    FILE *fp = fopen("Record_enter_ch.rec", "w");
    fwrite(Enter_CH_Storage.data(), ALL_NUM_OF_CH * 8, 1, fp);
    fclose(fp);
}
// 函数结束


//陌生字符添加函数
unsigned int text_enter_ch_add(int new_ch)
{
    unsigned int id = neuro_create(30);//新建神经元

    text_file_unit tf;
    tf.ch = new_ch;
    tf.link_id = id;
    Enter_CH_Storage.push_back(tf);
    Charter_To_Id[new_ch] = id;
    Id_To_Charter[id] = new_ch;
    ALL_NUM_OF_CH += 1;

    //没写神经元描述

return id;
}
//函数结束


//转换函数
inline void Character_to_node(const vector<char>& input_vec, 
    vector<uint32_t>& result)
{
    int code = 0;
    int bytesNeeded = 0;

    vector<int> utf8_list;

    //将utf8字符化整为int形式
    for(unsigned char c : input_vec)
    {
        int utf8_ch;

        if(bytesNeeded == 0) // 判断是 UTF-8 的第一个字节
        {
            if((c & 0x80) == 0) {
                // 1 字节 ASCII
                utf8_ch = c;
                utf8_list.push_back(utf8_ch);
            }else if((c & 0xE0) == 0xC0) {
                code = c & 0x1F;
                bytesNeeded = 1;
            }else if((c & 0xF0) == 0xE0) {
                code = c & 0x0F;
                bytesNeeded = 2;
            }else if((c & 0xF8) == 0xF0) {
                code = c & 0x07;
                bytesNeeded = 3;
            }

        }else{
            // 后续字节
            code = (code << 6) | (c & 0x3F);
            bytesNeeded--;
            
            if (bytesNeeded == 0)
            {
                utf8_ch = c;
                utf8_list.push_back(utf8_ch);
            }
        }
    }

    int a = 0;

    //将int形式转化为神经元id
    for(int utf8_ch : utf8_list)
    {
        General_Cognition_Node node;

        if( Charter_To_Id.count(utf8_ch) ) {
            node.self_id = ( Charter_To_Id[ utf8_ch ] );

        } else {
            unsigned id = text_enter_ch_add( utf8_ch );
            node.self_id = id;
        }

        // node.list_no = a;

        General_Cognition_Node_Storage.push_back(node);
        uint32_t idx = General_Cognition_Node_Storage.size() - 1;

        result.push_back(idx);

        a++;
    }

}
//函数结束


//字符转化函数，vector<char> 至 文本节点网络
uint32_t CharVector_To_Network(
    const vector<char>& input_vec, long long input_time)
{
    //放入存储位置
    uint32_t idx = get_a_Text_Inference();
    Text_Inference_Scene& curr_network = Text_Inference_Scene_Storage[idx];

    curr_network.input_time = input_time;
    curr_network.source_kind = 1;
    curr_network.text_infer_node_list.clear();
    curr_network.original_text_list.clear();
    vector<uint32_t>& result = curr_network.original_text_list;
    result.reserve( input_vec.size() );

    Character_to_node(input_vec, result);

return idx;
}//函数结束


//字符转化函数，文本节点网络至vector<char>
vector<char> Network_To_CharVector( uint32_t text_idx )
{
    vector<uint32_t>& list = Text_Inference_Scene_Storage[text_idx].original_text_list;
    vector<char> output;
    output.reserve( list.size()*4 );

    for (uint32_t b : list)
    {
        General_Cognition_Node& node = General_Cognition_Node_Storage[b];
        int code = Id_To_Charter[node.self_id]; // id转字符

        if (code <= 0x7F) {
            output.push_back( (char)(code));
        } else if (code <= 0x7FF) {
            output.push_back( (char)(0xC0 | ( code >> 6)));
            output.push_back( (char)(0x80 | ( code & 0x3F)));
        } else if (code <= 0xFFFF) {
            output.push_back( (char)(0xE0 | ( code >> 12)));
            output.push_back( (char)(0x80 | ((code >> 6) & 0x3F)));
            output.push_back( (char)(0x80 | ( code & 0x3F)));
        } else {
            output.push_back( (char)(0xF0 | ( code >> 18)));
            output.push_back( (char)(0x80 | ((code >> 12) & 0x3F)));
            output.push_back( (char)(0x80 | ((code >> 6) & 0x3F)));
            output.push_back( (char)(0x80 | ( code & 0x3F)));
        }
    }

    output.push_back('\0');

return output;
}//函数结束


//文本发送函数
void text_send_to(uint32_t curr_text_idx)
{
    Text_Inference_Scene& curr_text = Text_Inference_Scene_Storage[curr_text_idx];

    if(curr_text.source_kind == 3)
        return;
    
    bool expected = 0;

    if( Text_Is_Send.compare_exchange_strong(expected, 1, memory_order_seq_cst) )
    {
        Send_Text_List = Network_To_CharVector(curr_text_idx);
        Text_Is_Send.store(0);
    } else {
        //发送失败 未完成
    }

}


//文本操作函数
void text_operate(
    uint32_t curr_text_idx, vector<unsigned int> input_text_list,
    int beg_pos, int end_pos, char operate_kind) //删除0，添加1
{
    Text_Inference_Scene& curr_text = Text_Inference_Scene_Storage[curr_text_idx];
    vector<uint32_t>& origin_text_list = curr_text.original_text_list;

    if(operate_kind == 0)
    {
        //删除

        origin_text_list.erase(origin_text_list.begin() + beg_pos, origin_text_list.begin() + end_pos);

    } else if(operate_kind == 1) {

        //添加

        origin_text_list.insert(origin_text_list.begin() + beg_pos,
            input_text_list.begin(), input_text_list.end());
    }

    //删除和添加时的推理节点存储需要挪移还是改结构
    //节点位置改动的属性怎么办

}//函数结束




//程序输出行为


//取键盘鼠标对应的值

//鼠标dwFlags
    unsigned int Mouse_DwFlags[10] = {
        0x0001, //相对移动	MOUSEEVENTF_MOVE
        0x0002, //左键按下	MOUSEEVENTF_LEFTDOWN
        0x0004, //左键抬起	MOUSEEVENTF_LEFTUP
        0x0008, //右键按下	MOUSEEVENTF_RIGHTDOWN
        0x0010, //右键抬起	MOUSEEVENTF_RIGHTUP
        0x0020, //中键按下	MOUSEEVENTF_MIDDLEDOWN 
        0x0040, //中键抬起  MOUSEEVENTF_MIDDLEUP
        0x0800, //垂直滚轮	MOUSEEVENTF_WHEEL
        0x1000, //横向滚轮	MOUSEEVENTF_HWHEEL
        0x8000  //绝对移动	MOUSEEVENTF_ABSOLUTE
    };

//键盘dwFlags
    unsigned int Keyboard_DwFlags[2] = {
        0x0000, //按下 KEYEVENTF_KEYDOWN
        0x0002  //松开 KEYEVENTF_KEYUP
    };

// Windows 常用 VK 键码数组
    unsigned char Keyboard_Common_Keys[79] = {

        // 控制键16个
        0x08, // VK_BACK
        0x09, // VK_TAB
        0x0D, // VK_RETURN (Enter)
        0x10, // VK_SHIFT
        0x11, // VK_CONTROL
        0x12, // VK_MENU (Alt)
        0x1B, // VK_ESCAPE
        0x20, // VK_SPACE
        0x21, // VK_PRIOR (Page Up)
        0x22, // VK_NEXT  (Page Down)
        0x23, // VK_END
        0x24, // VK_HOME
        0x2D, // VK_INSERT
        0x2E, // VK_DELETE
        0x5B, // VK_LWIN
        0x5C, // VK_RWIN

        // 方向键4个
        0x25, // VK_LEFT
        0x26, // VK_UP
        0x27, // VK_RIGHT
        0x28, // VK_DOWN

        // 数字键10个
        0x30, // 0 )
        0x31, // 1 !
        0x32, // 2 @
        0x33, // 3 #
        0x34, // 4 $
        0x35, // 5 %
        0x36, // 6 ^
        0x37, // 7 &
        0x38, // 8 *
        0x39, // 9 (

        // 字母键 A-Z 26个
        0x41, // A
        0x42, // B
        0x43, // C
        0x44, // D
        0x45, // E
        0x46, // F
        0x47, // G
        0x48, // H
        0x49, // I
        0x4A, // J
        0x4B, // K
        0x4C, // L
        0x4D, // M
        0x4E, // N
        0x4F, // O
        0x50, // P
        0x51, // Q
        0x52, // R
        0x53, // S
        0x54, // T
        0x55, // U
        0x56, // V
        0x57, // W
        0x58, // X
        0x59, // Y
        0x5A, // Z

        // Function keys F1-F12 12个
        0x70, // VK_F1
        0x71, // VK_F2
        0x72, // VK_F3
        0x73, // VK_F4
        0x74, // VK_F5
        0x75, // VK_F6
        0x76, // VK_F7
        0x77, // VK_F8
        0x78, // VK_F9
        0x79, // VK_F10
        0x7A, // VK_F11
        0x7B, // VK_F12

        // 常用符号 11个
        0xBA, // ; :
        0xBB, // = +
        0xBC, // , <
        0xBD, // - _
        0xBE, // . >
        0xBF, // / ?
        0xC0, // ` ~
        0xDB, // [ {
        0xDC, // \ |
        0xDD, // ] }
        0xDE  // ' "
    };



// 行为检索结构，对应神经元连接
vector<unsigned int> ACTION_SORT;
// 鼠标 6 + 16*16(位置) +2*16(滚轮) + 键盘 79*2 + 4 = 456


// 载入记录文件
void Load_External_Action_File()
{
    ACTION_SORT.resize(456);

    FILE *fp = fopen("Record_Action_Sort.rec", "r");
    fread(ACTION_SORT.data(), 456*4, 1, fp);

    fclose(fp);
}
//函数结束


// 保存记录文件
void Save_external_action_file()
{
    FILE *fp = fopen("Record_enter_line.rec", "w");
    fwrite(ACTION_SORT.data(), 456 * 4, 1, fp);

    fclose(fp);
}
//函数结束


// 新行为记录生成函数
void New_external_action_record()
{
    // 创建神经元
    unsigned int id = neuro_create(4);
    uint32_t pos;
    ACTION_SORT[pos] = id;

    unsigned int* ptr = node_find(id);
}


//行为探索相关函数

vector<int> Keybord_Action_Tended(79, 20);
vector<int> Key_Press_Tended(79, 1);
vector<int> Key_Release_Tended(79, 1);

//随机-键行为生成函数
Model_Output_Action random_keybord()
{
    static thread_local random_device Keybord_RD;
    static thread_local mt19937 Keybord_Gen(Keybord_RD());
    discrete_distribution<int> Keybord_choose_dist(
        Keybord_Action_Tended.begin(), Keybord_Action_Tended.end() );

    Model_Output_Action moa;
    moa.action_kind = 2;
    
    //1、随机键值
    int vk = Keybord_choose_dist(Keybord_Gen);

    moa.vk = Keyboard_Common_Keys[vk];

    int Press_Release[2] = {Key_Press_Tended[vk], Key_Release_Tended[vk]};

    discrete_distribution<int> Press_Release_choose_dist(
        Press_Release, Press_Release + 1 );

    //2、按 松
    int d = Press_Release_choose_dist(Keybord_Gen);

    if(d == 0)
        moa.dwFlags = 0x0000;//按下 KEYEVENTF_KEYDOWN
    else
        moa.dwFlags = 0x0002;//松开 KEYEVENTF_KEYUP

return moa;
}//函数结束


vector<int> Mouse_Action_Tended(10, 20);

//随机-鼠标行为函数
Model_Output_Action random_mouse()
{
    static thread_local random_device Mouse_RD;
    static thread_local mt19937 Mouse_Gen(Mouse_RD());
    discrete_distribution<int> Mouse_choose_dist(
        Mouse_Action_Tended.begin(), Mouse_Action_Tended.end() );

    Model_Output_Action moa;
    moa.action_kind = 1;

    //1、随机dwFlags
    int d = rand_0_to_255();

    while(d > 10)
        d -= 10;

    moa.dwFlags = Mouse_DwFlags[d];

    //1-2、随机按键
    if(moa.dwFlags == 0x0001 //相对移动	MOUSEEVENTF_MOVE
        || moa.dwFlags == 0x8000) //绝对移动 MOUSEEVENTF_ABSOLUTE
    {
        //绝对移动的未考虑
        
        moa.x = rand_0_to_255();
        moa.y = rand_0_to_255();
    }

    //1-3、随机滚轮
    if(moa.dwFlags == 0x0800 //垂直滚轮	MOUSEEVENTF_WHEEL
        || moa.dwFlags == 0x1000) //横向滚轮 MOUSEEVENTF_HWHEEL
    {
        moa.mouseData = rand_0_to_255() - 128;
    }
        

return moa;
}
//函数结束


//行为输出抽取函数
void External_Action_Choose(void)
{
    //比重抽取
    discrete_distribution<int> action_choose_dist( action_choose_weights.begin(), action_choose_weights.end() );  //填入注意力的值

    //均等抽取
    uniform_int_distribution<> equal_dist(0 , 4);

    static thread_local random_device Motion_RD;
    static thread_local mt19937 Motion_Gen(Motion_RD());

    //
    Model_Output_Action model_action;
    
    int random_tended; // 倾向随机行为(探索)
    int aim_tended; // 倾向目的行为(任务)

    int mouse_tended = 100;
    int key_tended = 100;
    int interface_tended = 10;

    short action_limit = 5;
    short n = 0;

    while(n < action_limit)
    {
        int choose_I[2] = {random_tended, aim_tended};

        //比重抽取
        discrete_distribution<int> action_kind_dist( choose_I, choose_I + 1 );
        char action_kind = action_kind_dist(Motion_Gen);

        //选择随机行为
        if(action_kind == 1)
        {
            // 选择随机
            vector<int> choose_II = { mouse_tended, key_tended, interface_tended };
            discrete_distribution<int> choose_II_dist( choose_II.begin(), choose_II.end() );
            action_kind = choose_II_dist(Union_Gen);

            if(action_kind == 1) {
                model_action = random_mouse();

            } else if (action_kind == 2) {
                model_action = random_keybord();

            } else if (action_kind == 3) {
                vector<int> choose_III = { 1, 1, 1, 1 };
                discrete_distribution<int> choose_III_dist( choose_III.begin(), choose_III.end() );
                model_action.action_kind = choose_III_dist(Union_Gen);
            }

            //人为选项比重

        } else {// 选择目标行为

            model_action = action_choose_list[ action_choose_dist(Union_Gen) ];
        }

        model_action.action_order = n;
        Watting_Action_List.push_back(model_action);
        n++;
    }

}//函数结束


//行动相关结束

