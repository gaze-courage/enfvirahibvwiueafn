#include <cstdio>
#include <stdexcept>

#include "Half.hpp"




//高级数据分析


//注意对象评估函数
void map_attention_appraise(
    uint32_t last_scene_idx, uint32_t curr_scene_idx, char limit_time = 10)
{
    //检索注意对象的新增与消失
    //检索数量与空间位置
    //未完成

    //开始计时
    auto start_total = chrono::steady_clock::now();
    int total_elapsed_time = 0;

    General_Cognition_Scene& curr_scene = General_Cognition_Scene_Storage[curr_scene_idx];
    vector<uint32_t>& uniqure_node_list = curr_scene.number_record_node_list;
    vector<Require_Object>& Require_Object_List = curr_scene.Require_Object_List;

    General_Cognition_Scene& last_scene = General_Cognition_Scene_Storage[last_scene_idx];
    vector<uint32_t>& last_uniqure_node_list = last_scene.number_record_node_list;

    //连续性检索
    for(int a = 0; a < uniqure_node_list.size(); a ++)
    {
        uint32_t node_idx = uniqure_node_list[a];
        General_Cognition_Node& node = General_Cognition_Node_Storage[node_idx];

        if(node.node_attention < 10)
            continue;

        //1-1、若检索到消失性,创建消失对象
        //消失对象性应该挪到检索需求未完成的时候，赋予未完成的检索生成消失性对象

        //1-2、若检索到新增性,创建新增对象
        //新增对象性生成应该挪到检索激活的时候生成，这里只负责注意力遗传

        //1-3、若有对应存在，遗传一部分注意力

        //应该是通过这个创建检索需求才对
        for(int b = 0; b < last_uniqure_node_list.size(); b++)
        {
            uint32_t i = last_uniqure_node_list[b];
            General_Cognition_Node& last_node = General_Cognition_Node_Storage[i];

            Require_Object require_object;
            require_object.require_kind = 1;
            require_object.require_id = last_node.self_id;
            require_object.require_value = 10; // 为？不通过检索上一个需求继承增加

            last_node.self_id;

            Require_Object_List.push_back(require_object);
        }

    }

    //时间结算
    auto now = chrono::steady_clock::now();
    total_elapsed_time = chrono::duration_cast< chrono::milliseconds >(now - start_total).count();
}


//检索对象挑选函数
uint32_t map_require_object_select(
    vector< vector<int> >& model_require, uint32_t map_idx)
{
    //这个只适用于小规模优先对象，大规模的成本不如全体遍历
    char model_require_layer = model_require.size() - 1;
    int finally_idx = 0;
    int choose_value;
    int choose_idx;

    for(int q = model_require_layer; q >= 0; q--)
    {
        vector<int>& partial_model_require = model_require[model_require_layer];
        int curr_model_require_size = partial_model_require.size();

        choose_idx = 0;
        choose_value = partial_model_require[0];

        for(int w = 1; w < curr_model_require_size; w++)
        {
            if(choose_value < partial_model_require[w])
            {
                choose_value = partial_model_require[w];
                choose_idx = w;
            }
        }

        finally_idx = finally_idx*8 + choose_idx;
        model_require_layer--;
    }

return finally_idx;
}


//单节点空间性建模
void Image_A_Neuro_Space_Model(
    uint32_t map_idx, uint32_t node_idx)
{
    Map_Analysis_Scene& curr_map = Map_Analysis_Scene_Storage[map_idx];
    int height = curr_map.height;
    int width = curr_map.width;

    //确定建模节点
    General_Cognition_Node& curr_node = General_Cognition_Node_Storage[node_idx];

    //确定扫描范围
    Node_Image_Attribute the_node_attribute = read_a_Node_Image_Attribute(node_idx);
    short scan_range = sqrt(the_node_attribute.block_num) + sqrt(curr_node.node_attention);
    scan_range = scan_range * the_node_attribute.standard_size;

    //注意力加入控制

    int x = the_node_attribute.x * the_node_attribute.standard_size;
    int y = the_node_attribute.y * the_node_attribute.standard_size;

    short left = x - scan_range;
    short right = x + scan_range;
    short bottom = y - scan_range;
    short top = y + scan_range;

    if(left < 0) left = 0;
    if(right >= width) right = width - 1;
    if(bottom < 0) bottom = 0;
    if(top >= height) top = height - 1;

    //可选择点
    vector<uint32_t> can_choose_node;
    can_choose_node.reserve(128);
    vector<int> choose_node_weight;
    choose_node_weight.reserve(128);

    int record_distance = curr_map.Image_Cover_Node_View.record_distance;
    int record_width = width / record_distance;

    bottom /= record_distance;
    top /= record_distance;
    left /= record_distance;
    right /= record_distance;

    int x0 = x / record_distance;
    int y0 = y / record_distance;

    vector< vector<uint32_t> >& Image_Node_Idx_Record =
        curr_map.Image_Cover_Node_View.Image_Node_Idx_Record;

    int width_reduce_middle = record_width - (right-left);

    vector<uint32_t> have_link_idx;
    have_link_idx.reserve(16);

    //1、重复对象标记阻止
    for(int p = 0; p < curr_node.object_list.size(); p++)
    {
        if( (curr_node.object_list[p].link_attribute.Link_Kind >= 1 && curr_node.object_list[p].link_attribute.Link_Kind <= 4) )
        {
            uint32_t object_idx = curr_node.object_list[p].link_attribute.Link_Idx;
            have_link_idx.push_back(object_idx);
        }
    }

    uint32_t retrieval_idx = bottom*record_width + left;

    //区域遍历 确定建模对象

    //2、统计频率
    if(curr_node.model_require > 10)
    {
        for(int y1 = bottom; y1 <= top; y1++)
        {
            for(int x1 = left; x1 <= right; x1++)
            {
                // 2-1、合适对象选取
                int true_x_dis = x1 - x0;
                int true_y_dis = y1 - y0;

                //

                // 2-2、添加属性
                if(1)
                {
                    Attribute_Head item_head;
                    vector<General_Condition> general_condition_list;
                    vector<General_Result> general_result_list;

                    item_head.attribute_kind = 1;
                    item_head.condition_kind = 7;

                    Image_Item image_condition;
                    image_condition.direction_scale = 3;
                    image_condition.distance_scale = 3;
                    
                    General_Condition condition = {.image_condition = image_condition};

                    general_condition_list.push_back(condition);

                    simple_neuro_attribute_write(curr_node.self_id, 0, 1, item_head,
                        general_condition_list, general_result_list);
                }
            }
        }
    }

    //3、聚合建立
    if(curr_node.model_require > 10)
    {
        for(int y1 = bottom; y1 <= top; y1++)
        {
            for(int x1 = left; x1 <= right; x1++)
            {
                int true_x_dis = x1 - x0;
                int true_y_dis = y1 - y0;

                float distance_encourage_value = scan_range - sqrtf(true_x_dis*true_x_dis + true_y_dis*true_y_dis);

                if(distance_encourage_value < 0)
                    continue;

                //求取该点的推荐比重
                for(uint32_t object_node_idx : Image_Node_Idx_Record[retrieval_idx])
                {
                    General_Cognition_Node& this_node = General_Cognition_Node_Storage[object_node_idx];

                    Node_Image_Attribute node_image_attritube = read_a_Node_Image_Attribute(object_node_idx);

                    char standard_size = node_image_attritube.standard_size;
                    int true_x_dis = (node_image_attritube.x * standard_size) - x;
                    int true_y_dis = (node_image_attritube.y * standard_size) - y;

                    float distance_encourage_value = scan_range -
                        sqrtf(true_x_dis*true_x_dis + true_y_dis*true_y_dis);

                    int write_encourage_value;

                    int node_weight = this_node.node_attention + distance_encourage_value
                        + this_node.rough_free_item_size + this_node.model_require;
                    
                    can_choose_node.push_back(object_node_idx);
                    choose_node_weight.push_back(node_weight);
                }
                retrieval_idx += 1;
            }
            retrieval_idx += width_reduce_middle;
        }//全区域遍历结束
    }

    //4、生成新组合 添加至网络

    //选择倾向
    discrete_distribution<int> choose_tend_index_dist(
        choose_node_weight.begin(), choose_node_weight.end());

    unordered_set< vector<uint32_t>, VectorUint32_tHash, VectorUint32_tEq >& image_combo_hash
        = curr_map.image_combo_hash;

    char combine_count = 1;

    //随机生成
    int max_try = combine_count * 30;
    int try_count = 0;
    vector<float> k_weights = {0, 0.2, 0.3, 0.3, 0.2}; // 概率 组合的元素数
    discrete_distribution<int> dist(k_weights.begin(), k_weights.end());
    random_device RD;
    mt19937 Gen(RD());
    char k = dist(Gen); // 组合内元素的数量，随机生成

    int result_size = 0;

    vector<int> indices;
    indices.reserve(5);

    while (result_size < combine_count && try_count < max_try)
    {
        indices.clear();

        // 随机选 k 个不重复点
        while ( (int)indices.size() < k )
        {
            uint32_t array_idx = choose_tend_index_dist(Gen);

            //内部无
            if (find(indices.begin(), indices.end(), array_idx) == indices.end())
            {
                indices.push_back(array_idx);
            }
        }

        //
        vector<uint32_t> combo;
        combo.reserve(k + 1);
        combo.push_back(node_idx);

        for (int idx : indices)
            combo.push_back(can_choose_node[idx]);

        // 去重
        sort(combo.begin(), combo.end());

        if (image_combo_hash.insert(combo).second)
        {
            //通过，添加
            new_road_node_generate(combo, 1 , map_idx, 1);
            result_size++;
        }

        try_count++;
    }

    //非精确方位对应 类别

}


//单节点时间性建模，未完成
void Image_A_Neuro_Time_Model(
    uint32_t map_idx, uint32_t node_idx)
{
    General_Cognition_Node& curr_node = General_Cognition_Node_Storage[node_idx];

    General_A_Neuro_Active(node_idx, map_idx, 3);

    //
    char need_add_stat = curr_node.model_require*10 + curr_node.rough_free_item_size;

    //1、新增统计连接添加
    while(need_add_stat >= 100)
    {
        //根据节点比重选择最适路径
        vector<uint32_t> choose_can;

        //合适节点选取
        uint32_t choose_idx;
        auto choose_model_node = General_Cognition_Node_Storage[choose_idx];

        //注意力竞争 晋升
        //建模条目数量 原条目复用
        //插入位置
        //建模缺失性，建模抑制性，注意力抑制
        //属于高级特性，在普通建模中不应包括

        //条件不足，求取精确条件
            // 全条件性统计
            // 满足率
            // 更新或增加比重
            // 所有条件的满足率

        unsigned int choose_node_id = choose_model_node.self_id;

        vector<General_Condition> general_condition_list;
        vector<General_Result> general_result_list;

        Attribute_Head attribute_head;
        attribute_head.condition_kind = 2;
        attribute_head.result_kind = 2;

        Time_Item time_condition;
        time_condition.time_range;
        time_condition.time_scale;

        time_condition.related_id;

        simple_neuro_attribute_write(choose_node_id, 0, 1,
            attribute_head, general_condition_list, general_result_list);
        
    }//统计添加结束
    
}


//图节点态度生成
void Image_All_Neuro_Emotion_Model(uint32_t map_idx, uint32_t node_idx)
{
    General_Cognition_Node& curr_node = General_Cognition_Node_Storage[node_idx];

    General_A_Neuro_Active(node_idx, map_idx, 3);

    curr_node.rough_free_item_size;

    if(curr_node.model_require );
}

//
void Image_A_Neuro_Category_Model(uint32_t map_idx, uint32_t node_idx)
{
    General_Cognition_Node& curr_node = General_Cognition_Node_Storage[node_idx];

    //挑选足够的

    //检查方向与距离上的需求
    Image_Item image_condition;

    //
    Node_Image_Attribute self_image_attribute = read_a_Node_Image_Attribute(node_idx);

    //
    //类别是指在只要有任意条件就可以生成的对象，等同于||逻辑
    //同一个节点，由不同的条件组合生成，只要元素和位置一致就可以，这种是否可以看作是类别

    self_image_attribute.x;
    self_image_attribute.y;
    self_image_attribute.contain_distance;
    
}


//因果模糊融合
void Casual_Fusion(uint32_t calu_node_idx)
{
    General_Cognition_Node& curr_node = General_Cognition_Node_Storage[calu_node_idx];

    /*
    对同一对象的多重预测
    选择融合为一的情况

    总体概率 = 单一概率*可信度*因果对象抑制性(来自其他神经元对其的统计，没有的话为1) * 单一在总体的比例
    似乎还有个计算偏差度的公式，来判断生成因果抑制属性

    大范围时效性未考虑如何实际操作到小范围时间
    单一事件的数量也不知道怎么影响概率
    */

    for(int l = 0; l < curr_node.object_list.size(); l++)
    {
        vector<float> probility_list;
        vector<int> stat_num_list;
        vector<float> restrain_list;
        int total_stat = 0;

        if( curr_node.object_list[l].link_attribute.Link_Kind == 3 )
        {
            uint32_t source_idx = curr_node.object_list[l].link_attribute.Link_Idx;
            General_Cognition_Node& source_node = General_Cognition_Node_Storage[source_idx];

            //只是遍历获取因果变量
            for(int k = 0; k < source_node.object_list.size(); k++)
            {
                if(source_node.object_list[k].link_attribute.Link_Idx != calu_node_idx)
                    continue;
                
                //找到连接对象 但连接对象被删除的情况呢

                //
                probility_list.push_back(source_node.object_list[k].link_attribute.Link_Value);
            }
        }

        float p = 0;

        for(int j = 0; j < probility_list.size(); j++)
        {
            p += probility_list[j] * stat_num_list[j]/total_stat * restrain_list[j];
        }

        curr_node.probability = p;
    }

}


//情景提取生成函数
//情景生成分类函数
vector<uint32_t> Scene_Generate_Classify(
    vector<uint32_t>& total_init_element, uint32_t scene_idx)
{
    General_Cognition_Scene& source_simu_scene = General_Cognition_Scene_Storage[scene_idx];

    uint32_t add_simu_idx = get_a_General_Cognition_Scene();

    vector<uint32_t> return_simu_scene_idx;

    vector<uint32_t> all_derive_element;
    vector<uint32_t> derive_element;
    all_derive_element.reserve(total_init_element.size()*8);

    //1、原下层生成，可选项目
    for(int q = 0; q < total_init_element.size(); q++ )
    {
        derive_element = General_A_Neuro_Active(total_init_element[q], 0, 4);
        
        all_derive_element.insert(derive_element.begin(),
            derive_element.end(), all_derive_element.end());

        //
    }

    //这只在时间分布，还不在数量分布与空间分布
    
    vector<Link_Object_Attribute> link_object;
    link_object.reserve(32);
    int attention_size;

    //2、预测对象归一，但时间范围和预测数量问题
    for(int w = 0; w < 0; w++)
    {
        unsigned int id ;

        //计算注意力和连接
        for(int a = 1; a < 0; a++)
        {
            uint32_t i ;
            General_Cognition_Node& a_node = General_Cognition_Node_Storage[i];
            attention_size += a_node.node_attention;
        }

        // Casual_Fusion();

        General_Cognition_Node_Storage[0].node_attention += attention_size;
        //将注意力分配 整合

        //查找时间分布统计
        //时间分配不均则不归入同一统计
        //空白增生与注意消减

    }//归一化结束

    unordered_set<uint32_t> clear_find;

    //3、注意力再分配 与 概率分配
    for(int e = 0; ; )
    {
        //筛选无被赋予概率性性节点，作为起始概率统计
        uint32_t ni ;
        General_Cognition_Node& node = General_Cognition_Node_Storage[ni];

        for(int a = 0; a < node.object_list.size(); a++)
        {

        }
        
        //关联，关注属性
    }
    
    //矛盾统计 预测优势 预测抑制与数量相关系 单列概率区 前后向传播添加式更新

return return_simu_scene_idx;
}




// 全图像处理函数
void All_Image_Process(
    uint32_t curr_map_idx, char limit_time)
{
    auto start = chrono::steady_clock::now();
    int elapsed_ms = 0;

    Map_Analysis_Scene& curr_map = Map_Analysis_Scene_Storage[curr_map_idx];
    unsigned short width = curr_map.width;
    unsigned short height = curr_map.height;

    vector<Wait_Active_Neuro> wait_active_list;
    vector<uint32_t> free_wait_active_idx;

    vector< vector<int> >& retrieve_require_list = curr_map.retrieve_require_list;
    vector< vector<int> >& model_require_list = curr_map.model_require_list;

    // 1、初始化识别
    if(curr_map.is_init_recognize == 0 && curr_map.is_lock_occupy == 0)
    {
        curr_map.is_lock_occupy += 1;

        //基础注意力生成
        if(curr_map.last_map != 0)
            map_nature_attention_generate(curr_map.last_map, curr_map_idx);
        else map_nature_attention_generate(curr_map_idx, curr_map_idx);

        //视图生成
        map_explain_view_generate(curr_map_idx, 1);
        map_explain_view_generate(curr_map_idx, 2);
        map_explain_view_generate(curr_map_idx, 4);

        //初始化需求生成
        init_map_require(curr_map_idx, retrieve_require_list, 1);
        init_map_require(curr_map_idx, model_require_list, 2);

        //对象需求继承
        map_attention_appraise(curr_map.last_map, curr_map_idx);

        curr_map.is_init_recognize = 1;
        curr_map.is_lock_occupy -= 1;

    } else {
        return;
    }
    // 初始化识别结束


    // 2、任务执行选取
    random_device Task_RD;
    mt19937 Task_Gen(Task_RD());
    int work_weights[5];
    
    work_weights[0] = curr_map.sum_retrieve_require;
    work_weights[1] = curr_map.sum_model_space_require;
    work_weights[2] = curr_map.sum_model_time_require;
    work_weights[3] = curr_map.sum_construct_require;
    work_weights[4];

    discrete_distribution<int> task_dist(work_weights, work_weights + 4);
    int task_chose = task_dist(Task_Gen);
    //随机任务目的

    atomic<char> un_fixed_task(1);
    
    //3、正式执行 限制时间
    while(elapsed_ms < limit_time && curr_map.is_lock_occupy == 0)
    {
        // 注意力与需求调控

        // 任务执行
        switch (task_chose)
        {
            case 0://检索生成
            {
                //从区域需求(线段探测) 还是 节点需求
                uint32_t target_idx = map_require_object_select(retrieve_require_list, curr_map_idx);

                //构造线段 或 激活节点
                General_A_Neuro_Active(target_idx, curr_map_idx, 1);

                //边缘 线段 探测生成
            }
            break;
            case 1://建模生成 空间
            {
                //检索未满 或 需求增生
                uint32_t target_idx = map_require_object_select(model_require_list, curr_map_idx);
                Image_A_Neuro_Space_Model(curr_map_idx, target_idx);
            }
            break;
            case 2://建模生成 时间
            {
                //选择合适节点
                uint32_t target_idx;
                Image_A_Neuro_Time_Model(curr_map_idx, target_idx);

                //进入其他对象
                if(0)
                {
                    uint32_t other_map_idx;
                    All_Image_Process(other_map_idx, limit_time - elapsed_ms);
                }
            }
            break;
            case 3://建模生成 态度
            {
                uint32_t target_idx;
                Image_All_Neuro_Emotion_Model(curr_map_idx, target_idx);
            }
            break;
            case 4://构造生成
            {
                char calculate_state; // 计算状态 时间1 空间2 结论3 (目标消失，目标生成)
                char calculate_aim; // 预测1 行动规划2 文本构造3 知识构造4

                int limit_history; //限制读取的历史长度
                int limit_evolution_time; //限制演化的时间

                int limit_number; //限制演化的总数量
                char limit_branch; //限制演化的分支数量
                short limit_dimension; //限制演化的单分支元素数量
                short limit_layer; //限制演化的层数

                //原有的发生事件
                uint32_t Original_idx ;
                General_Cognition_Scene& Original_Scene = General_Cognition_Scene_Storage[Original_idx];

                //计算的发生事件概率
                uint32_t Calculate_idx ;
                General_Cognition_Scene& Calculate_Network = General_Cognition_Scene_Storage[Calculate_idx];

                //基于原统计列表展开预测
                for(int a = 0; a < Original_Scene.all_have_node_idx_list.size(); a++)
                {
                    uint32_t node_idx = Original_Scene.all_have_node_idx_list[a];
                    General_A_Neuro_Active(node_idx, Original_idx, 4);
                }


                //改成随时间增加激活神经元从而添加因果连接、修正预测判断的形式

                //查找下一演化方向，演化区分度 注意力控制 封闭当前系统
                //归纳总结演化方向，合并预测内容，分离预测内容，整理预测内容
                    //筛选主要方面
                    //添加或新建
                    //重合判断
                    //聚合属性连串激活
                    //区别重要性，根据注意力值区分需要节点

                //只对关注元素采取确定情景化，对非关注元素采取合一的模糊概率

                //情景分类整合

                //预测首先要做生成预测内容，再将预测内容区分连接程度、注意力，将预测内容划分好概率，再将预测内容放入场景
                //根据识别需求来做情境划分
                //根据神经元注意力、来自总体注意力、情景自生注意力
                //根据概率整合与分散注意力

                //时间预测列表

                //计算总体概率，除非有特别关注的注意力，否则合一情景元素
            }

        }//任务switch结束


        // 4、任务重分配
        if(un_fixed_task)
        {
            work_weights[0] = curr_map.sum_retrieve_require;
            work_weights[1] = curr_map.sum_model_space_require;
            work_weights[2] = curr_map.sum_model_time_require;
            work_weights[3] = curr_map.sum_construct_require;
            work_weights[4];
            discrete_distribution<int> a_dist(work_weights, work_weights + 4);
            int task_chose = a_dist(Task_Gen);
        }
        

        //时间结束
        auto end = chrono::steady_clock::now();
        elapsed_ms= chrono::duration_cast<std::chrono::milliseconds>(end - start).count();
        
    }//正式执行结束

}
//函数结束



//行动规划函数
int More_Motion_Calculate_And_Execulate(uint32_t scene_idx, char limit_time)
{
    auto start = chrono::steady_clock::now();
    int elapsed_ms = 0;

    General_Cognition_Scene& curr_scene = General_Cognition_Scene_Storage[scene_idx];

    unordered_map<unsigned int, vector<uint32_t> > init_condition;

    vector<uint32_t>& init_node_idx = curr_scene.all_have_node_idx_list;

    //连接路径探测组织
    vector<uint32_t> need_find_list;//一般两个
    vector<uint32_t> total_node_list;

    uint32_t idx_a = need_find_list[0];
    uint32_t idx_b = need_find_list[1];

    vector<uint32_t> wait_find_link_list;
    wait_find_link_list.push_back(idx_a);
    wait_find_link_list.push_back(idx_b);
    vector<uint32_t> generate_id_list;

    unordered_map<unsigned int, char> find_connection;
    unordered_map<unsigned int, uint32_t> find_idx;

    find_connection[ General_Cognition_Node_Storage[idx_a].self_id ] = 1;
    find_connection[ General_Cognition_Node_Storage[idx_b].self_id ] = 2;

    int need_do = 1;
    int check_no = 0;
    int find_coincidence_num = 0; // 统计找到连接的量

    bool think_suit = 1;

    vector<uint32_t> key_path;

    //注意力控制
    vector<uint32_t> active_attention_control;

    //行动目的
    unsigned int target;

    //操作路径，未多选择化
    vector<uint32_t> return_path;
    curr_scene.all_have_node_idx_list;
    rand_0_to_255();


    //随机任务执行器
    random_device Task_RD;
    mt19937 Task_Gen(Task_RD());
    vector<int> work_weights = {0, 1, 0, 0, 0, 0};
    discrete_distribution<int> dist(work_weights.begin(), work_weights.end());
    int task_chose = dist(Task_Gen);

    char un_fixed_task = 1;
    
    while(elapsed_ms < limit_time)
    {
        switch(task_chose)
        {
            case 1://连接探测
            {
                //1、探索连接

                //未能被注意力控制
                uint32_t id_idx = wait_find_link_list[check_no];
                char base_connection = find_connection[id_idx];
                generate_id_list = General_A_Neuro_Active(id_idx, scene_idx, 5);//改生成方式
                
                //分离结果
                for(uint32_t target_id : generate_id_list)
                {
                    unsigned int id = General_Cognition_Node_Storage[target_id].self_id;
                    if( find_connection.count(id) )
                    {
                        //重合元素
                        if(find_connection[id] != base_connection);
                        {
                            find_connection[id] = 3;
                            find_coincidence_num += 1;
                        }
                        //但去重的工作

                    } else {//新元素
                        find_connection[id] = base_connection;
                        wait_find_link_list.push_back(target_id);
                    }
                }
                //分离结果结束

            }
            break;
            case 2://检查选择概率
            {
                //如果转变探查
                task_chose = 1;
            }
            break;
            case 3://优化路径选取
            {
                //2、优化选择路径(节点路径)
                while(need_do || think_suit)
                {
                    //选择合适路径
                        //探索相关
                    //归纳最大路径
                        //客观时间、感度、可达度

                    //中继目的
                }
            }
            break;
            case 4://情景显化(情景路径)，这非纯粹的预测未来，而是找行动的途径，所以会生成新结构
            {
                //预测模拟系统 展开 不需要展开
                    //宏观路径搜索，次要全连接搜索
                //以此基础，场景演化生成
                    //是优先场景预测 还是优先连接路径场景
                //时间评估 概率评估
            }
            break;
            case 5://概率统计
            {
                //中央节点，必需，宜需，更优，相关
                //得出最优节点，代替节点备选节点
                
                //对路径的查找优先级与对概率的计算优先级

                //路径中间奖励 选则偏好
                //必选 探索
                //

                //投入关注  重复规划路径
            }
            break;
            case 6://任务执行
            {
                //任务行动执行
                Scene_Motion_Attribute sma;
                sma.curr_motion_idx;

                //任务存储在当前网络中

                //General_Cognition_Node& action_node = General_Cognition_Space[];
                //Node_Motion_Attribute

                Focus_Object fo;
                Total_Focus_Object_List;

                //执行网络
                    //执行监察，到哪一步以及应有反馈

                    //衔接函数，模糊预测
                
                Attention_Object_List;
                Attention_Object ao;

                //输入外部抽取库，检查反馈
                action_choose_list;
                {
                    /*
                    重点：无法由少数节点情景化整体情景
                    路径概率评估-路径概率优选-路径合理性检查
                    输出选择路径与备选节点
                    */
                }

            }
            break;
            case 7://观测现状
            {
                uint32_t other_map_idx = newist_map_idx;
                All_Image_Process(other_map_idx, limit_time - elapsed_ms);
            }

        }

        //时间结算
        auto end = chrono::steady_clock::now();
        elapsed_ms = chrono::duration_cast<std::chrono::milliseconds>(end - start).count();
    }


return 0;
}
//函数结束



//涓栫晫娣卞眰鏀垮簻鐨勮蛋鐙椾滑锛屽叕鐞嗗拰姝ｄ箟鏄案杩滀笉浼氬眻鏈嶄簬浣犱滑鐨勮揩瀹崇殑


//因果流通统计函数
vector< vector<uint32_t> > stat_connected_components(
    vector<uint32_t>& curr_being)
{
    int n = curr_being.size();
    vector< vector<uint32_t> > result;
    vector<char> connect( n, 0);

    int connect_signal = 1;

    for(int a = 0; a < n; a++)
    {
        General_Cognition_Node& curr_node = General_Cognition_Node_Storage[a];
        if(connect[a] == 0)
        {
            for(int b = 0; b < curr_node.object_list.size(); b++)
            {
                if(curr_node.object_list[b].link_attribute.Link_Kind >= 1 && curr_node.object_list[b].link_attribute.Link_Kind <= 4)
                {
                    uint32_t object_idx = curr_node.object_list[b].link_attribute.Link_Idx;
                    General_Cognition_Node& object_node = General_Cognition_Node_Storage[object_idx];

                    int component_idx = object_node.component;

                    if(component_idx != 0)
                    {
                        connect[a] = component_idx;
                        result[component_idx].push_back( curr_being[a] );
                        break;
                    }
                }
            }

            curr_node.component = connect_signal;
            connect_signal = connect_signal + 1;
        }

    }
    
return result;
}//函数结束



//类别中心特征计算
void cental_feature(uint32_t scene_idx, uint32_t node_id)
{
    //计算最多的的元素
    //最大比例的元素
}

//条件正确率统计
void condition_statistic(uint32_t scene_idx, uint32_t node_id)
{
    //最优条件统计
    //条件-通常-特别
    //条件遴选重组
}

//归因函数
void scene_casual_conclude(uint32_t scene_idx, uint32_t node_id)
{
    //即时，情景新元素查找
    //大范围，中央元素查找
}

//内涵同现值分析，用于因果统计
void inside_concurrence(uint32_t scene_idx, uint32_t node_id)
{
    ;
}

//重复元素查找函数
vector<unsigned int> findCommon(
    vector<unsigned int>& a,
    vector<unsigned int>& b)
{
    unordered_set<unsigned int> s(a.begin(), a.end());
    vector<unsigned int> result;
    result.reserve(min(a.size(), b.size()));

    for (int x : b)
    {
        if (s.count(x))
        {
            result.push_back(x);
        }
    }

return result;
}//函数结束


    struct Result_Diff {
        vector<unsigned int> less;// B 少的（A多出的）
        vector<unsigned int> more;// B 多出的
    };


//增减元素查找函数
Result_Diff diff_element_search(
    vector<unsigned int>& A,
    vector<unsigned int>& B)
{
    unordered_set<unsigned int> set_A(A.begin(), A.end());
    unordered_set<unsigned int> set_B(B.begin(), B.end());

    Result_Diff result;

    // 查 B 多出的元素
    for (unsigned int & x : B)
    {
        if (!set_A.count(x))
            result.more.push_back(x);
    }

    // 查 B 少的元素（即 A 多出的元素）
    for (unsigned int & y : A)
    {
        if (!set_B.count(y))
            result.less.push_back(y);
    }

return result;
}//函数结束



//
void contradict_sift(uint32_t source_scene_idx,
    vector<uint32_t>& generate_predict_event_idx)
{
    General_Cognition_Scene source_scene = General_Cognition_Scene_Storage[source_scene_idx];
    generate_predict_event_idx;
}



//节点连接度量
struct node_explore_measure
{
    int explore_value;
    int useful_value;
};




/*
**
**文本认知 
**
*/


//文本建模函数
void Text_A_Neuro_Model(
    uint32_t text_pos, uint32_t text_network_idx)
{
    Text_Inference_Scene& text_network = Text_Inference_Scene_Storage[text_network_idx];
    vector<uint32_t> original_text_list = text_network.original_text_list;

    uint32_t text_node_idx = original_text_list[text_pos];
    General_Cognition_Node& curr_node = General_Cognition_Node_Storage[text_node_idx];
    unsigned int id = curr_node.self_id;

    unordered_set< vector<unsigned int>, VectorUint32_tHash, VectorUint32_tEq > Text_Combo_Unordered;

    //有建模需求的节点 取无连接节点作为大建模需求的节点

    vector<int> front_modeling_require_scan(8, 0);
    vector<int> back_modeling_require_scan(8, 0);

    //频率建模
    //1、确定建模对象 添加新对象
    if(curr_node.model_require >= 7)
    {
        //model_require是一个会向成功生成的上级节点传播的值
        //在传播中会有损耗，从而通过探测较大值对象来确定建模对象
        //通常和注意力结合来确定增加对象

        //建模字符

        Node_Text_Attribute self_text_attribute = read_a_Node_Text_Attribute(text_node_idx);

        vector<Flexible_Object>& link_object_list = curr_node.object_list;

        char scan_range = curr_node.model_require / 2;
        
        //遍历连接属性
        for(int l = 0; l < link_object_list.size(); l++)
        {
            uint32_t idx = link_object_list[l].link_attribute.Link_Idx;
            General_Cognition_Node_Storage[idx].node_calu_state = 2; // 去除已有连接
        }


        //前后向扫描建模
        for(int i = -scan_range; i < scan_range; i++)
        {
            uint32_t idx = original_text_list[text_pos + i];
            General_Cognition_Node& object_node = General_Cognition_Node_Storage[idx];

            //去重对象
            if(object_node.node_calu_state == 2 || i == 0)
                continue;
            
            //确定对象值
            int need_add_stat = curr_node.model_require - object_node.predict_stability
                - i + curr_node.rough_free_item_size;
            
            //单对象写入建模
            if(need_add_stat > 0)
            {
                //添加属性
                Attribute_Head item_head;
                vector<General_Condition> general_condition_list;
                vector<General_Result> general_result_list;

                Text_Item text_item;
                text_item.left_distance = 1;
                text_item.distance_scale = 4;
                text_item.target_id = object_node.self_id;;

                General_Condition condition = {.text_condition = text_item};
                general_condition_list.push_back(condition);

                item_head.attribute_kind = 1;
                item_head.condition_kind = 3;
                item_head.condition_num += 1;
                
                simple_neuro_attribute_write(curr_node.self_id, 0, 1, item_head,
                    general_condition_list, general_result_list);

                //连接写入节点 写入当前节点还是所有节点 写入所有节点又如何检验
                Link_Object_Attribute la;
                la.Link_Attribute = 1;
                la.Link_Kind = 4;
                la.Link_Idx = idx;

                Flexible_Object flex = {.link_attribute = la};
                curr_node.object_list.push_back(flex);
            }
            //单对象写入建模结束
            
        }
        //单对象写入建模结束

    }
    //但是没有确定大文本对象的建模

    //频率建模结束

    //2、对应建模
    if(curr_node.identify_require >= 5)
    {
        unsigned int* ptr = node_find(id); // 头部位置

        //对应建模
        text_network.sum_identify_require;
        curr_node.identify_require;

        int Current_Attention_Object_List_size = Current_Attention_Object_List.size();

        for(int a = 0; a < Current_Attention_Object_List_size; a++)
        {
            Attention_Object& attention_object = Current_Attention_Object_List[a];
            //遍历全体节点下标

            attention_object.value;

            
        }
        
        //检验范式

        //计算在时间上的注意力累积

        //对应感认知，图像+时间+信念+注意力
        //用时间上的图像对象作对应，和用文本对象的空间位置作对应认知
        //或许，这个对应性要依靠函数的判断累积训练而成，
        
    }
    //对应建模结束

}//函数结束


//文本需求初始化函数
void init_text_require(vector< vector<int> >& retrieve_require, unsigned short text_size)
{
    int need_size = text_size;
    int need_layer = 1;

    while(need_size >= 8)// 计算所需层数
    {
        need_size /= 8;
        need_layer += 1;
    }

    retrieve_require.resize(need_layer);

    need_size = text_size;
    need_layer = 0;

    int retrieve_value = 10;
    int model_value = 10;

    while(need_size >= 8)// 计算层数数值
    {
        vector<int>& curr_retrieve_require = retrieve_require[need_layer];
        curr_retrieve_require.resize(need_size);

        for(int q = 0; q < text_size; q++)
        {
            curr_retrieve_require[q] = retrieve_value;
        }

        need_size /= 8;
        need_layer += 1;
        retrieve_value *= 8;
        model_value *= 8;
    }

    int lower_size = text_size;
    int lower_layer = 0;
    int upper_size = text_size / 8;
    int upper_layer = 1;

    bool new_upper_have = 0;

    char more_value;

    for(int w = 0; w < retrieve_require.size(); w++)//处理余数汇总
    {
        more_value = lower_size % 8;

        if(more_value > 0 || new_upper_have)
        {
            if(more_value == 0)//下层添加后的特殊情况
                more_value = 1;

            new_upper_have = 1;
            upper_size += 1;
            retrieve_require[upper_layer].resize(upper_size);

            vector<int>& lower_retrieve_require = retrieve_require[lower_layer];
            vector<int>& upper_retrieve_require = retrieve_require[upper_layer];

            int curr_require_size = lower_retrieve_require.size();

            int more_position = curr_require_size - more_value;

            //执行汇总
            while(more_value > 0)
            {
                upper_retrieve_require.back() += lower_retrieve_require[more_position];
                more_value -= 1;
                more_position += 1;
            }
            
        }//当层汇总结束

        lower_layer += 1;
        upper_layer += 1;
        lower_size = upper_size;
        upper_size = upper_size / 8;
    }
}


//建模对象挑选函数
uint32_t text_model_object_chose(vector< vector<int> >& model_require)
{
    //这个只适用于小规模优先对象，大规模不如直接遍历更节省
    char model_require_layer = model_require.size() - 1;
    int finally_idx = 0;
    int choose_value;
    int choose_idx;

    for(int q = model_require_layer; q >= 0; q--)
    {
        vector<int>& curr_model_require = model_require[model_require_layer];
        int curr_model_require_size = curr_model_require.size();

        choose_idx = 0;
        choose_value = curr_model_require[0];

        for(int w = 1; w < curr_model_require_size; w++)
        {
            if(choose_value < curr_model_require[w])
            {
                choose_value = curr_model_require[w];
                choose_idx = w;
            }
            
        }

        finally_idx = finally_idx*8 + choose_idx;
        model_require_layer--;
    }
return finally_idx;
}



//文本认知与演算函数
void Text_Cognition_Calculate(
    uint32_t curr_text_idx, short limit_time,
    uint32_t display_idx = 0)
{
    auto start = chrono::steady_clock::now();
    int elapsed_ms = 0;

    Text_Inference_Scene& curr_text_network = Text_Inference_Scene_Storage[curr_text_idx];
    vector<uint32_t>& original_text_list = curr_text_network.original_text_list;
    unsigned short text_size = original_text_list.size();

    vector< vector<int> > retrieve_require = curr_text_network.retrieve_require;
    vector< vector<int> > model_require = curr_text_network.model_require;

    // 1、初始化观测需求
    if(curr_text_network.have_init == 0)
    {
        init_text_require(retrieve_require, text_size);
        init_text_require(model_require, text_size);
        curr_text_network.have_init = 1;
    }
    //观测与建模需求汇总结束

    Gtk_Text_Display_Interface& gtk_interface = gtk3_text_display[display_idx];

    //若所处理文本为界面输入
    if(display_idx != 0)
    {
        vector<char>& input_string = gtk_interface.input_string_A;
        char& aim_kind = gtk_interface.response_kind;

        //1、转换格式
        int text_scene_idx = CharVector_To_Network(input_string, CURRENT_MODEL_TIME);
        Text_Inference_Scene& curr_network = Text_Inference_Scene_Storage[text_scene_idx];
        gtk_interface.Text_input_Inference_A_Idx = text_scene_idx;

        //2、填入意图
        // curr_purpose.constant = 1;
        // curr_purpose.purpose_object_detail_kind = 4;
        // curr_purpose.attention = interface_input.input_value_I[0];//优先程度，线程占用程度
    }

    // 2、随机工作任务
    random_device Task_RD;
    mt19937 Task_Gen(Task_RD());
    int task_work = 0;
    char un_fixed_task = 1;

    int satisfied_value = 0;

    while(elapsed_ms <= limit_time || satisfied_value > 100)
    {
        switch(task_work)
        {
            case 0:
            {
                //初始化工作，逐一原词检索激活

                for(int q = 0; q < text_size; q++)
                {
                    uint32_t i = original_text_list[q];
                    General_A_Neuro_Active(i, curr_text_idx, 2);
                    //节点未初始化标记

                    //并没有注意力控制
                }
                //原始文本激活结束
            }
            break;
            case 1://检索工作
            {
                //允许激活的节点再控制原文的检索工作，通过注意力/需求的方式

                //注意力控制

                //需求控制
                uint32_t chose_object_idx = text_model_object_chose(retrieve_require);

                //
                General_A_Neuro_Active(chose_object_idx, curr_text_idx, 2);

                //控制对心理其他空间的检索

            }
            break;
            case 2://建模工作
            {
                //对于有需求的激活节点，执行建模工作

                //挑选较大值建模对象
                uint32_t chose_object_idx = text_model_object_chose(model_require);
                //挑选建模对象结束

                uint32_t node_idx = original_text_list[chose_object_idx];
                General_Cognition_Node& curr_node = General_Cognition_Node_Storage[node_idx];

                //3.1频率对应建模
                if(curr_node.model_require >= 7)
                {
                    General_A_Neuro_Active(node_idx, curr_text_idx, 3);//优化建模
                    Text_A_Neuro_Model(node_idx, curr_text_idx);
                }

            }
            break;
            case 3://构造为文本工作
            {
                //对于相关目的，用于创建文本

                //只是id转化文本的实验
                Text_Inference_Scene& output_text_network = Text_Inference_Scene_Storage[gtk_interface.Text_output_Inference_Idx];

                uint32_t text_simu_virtual_scene_idx;
                General_Cognition_Scene text_simu_virtual_scene;
                
                uint32_t Purpose_Idx = gtk_interface.Purpose_Idx;
                General_Purpose& Cental_Purpose = General_Purpose_Focus_List[Purpose_Idx];
                General_Purpose& Current_Purpose = Cental_Purpose;

                vector<uint32_t> temporary_text_list;

                int curr_run = 1;

                int current_order = 0;

                //正在构造
                while(curr_run == 1 || elapsed_ms)
                {
                    Cental_Purpose.purpose_related_list;
                    Purpose_Related purpose_related = read_General_Purpose_need_id(Current_Purpose, current_order);

                    purpose_related.Require_object; // 需求对象
                    purpose_related.Require_value; // 

                    //
                    uint32_t new_node_idx = create_a_General_Cognition_Node();
                    General_Cognition_Node write_context;
                    /**/
                    write_a_General_Cognition_Node(new_node_idx, write_context);

                    push_back_a_node_to_General_Cognition_Scene(text_simu_virtual_scene_idx, new_node_idx);
                    //

                    //搜寻目的构造
                    vector<uint32_t> generate_list;


                    vector<Wait_Active_Neuro> wait_active_neuro_list;
                    vector<uint32_t> free_wait_active_neuro_idx;
                    
                    // 生成意图的下级节点
                    unsigned int* ptr = node_find(purpose_related.Require_object);

                    Neuro_Head_Attribute neuro_head = neuro_head_read(*ptr);
                    ptr += 16; // 指针转入特征位置

                    int neuro_item_num = neuro_head.used_item_num;
                    int fea = 0;

                    while( fea > neuro_item_num)
                    {
                        Attribute_Head attribute_head = attribute_head_get(ptr);

                        if(attribute_head.attribute_kind != 3)
                        {
                            ptr += attribute_head.item_num;
                            fea += attribute_head.item_num;

                        } else {
                            //成功生成下级
                            uint32_t gen_idx = create_a_General_Cognition_Node();
                            General_Cognition_Node node;
                            write_a_General_Cognition_Node(gen_idx, node);

                            //添加下级节点
                            generate_list.push_back(gen_idx);
                            //
                        }

                    }
                    //意图下级节点生成完成

                    //
                    vector<uint32_t> formation_node;

                    //排列全部需要的节点，尽量不违背构造的规则

                    get_a_General_Cognition_Scene();
                    General_Cognition_Scene primitive_scene;

                    unordered_map<unsigned int, vector<uint32_t> > hash_find_id_to_idx;
                    hash_find_id_to_idx.reserve( formation_node.size() );

                    //1、记录存在字符的查询
                    for(uint32_t idx : formation_node)
                    {
                        unsigned int id = read_a_General_Cognition_Node(idx).self_id;
                        hash_find_id_to_idx[id].push_back(idx);
                    }

                    //2、生成必需下层，类别可能性下层，文本对应
                    for(uint32_t idx : formation_node)
                    {
                        unsigned int id = read_a_General_Cognition_Node(idx).self_id;
                        unsigned int* ptr = node_find(id);

                        Neuro_Head_Attribute neuro_head = neuro_head_read(*ptr);
                        ptr += 16; // 指针转入特征位置

                        int neuro_item_num = neuro_head.used_item_num;
                        int fea = 0;

                        while(fea > neuro_item_num)
                        {
                            Attribute_Head attribute_head = attribute_head_get(ptr);
                            if(attribute_head.attribute_kind == 3);
                            {
                                ;
                            }
                        }
                    }
                    

                    //3、加入每个字符
                    for(uint32_t node_idx : formation_node)
                    {
                        unsigned int id = read_a_General_Cognition_Node(node_idx).self_id;
                        unsigned int* ptr = node_find(id);

                        Neuro_Head_Attribute neuro_head = neuro_head_read(*ptr);
                        ptr += 16; // 指针转入特征位置

                        int neuro_item_num = neuro_head.used_item_num;
                        int fea = 0;

                        while(fea > neuro_item_num)
                        {
                            Attribute_Head attribute_head = attribute_head_get(ptr);

                            /* 节点必为节点肯定必有他的组成部分，这是硬性合理性
                            节点为熟悉的节点那就应该有很多他的高推测对象在附近, 这是软性合理性
                            所以文本节点最好在满足排列元素之后，越符合推测对象越高合理性
                            */

                            //概率属性
                            if(attribute_head.attribute_kind == 1)
                            {
                                unsigned int stat_id = *(ptr + attribute_head.item_num);

                                //找到可能的连接对象
                                if( hash_find_id_to_idx.count(stat_id) )
                                {
                                    vector<uint32_t>& node_idx_list = hash_find_id_to_idx[stat_id];

                                    //如果有可连接节点的话
                                    for(uint32_t link_idx: node_idx_list)
                                    {
                                        Text_Item text_require = *(Text_Item*)(ptr + 3);
                                        text_require.logic = 1;
                                        text_require.target_id = link_idx;//此时作idx
                                        Flexible_Object flexible_object = {.simulate_text_require = text_require};\

                                        push_back_a_flexible_object_to_General_Cognition_Node(node_idx, flexible_object);

                                        //在模拟中对相同id可以考虑合一
                                    }
                                }
                                
                            } else if (attribute_head.attribute_kind == 3) {
                                //下属属性
                            }

                            fea += attribute_head.item_num;
                            ptr += attribute_head.item_num;

                        }
                        //属性遍历结束

                    }


                    //4、网络组织排列尝试
                    for(int a = 0; a < formation_node.size(); a++)
                    {
                        uint32_t idx = formation_node[a];
                        General_Cognition_Node node = read_a_General_Cognition_Node(idx);

                        //直接 一般情况下

                        text_operate(curr_text_idx, temporary_text_list, 123, 456 ,0);

                        //先固定排列，再插入排列

                        //排列奖励优势

                        //查找前列元素
                        deque<uint32_t> output_element;
                    }
                    
                }

                //文本构造的方法
                //目的对象 转化 文本形态 并且 规则排列

            }
            case 4://文本构造为图像
            {
                ;
            }
            break;
            case 11://解释               对应性检索
            {
                //查找原文对应实体
                un_fixed_task = 0;
                task_work = 3;

                //转化文本相关(情景回答)
                //评估量 相关值()
                //统计指标：关注度 清楚度 合理性
                //追求指标：行动欲 求知欲 理解欲
            }
            break;
            case 12://回答           检索+构造
            {
                //解释定位
                //推演 + 结果文本化
                //情景转化文本 + 推理状态(纯推演/有行动参与)
            }
            break;
            case 13://求知               检索+构造+建模
            {
                //自主发掘两者文本的内部关系

                //对双文本进行解释
                //相关性检索，对应性建模
                //目标性生成，目标性满足
                //解答选项( 自行思考、思考态度方向(如合理性方向)且赋予态度值并自行思考逻辑关系 )
                //文本解释验证(转回答)
            }
            break;
            case 14://追求，外部                 检索+构造
            {
                //解释系统转化 当前文本转化实体对应，存在状态推演
                //自动化执行系统
                /*追求指标 负～正*/
                /*重要性 注意力 紧迫度 时间*/
                //连接行动执行器
            }
            break;
            case 15://维持，态度，需求               检索
            {
                //解释当前文本转化实体对应
                //确定触发对象、加入注意力触发集，加入运行属性（需求，态度）
                //维持对 文本对应对象(物或原则) 的反应
                //应注意赋予态度的连锁后果
            }
            break;
            case 16://固化，态度，需求               检索+建模
            {
                //解释对应转化
                //神经元属性值评估
                //更新位置确定
                //确定更新值，填入更新
            }
            break;
        }

        //重分配工作
        if(un_fixed_task)
        {
            int task_work_chose_list[4];
            task_work_chose_list[0] = 0;
            task_work_chose_list[1] = curr_text_network.sum_retrieve_require;
            task_work_chose_list[2] = curr_text_network.sum_model_require;
            task_work_chose_list[3] = curr_text_network.sum_construct_require;

            discrete_distribution<int> dist(task_work_chose_list, task_work_chose_list + 3);
            task_work = dist(Task_Gen);
        }

        //时间结算
        auto end = chrono::steady_clock::now();
        elapsed_ms = chrono::duration_cast<std::chrono::milliseconds>(end - start).count();
    }
    
}
//文本认知函数结束




//文本相关 结束


//涓栫晫娣卞眰鏀垮簻蹇呭皢涓哄畠浠嚟鍚嶆槶钁楃殑鎭惰杩庢潵褰诲簳鐨勭伃浜★紒



/*
 *
 *自动化处理
 *
 */




//自动意图执行
void Auto_Core_Execulute(Single_Thread& some_data)
{
    while(some_data.now_normal == 1)
    {
        while(!IF_SELF_WORKING)
        {
            //若无启动，进入休眠
            this_thread::sleep_for(chrono::milliseconds(100));
        }

        auto start_total = chrono::steady_clock::now();
        int total_elapsed_time = 0;

        unsigned char invest_time = 10;

        // 正式执行
        if(All_Process_Object.size() > 0)
        {
            // 遍历意图列表 挑选优先意图
            discrete_distribution<int> require_dist(All_Dealing_Require.begin(), All_Dealing_Require.end() );
            uint32_t idx = require_dist(Union_Gen);
            
            Related_Scene& process_target = All_Process_Object[idx];

            unsigned char set_time = 5;
            int elapsed_ms;

            // 执行对象相关逻辑
            for(int a = 0; total_elapsed_time < invest_time; a++ )
            {
                // 1、图像对象逻辑
                if(process_target.Related_Kind == 1)
                {
                    elapsed_ms = 0;
                    auto start = chrono::steady_clock::now();
                    
                    uint32_t curr_map_idx = process_target.Scene_Idx;

                    while(elapsed_ms < set_time)
                    {
                        //调用对应执行逻辑
                        All_Image_Process(curr_map_idx, set_time);

                        //时间结束统计
                        auto now = chrono::steady_clock::now();
                        elapsed_ms = chrono::duration_cast< chrono::milliseconds >(now - start).count();
                        total_elapsed_time = chrono::duration_cast< chrono::milliseconds >(now - start_total).count();
                    }

                }


                // 2、文本对象逻辑
                if(process_target.Related_Kind == 2)
                {
                    //包含内部输入
                    elapsed_ms = 0;
                    auto start = chrono::steady_clock::now();
                    
                    uint32_t curr_text_idx = process_target.Scene_Idx;
                    Text_Inference_Scene& curr_text = Text_Inference_Scene_Storage[curr_text_idx];

                    while(elapsed_ms < set_time)
                    {
                        Text_Cognition_Calculate(curr_text_idx, set_time);

                        //时间结束统计
                        auto now = chrono::steady_clock::now();
                        elapsed_ms = chrono::duration_cast< chrono::milliseconds >(now - start).count();
                        total_elapsed_time = chrono::duration_cast< chrono::milliseconds >(now - start_total).count();
                    }
                }

                
                // 3、推理对象逻辑
                {
                    elapsed_ms = 0;
                    
                    while(elapsed_ms < set_time)
                    {
                        auto start = chrono::steady_clock::now();

                        //行为目标
                        More_Motion_Calculate_And_Execulate(process_target.Scene_Idx, set_time);

                        auto now = chrono::steady_clock::now();
                        elapsed_ms = chrono::duration_cast< chrono::milliseconds >(now - start).count();
                        total_elapsed_time = chrono::duration_cast< chrono::milliseconds >(now - start_total).count();

                    }// 推算逻辑结束
                }
                
            }// 时间结束

        }

        // 休眠-降低功耗
        if(some_data.need_free_time >= 30)
        {
            auto begin = chrono::steady_clock::now();
            this_thread::sleep_for(chrono::milliseconds(some_data.need_free_time));
            auto end = chrono::steady_clock::now();
            int duration = chrono::duration_cast< chrono::milliseconds >(end - begin).count();
            some_data.need_free_time - duration;
        }

    }//重复执行直到线程销毁

}
//当前线程执行结束

