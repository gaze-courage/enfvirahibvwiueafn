#include <gtk/gtk.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>

#include "Top.hpp"

/*
运算端gui为gtk3，
读写路径为Linux
*/

const int SEND_PORT = 5095; // 对方接收端口
string IP = "10.43.79.101"; // 对方ip
const long long VERIFICATION = 0b01010101010101010101010101010101; // 校验码
int Last_Gap_Model_Time = -1;
int Gap_Model_Time = -1;

// 接收概览
struct recv_overview
{
    unsigned short width;    // 图片宽度
    unsigned short height;   // 图片高度
    unsigned short text_num; // 文本长度
    long long code_time;     // 程序时间
}; // 14字节

// 发送概览
struct send_instruct
{
    char if_need_working;
    char if_need_communication;
    char if_need_action;
    char if_need_capture;
    char action_num;
    unsigned short text_num; // 文本长度
    long long model_time;    // 模型时间
}; // 15字节

vector<RGB_Unit> Receive_PixelMap; // 接受像素图
char Receive_Pixel_Map_State = 0;  // 0未填充数据，1未被读取过，2已被读取过
unsigned short Pixel_Map_Height;
unsigned short Pixel_Map_Weight;

const char text_11[12] = "无通信";
const char text_12[12] = "通信中";
const char text_21[20] = "模型无运行";
const char text_22[20] = "模型运行中";
char text_57[24] = "文本项目输入";
char text_58[24] = "文本项目显示";
char text_513[24] = "文本项目回答";

// 创建容器
struct gtkwidgt_group
{
    vector<GtkWidget *> widget;
    vector<char> kind; // string 1, int 2, long long 3
    vector<void *> number_or_string;
};

gtkwidgt_group update_group;   // 自动更新组
gtkwidgt_group inoutput_group; // 输入输出组
gtkwidgt_group flow_group;     // 流动变更组

/*
 * 弹窗
 * parent : 父窗口（一般传主窗口）
 * title  : 标题
 * message: 内容
 */
char show_message(GtkWidget *parent,
    const char *title,
    const char *message)
{
    GtkWidget *dialog = gtk_message_dialog_new(
        GTK_WINDOW(parent),
        GTK_DIALOG_MODAL,     // 模态窗口
        GTK_MESSAGE_QUESTION, // 类型：消息 INFO
        GTK_BUTTONS_YES_NO,   // OK 按钮
        "%s", message         // 内容
    );

    gtk_window_set_title(GTK_WINDOW(dialog), title);

    gint response = gtk_dialog_run(GTK_DIALOG(dialog)); // 等待用户点击
    // GtkResponseType;

    char return_value = 0;
    switch (response)
    {
    case -8: // GTK_RESPONSE_YES          = -8,
        return_value = 1;
        break;

    case -9: // GTK_RESPONSE_NO           = -9,
        return_value = 0;
        break;
    }

    gtk_widget_destroy(dialog);

    return return_value;
}
//弹窗函数结束


// 通讯线程
void Socket_Thread()
{
    Watting_Action_List.reserve(5);

    // 设置收发用数组
    vector<char> Send_Vector;
    Send_Vector.reserve(512 * 1024);

    vector<char> Recv_Vector;
    Recv_Vector.reserve(512 * 1024);

    Receive_PixelMap.reserve(4 * 1024 * 3 * 1024);
    Send_Text_List.reserve(64 * 1024);
    Receive_Text_List.reserve(64 * 1024);

    // 创建 socket
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);

    if (sockfd < 0)
    {
        perror("[发送线程] socket 创建失败");
        return;
    }

    // 设置服务器地址
    sockaddr_in server{};
    server.sin_family = AF_INET;
    server.sin_port = htons(SEND_PORT);
    inet_pton(AF_INET, IP.c_str(), &server.sin_addr);

    // 设置发送缓冲区大小
    int sndbuf = 512 * 1024; // 512KB
    setsockopt(sockfd, SOL_SOCKET, SO_SNDBUF, (char *)&sndbuf, sizeof(sndbuf));

    // 设置接收缓冲区大小
    int rcvbuf = 30 * 1024 * 1024; // 30 MB
    setsockopt(sockfd, SOL_SOCKET, SO_RCVBUF, (char *)&rcvbuf, sizeof(rcvbuf));

    while (IF_SELF_TURN_OFF)
    {
        if (IF_SELF_COMMUNIATE && IF_SELF_CONNECT == 0)
        {
            // 连接执行端
            while (connect(sockfd, (sockaddr *)&server, sizeof(server)) < 0)
            {
                perror("[发送线程] 连接失败");
                sleep(100);
                IF_SELF_CONNECT = 1;
            }
        }

        while (IF_SELF_COMMUNIATE && IF_SELF_CONNECT)
        {
            // 连接成功，开始发送

            //"通信中"
            GtkTextBuffer *buffer = gtk_text_view_get_buffer((GTK_TEXT_VIEW(inoutput_group.widget[2])));
            gtk_text_buffer_set_text(buffer, text_12, -1);

            // 1、发送校验码
            Send_Vector.insert(Send_Vector.end(), (char *)&VERIFICATION, (char *)&VERIFICATION + 8);

            send_instruct si;
            si.if_need_working = IF_NEED_WORKING;
            si.if_need_communication = IF_NEED_COMMUNIATE;
            si.if_need_capture = IF_NEED_CAPTURE;
            si.if_need_action = IF_NEED_ACTION;
            si.action_num = Watting_Action_List.size();
            si.text_num = Send_Text_List.size();
            si.model_time = CURRENT_MODEL_TIME;

            // 2 、设置发送数据概览
            Send_Vector.insert(Send_Vector.end(), (char *)&si.if_need_working, (char *)&si.if_need_working + 1);
            Send_Vector.insert(Send_Vector.end(), (char *)&si.if_need_communication, (char *)&si.if_need_communication + 1);
            Send_Vector.insert(Send_Vector.end(), (char *)&si.if_need_action, (char *)&si.if_need_action + 1);
            Send_Vector.insert(Send_Vector.end(), (char *)&si.if_need_capture, (char *)&si.if_need_capture + 1);
            Send_Vector.insert(Send_Vector.end(), (char *)&si.action_num, (char *)&si.action_num + 1);
            Send_Vector.insert(Send_Vector.end(), (char *)&si.text_num, (char *)&si.text_num + 2);

            Send_Vector.insert(Send_Vector.end(), (char *)&si.model_time, (char *)&si.model_time + 8);

            // 填入指令数据
            Send_Vector.insert(Send_Vector.end(), (char *)Watting_Action_List.data(), (char *)Watting_Action_List.data() + 12 * si.action_num);
            Watting_Action_List.clear();

            // 填入文本数据
            Send_Vector.insert(Send_Vector.end(), (char *)Send_Text_List.data(), (char *)Send_Text_List.data() + sizeof(char) * si.text_num);

            // 3、发送数据
            send(sockfd, (char *)Send_Vector.data(), Send_Vector.size(), 0);
            Send_Text_List.clear();
            Send_Vector.clear();

            // 开始准备接收校验码
            int v = 0;
            int verification_count = 0;

            do
            {
                recv(sockfd, &v, 8, 0);
                verification_count += 1;
                if (verification_count > 1)
                {
                    // 丢包了，还没写这种情况该怎么办
                    show_message(inoutput_group.widget[0], "严重错误", "网络传输丢包");

                    IF_SELF_COMMUNIATE = 0; // 关闭通信
                    IF_NEED_COMMUNIATE = 0;
                    IF_NEED_CAPTURE = 0;
                    IF_NEED_ACTION = 0;

                    GtkTextBuffer *buffer = gtk_text_view_get_buffer((GTK_TEXT_VIEW(inoutput_group.widget[2])));
                    gtk_text_buffer_set_text(buffer, text_11, -1);
                }

            } while (v != VERIFICATION);

            verification_count = 0;

            Last_Gap_Model_Time = stat_gap_time();

            // 4、接收数据
            recv_overview ro;
            recv(sockfd, Recv_Vector.data(), 16, 0);

            memcpy((char *)&ro.width, Recv_Vector.data(), 2);
            memcpy((char *)&ro.height, Recv_Vector.data() + 2, 2);
            memcpy((char *)&ro.text_num, Recv_Vector.data() + 4, 2);
            memcpy((char *)&ro.code_time, Recv_Vector.data() + 6, 8);
            Recv_Vector.clear();

            if (ro.width > 4000 || ro.height > 3000)
            {
                // 长宽数值不对，收错包，或尺寸过大
                cout << "图片接收错误" << endl;
            }

            Pixel_Map_Height = ro.height;
            Pixel_Map_Weight = ro.width;

            int give_attention = 1 + Free_Total_Task_Attention / 3;

            // 4-1、接收图片数据
            if (ro.width * ro.height != 0)
            {
                Receive_PixelMap.resize(ro.width * ro.height);
                int already_read = 0; // recv函数就是不行一次性读完
                while (already_read < ro.width * ro.height * 3)
                {
                    already_read += recv(sockfd, (char *)Receive_PixelMap.data() + already_read, ro.width * ro.height * 3 - already_read, 0); // 接收图片数据
                }

                uint32_t idx = get_a_Map_Analysis();
                Map_Analysis_Scene new_map = Map_Analysis_Scene_Storage[idx];
                new_map.RGB_Map = Receive_PixelMap;
                new_map.width = Pixel_Map_Weight;
                new_map.height = Pixel_Map_Height;
                New_Map_Analysis_Index.push_back(idx);

                // 产生目的
                uint32_t pur_idx = create_a_General_Purpose();
                General_Purpose &new_purpose = General_Purpose_Focus_List[pur_idx];

                new_purpose.attention = give_attention;
                Free_Total_Task_Attention -= give_attention;
            }

            give_attention = 1 + Free_Total_Task_Attention / 3;

            // 4-2、接收文本数据
            if (ro.text_num != 0)
            {
                int already_read = 0;
                while (already_read < ro.width * ro.height * 3)
                {
                    already_read += recv(sockfd, Receive_Text_List.data() + already_read, ro.text_num - already_read, 0);
                }

                uint32_t idx = CharVector_To_Network(Receive_Text_List, CURRENT_MODEL_TIME);
                Receive_Text_List.clear();
                Text_Inference_Scene new_text = Text_Inference_Scene_Storage[idx];

                // 产生目的
                uint32_t pur_idx = create_a_General_Purpose();
                General_Purpose &new_purpose = General_Purpose_Focus_List[pur_idx];

                new_purpose.attention = give_attention;
                Free_Total_Task_Attention -= give_attention;
            }

            //                             //
            // 数据接收完毕 //
            //                             //
        }

        if (IF_SELF_COMMUNIATE == 0)
        {
            sleep(10);
        }
    }

    close(sockfd);
}
// 终端通讯线程结束

// 硬盘读写线程
void Disk_Thread()
{
    char Require_Read_Level = 0;
    char Require_Write_Level = 0;
    short Read_Require = 0;
    short Write_Require = 0;

    while (IF_SELF_TURN_OFF)
    {
        while (IF_SELF_WORKING == 0)
        {
            sleep(10); // 等待10ms
        }

        Read_Require = Will_Read_Neuro_Queue.size();
        Write_Require = Will_Write_Neuro_Queue.size();

        int order = 0;

        if (Read_Require > 5)
            Require_Read_Level = 5;
        else
            Require_Read_Level = Read_Require;

        if (Read_Require + Write_Require)
        {
            // 读入
            while (order < Require_Read_Level)
            {
                string target_path = "Neuro/";
                target_path += VariableToPath(Will_Read_Neuro_Queue[0]);

                FILE *R_file = fopen(target_path.c_str(), "r");

                int head;
                int *head_ptr = &head;
                fread(head_ptr, 4, 1, R_file);

                Neuro_Head_Attribute head_info = neuro_head_read(head);

                int index = pack_position_insert(Will_Read_Neuro_Queue[0], head_info.node_size);
                unsigned int *ptr = Neuro_Pack_Storage[index].attribute_item;

                fread(ptr, 256*head_info.node_size, 1, R_file);
                // 读取结束

                Will_Read_Neuro_Queue.pop_front();
                fclose(R_file);

                neuro_use_record_update(Will_Read_Neuro_Queue[0]);
                order++;
            }

            order = 0;

            if (Write_Require > 5)
                Require_Write_Level = 5;
            else
                Require_Write_Level = Write_Require;

            // 写入
            while (order < Require_Write_Level)
            {
                string target_path = "Neuro/";
                target_path += VariableToPath(Will_Write_Neuro_Queue[0]);

                FILE *W_file = fopen(target_path.c_str(), "w");

                int index = pack_index_find(Will_Write_Neuro_Queue[0]);
                unsigned int *ptr = Neuro_Pack_Storage[index].attribute_item;

                char pack_size = Neuro_Pack_Record_Storage[index].pack_size;

                fwrite(ptr, 256*pack_size, 1, W_file);
                // 写入结束
                
                pack_delete(Will_Write_Neuro_Queue[0]);

                Will_Write_Neuro_Queue.pop_front();
                fclose(W_file);
                order++;
            }
        }
        else
        { // 队列为空
            sleep(1);
        }
    }

} // 硬盘读写线程结束

// 线程设置函数
// num：线程数量
void setup_thread(unsigned char num)
{
    char change_num = num - Calculate_Thread_Num;

    while (change_num > 0)
    {
        if (Thread_Handle_List.size() < num)
        {
            Single_Thread reduce_thread;
            Thread_Handle_List.push_back(reduce_thread);
            thread cal(Auto_Core_Execulute, ref(Thread_Handle_List.back()));
            cal.detach();
        }
        else
        {
            char n = 0;
            while (Thread_Handle_List[n].now_normal == 1)
                n++;

            Thread_Handle_List[n].now_normal = 1;
            thread cal(Auto_Core_Execulute, ref(Thread_Handle_List[n]));
            cal.detach();
        }

        change_num--;
        Calculate_Thread_Num++;
        Use_Thread_Num++;
        Total_Task_Attention += 100;
        Free_Total_Task_Attention += 100;
    }

    while (change_num < 0)
    {
        Thread_Handle_List[Calculate_Thread_Num - 1].now_normal = 0;
        Thread_Handle_List[Calculate_Thread_Num - 1].need_free_time = 0;
        Thread_Handle_List[Calculate_Thread_Num - 1].future_invest = 0;
        Thread_Handle_List[Calculate_Thread_Num - 1].task.clear();

        change_num++;
        Calculate_Thread_Num--;
        Use_Thread_Num--;
        Total_Task_Attention -= 100;
        Free_Total_Task_Attention -= 100;
    }

    return;
}

// 按钮事件触发
static void on_button_clicked(GtkWidget *widget, gpointer data)
{
    int msg = GPOINTER_TO_INT(data);

    switch (msg)
    {
    case 1: // 展开通信
        IF_SELF_COMMUNIATE = 1;
        IF_NEED_COMMUNIATE = 1;

        break;
    case 2: // 展开运行
    {
        IF_SELF_WORKING = 1;

        GtkTextBuffer *buffer = gtk_text_view_get_buffer((GTK_TEXT_VIEW(inoutput_group.widget[3])));
        gtk_text_buffer_set_text(buffer, text_22, -1);
        gtk_widget_hide(inoutput_group.widget[5]);
        gtk_widget_show(inoutput_group.widget[4]);
    }
    break;

    case 3: // 允许图片
        IF_NEED_CAPTURE = 1;

        break;
    case 4: // 允许活动
        IF_NEED_ACTION = 1;

        break;
    case 5: // 设置线程
    {
        GtkWidget *text_view = inoutput_group.widget[6];
        GtkTextBuffer *buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(text_view));
        GtkTextIter start, end;
        gtk_text_buffer_get_start_iter(buffer, &start);
        gtk_text_buffer_get_end_iter(buffer, &end);
        gchar *text = gtk_text_buffer_get_text(buffer, &start, &end, FALSE);
        char **endptr;
        int n = strtol(text, endptr, 10);
        g_free(text);

        if (n <= 10)
        {
            if (n <= 0)
            {
                n = 0;
                bool right = show_message(inoutput_group.widget[0], "提示", "输入值要为0？");
                if (right == 1)
                    setup_thread(0);
            }
            else
                setup_thread(n);
        }
        else
        {
            bool right = show_message(inoutput_group.widget[0], "提示", "最大值为10");
            setup_thread(10);
        }
    }

    break;
    case 6: // 执行 文本操作
    {
        GtkWidget *text_view_1 = inoutput_group.widget[7]; // 获取文本
        GtkTextBuffer *buffer_1 = gtk_text_view_get_buffer(GTK_TEXT_VIEW(text_view_1));
        GtkTextIter start, end;
        gtk_text_buffer_get_start_iter(buffer_1, &start);
        gtk_text_buffer_get_end_iter(buffer_1, &end);
        gchar *text = gtk_text_buffer_get_text(buffer_1, &start, &end, FALSE);
        char **endptr;
        string str_curr(text);
        vector<char> text_cur(str_curr.begin(), str_curr.end());
        g_free(text);

        GtkWidget *text_view_2 = inoutput_group.widget[9]; // 获取操作指令
        GtkTextBuffer *buffer_2 = gtk_text_view_get_buffer(GTK_TEXT_VIEW(text_view_2));
        gtk_text_buffer_get_end_iter(buffer_2, &end);
        text = gtk_text_buffer_get_text(buffer_2, &start, &end, FALSE);
        int kind = strtol(text, endptr, 10);
        g_free(text);
        if (kind <= 0 || kind >= 7)
        {
            show_message(inoutput_group.widget[0], "提示", "输入值为0");
            break;
        }

        // 创建意图
        uint32_t i = create_a_General_Purpose();
        General_Purpose &macro_purpose_group = General_Purpose_Focus_List[i];

        uint32_t idx = get_a_gtk3_text_display();

        // 添入显示
        gtk3_text_display[idx].input_string_A = text_cur;

    }

    break;

    case 7: // 删除 文本操作
    {
        // 更新显示
        GtkWidget *text_view_1 = inoutput_group.widget[12]; // 获取编号
        GtkTextBuffer *buffer_1 = gtk_text_view_get_buffer(GTK_TEXT_VIEW(text_view_1));
        GtkTextIter start, end;
        gtk_text_buffer_get_start_iter(buffer_1, &start);
        gtk_text_buffer_get_end_iter(buffer_1, &end);
        gchar *text = gtk_text_buffer_get_text(buffer_1, &start, &end, FALSE);
        char **endptr;
        long number = strtol(text, endptr, 10);
        g_free(text);

        if (number < 0 || number > gtk3_text_display.size())
        {
            show_message(inoutput_group.widget[0], "提示", "输入值为0");
            break;
        }

        // 删除意图
        clear_a_gtk3_text_display(number);
    }

    break;

    case 8: // 内存允许上限
    {
        GtkWidget *text_view = inoutput_group.widget[7];
        GtkTextBuffer *buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(text_view));
        GtkTextIter start, end;
        gtk_text_buffer_get_start_iter(buffer, &start);
        gtk_text_buffer_get_end_iter(buffer, &end);
        gchar *text = gtk_text_buffer_get_text(buffer, &start, &end, FALSE);
        char **endptr;
        int n = strtol(text, endptr, 10);
        g_free(text);

        // 没写什么后果
    }

    break;

    case 9: // 当前包上限
    {
        GtkWidget *text_view = inoutput_group.widget[8];
        GtkTextBuffer *buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(text_view));
        GtkTextIter start, end;
        gtk_text_buffer_get_start_iter(buffer, &start);
        gtk_text_buffer_get_end_iter(buffer, &end);
        gchar *text = gtk_text_buffer_get_text(buffer, &start, &end, FALSE);
        char **endptr;
        int n = strtol(text, endptr, 10);
        g_free(text);

        Pack_Limit = n * 10000;
        Neuro_Pack_Storage.reserve(Pack_Limit);
        Pack_Vector_Index_Find.reserve(Pack_Limit);
    }

    break;

    case 0:

        break;

    case -1:
    {
        IF_SELF_COMMUNIATE = 0; // 关闭通信
        IF_NEED_COMMUNIATE = 0;
        IF_NEED_CAPTURE = 0;
        IF_NEED_ACTION = 0;

        GtkTextBuffer *buffer = gtk_text_view_get_buffer((GTK_TEXT_VIEW(inoutput_group.widget[2])));
        gtk_text_buffer_set_text(buffer, text_11, -1);
    }

    case -2:
    {
        IF_SELF_WORKING = 0;
        IF_NEED_CAPTURE = 0;
        IF_NEED_ACTION = 0;

        GtkTextBuffer *buffer = gtk_text_view_get_buffer((GTK_TEXT_VIEW(inoutput_group.widget[1])));
        gtk_text_buffer_set_text(buffer, text_21, -1);
        gtk_widget_hide(inoutput_group.widget[4]);
        gtk_widget_show(inoutput_group.widget[5]);
    }

    break;

    case -3:
        IF_NEED_CAPTURE = 0;

        break;

    case -4:
        IF_NEED_ACTION = 0;

        break;
    }
}

/*
 * create_button
 * parent : 必须是 GtkFixed 容器
 * left,right,top,bottom : 边界
 * msg : 点击按钮返回消息值
 */
GtkWidget *create_button(GtkWidget *parent,
    int left, int right,
    int top, int bottom,
    int msg,
    const char *text)
{
    GtkWidget *button = gtk_button_new_with_label(text);

    int width = right - left;
    int height = bottom - top;

    gtk_widget_set_size_request(button, width, height);

    // 绝对定位
    gtk_fixed_put(GTK_FIXED(parent), button, left, top);

    // 点击时返回 msg
    g_signal_connect(button, "clicked",
                     G_CALLBACK(on_button_clicked),
                     GINT_TO_POINTER(msg));

    gtk_widget_show(button);
    return button;
}

/*
 * 数字显示控件
 * parent  : GtkFixed 容器
 * left,right,top,bottom : 边界
 * value   : 初始数字
 *
 * 返回 GtkWidget*（以后可以用它修改显示内容）
 */
GtkWidget *create_number_display(GtkWidget *parent,
    int left, int right,
    int top, int bottom)
{
    long long init_value = 0;

    GtkWidget *label = gtk_label_new(NULL);

    char buf[32];
    snprintf(buf, sizeof(buf), "%d", init_value);
    gtk_label_set_text(GTK_LABEL(label), buf);

    int width = right - left;
    int height = bottom - top;

    gtk_widget_set_size_request(label, width, height);

    // 让文字居中（GTK3）
    gtk_label_set_xalign(GTK_LABEL(label), 0.5);
    gtk_label_set_yalign(GTK_LABEL(label), 0.5);

    gtk_fixed_put(GTK_FIXED(parent), label, left, top);

    gtk_widget_show(label);
    return label;
}

/* 阻止非数字输入（只允许 0~9 和退格） */
static void only_allow_digits(GtkEditable *editable,
    const gchar *text,
    gint length,
    gint *position,
    gpointer data)
{
    for (int i = 0; i < length; i++)
    {
        if (text[i] < '0' || text[i] > '9')
        {
            g_signal_stop_emission_by_name(editable, "insert-text");
            return;
        }
    }
}

/*
 * 数字输入框
 * parent  : GtkFixed 容器
 * left,right,top,bottom: 边界
 * init_value : 初始数值
 *
 * 返回 GtkWidget*，以后可以读取 / 修改
 */
GtkWidget *create_number_input(
    GtkWidget *parent,
    int left, int right,
    int top, int bottom,
    long init_value)
{
    GtkWidget *entry = gtk_entry_new();

    int width = right - left;
    int height = bottom - top;

    gtk_widget_set_size_request(entry, width, height);

    // 设置初始值
    char buf[32];
    snprintf(buf, sizeof(buf), "%d", init_value);
    gtk_entry_set_text(GTK_ENTRY(entry), buf);

    // 限制只能输入数字
    g_signal_connect(entry, "insert-text", G_CALLBACK(only_allow_digits), NULL);

    gtk_fixed_put(GTK_FIXED(parent), entry, left, top);
    gtk_widget_show(entry);

    return entry;

    // 未知故障：输入数字后使用转换函数读取卡死，转用文本输入框(输入文本时归零)
    // gtk_entry_get_text(GTK_ENTRY( entry ));
}

/*
 * 文本显示框
 * parent  : GtkFixed 容器
 * left,right,top,bottom : 边界
 * text    : 初始文本
 *
 * 返回 GtkWidget*（TextView）
 */
GtkWidget *create_text_fixed_display(GtkWidget *parent,
    int left, int right,
    int top, int bottom,
    const char *text)
{
    GtkWidget *textview = gtk_text_view_new();

    int width = right - left;
    int height = bottom - top;

    gtk_widget_set_size_request(textview, width, height);

    // 不允许编辑
    gtk_text_view_set_editable(GTK_TEXT_VIEW(textview), FALSE);
    gtk_text_view_set_cursor_visible(GTK_TEXT_VIEW(textview), FALSE);

    // 自动换行
    gtk_text_view_set_wrap_mode(GTK_TEXT_VIEW(textview), GTK_WRAP_WORD_CHAR);

    // 设置初始文本
    GtkTextBuffer *buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(textview));
    gtk_text_buffer_set_text(buffer, text, -1);

    gtk_fixed_put(GTK_FIXED(parent), textview, left, top);
    gtk_widget_show(textview);

    return textview;
}

// 滚动型文本显示框
GtkWidget *create_text_flowed_display(
    GtkWidget *parent,
    int left, int right,
    int top, int bottom,
    const char *text)
{
    int width = right - left;
    int height = bottom - top;

    // 滚动窗口
    GtkWidget *scrolled = gtk_scrolled_window_new(NULL, NULL);
    gtk_widget_set_size_request(scrolled, width, height);

    // 允许显示滚动条（自动策略）
    gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrolled),
                                   GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);

    // TextView
    GtkWidget *textview = gtk_text_view_new();
    gtk_text_view_set_editable(GTK_TEXT_VIEW(textview), FALSE);
    gtk_text_view_set_cursor_visible(GTK_TEXT_VIEW(textview), FALSE);
    gtk_text_view_set_wrap_mode(GTK_TEXT_VIEW(textview), GTK_WRAP_WORD_CHAR);

    // 设置文本
    GtkTextBuffer *buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(textview));
    gtk_text_buffer_set_text(buffer, text, -1);

    // 把 TextView 放进滚动框
    gtk_container_add(GTK_CONTAINER(scrolled), textview);

    // 放入父容器
    gtk_fixed_put(GTK_FIXED(parent), scrolled, left, top);

    gtk_widget_show_all(scrolled);

    return textview; // 返回 textview，方便以后更新文本
}

/*
 * 文本输入框
 * parent  : GtkFixed 容器
 * left,right,top,bottom : 边界
 * init_text : 初始文本
 *
 * 返回 GtkWidget*（TextView）
 */
GtkWidget *create_text_input(GtkWidget *parent,
    int left, int right,
    int top, int bottom,
    const char *init_text)
{
    GtkWidget *textview = gtk_text_view_new();

    int width = right - left;
    int height = bottom - top;

    gtk_widget_set_size_request(textview, width, height);

    // 允许编辑
    gtk_text_view_set_editable(GTK_TEXT_VIEW(textview), TRUE);
    gtk_text_view_set_cursor_visible(GTK_TEXT_VIEW(textview), TRUE);

    // 自动换行
    gtk_text_view_set_wrap_mode(GTK_TEXT_VIEW(textview), GTK_WRAP_WORD_CHAR);

    // 设置初始文本
    GtkTextBuffer *buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(textview));
    gtk_text_buffer_set_text(buffer, init_text, -1);

    gtk_fixed_put(GTK_FIXED(parent), textview, left, top);
    gtk_widget_show(textview);

    return textview;
}

// 函数-时间统一更新
gboolean update_timeout(gpointer user_data)
{
    GtkWidget *label;
    char kind;

    Code_Time += 100;

    if (IF_SELF_WORKING)
    {
        CURRENT_MODEL_TIME += 100;
        time_out_clean();
    }

    if (*(long long *)(use_time + time_curr * 2) != CURRENT_MODEL_TIME & time_update_gap)
    {
        if (time_curr >= 3)
            time_curr = 0;
        else
            time_curr += 1;

        *(long long *)(use_time + time_curr * 2) = CURRENT_MODEL_TIME & time_update_gap;
    }

    for (int q = 0; q < update_group.widget.size(); q++) // 更新数值
    {
        kind = update_group.kind[q];

        if (kind == 1) // 文本
        {
            const char *ptr = (char *)update_group.number_or_string[q];
            label = update_group.widget[q];

            GtkTextBuffer *buffer = gtk_text_view_get_buffer((GTK_TEXT_VIEW(label)));
            gtk_text_buffer_set_text(buffer, ptr, -1);
        }
        else if (kind == 2) // 4字节数值
        {
            const int *ptr = (int *)update_group.number_or_string[q];
            label = update_group.widget[q];

            char buf[32];
            snprintf(buf, sizeof(buf), "%d", *ptr);
            gtk_label_set_text(GTK_LABEL(label), buf);
        }
        else if (kind == 3) // 8字节数值
        {
            const long long *ptr = (long long *)update_group.number_or_string[q];
            label = update_group.widget[q];

            char buf[32];
            snprintf(buf, sizeof(buf), "%d", *ptr);
            gtk_label_set_text(GTK_LABEL(label), buf);
        }
    }

    string show_text;
    string response_text;
    GtkWidget *show_widget = inoutput_group.widget[10];
    GtkWidget *response_widget = inoutput_group.widget[13];

    vector<char> output_text_vector;

    // 更新文本
    for (int w = 1; w < gtk3_text_display.size(); w++)
    {
        string text_string(gtk3_text_display[w].input_string_A.begin(), gtk3_text_display[w].input_string_A.end());
        string order = to_string(w);
        show_text += order;
        show_text += text_string;
        show_text += "\n\n";

        response_text += order;
        output_text_vector = Network_To_CharVector(gtk3_text_display[w].Text_input_Inference_A_Idx);
        string output_text(output_text_vector.begin(), output_text_vector.end());
        response_text += output_text;
        response_text += "\n\n";
    }

    GtkTextBuffer *buffer = gtk_text_view_get_buffer((GTK_TEXT_VIEW(show_widget)));
    gtk_text_buffer_set_text(buffer, show_text.c_str(), -1);

    buffer = gtk_text_view_get_buffer((GTK_TEXT_VIEW(response_widget)));
    gtk_text_buffer_set_text(buffer, response_text.c_str(), -1);

    return TRUE;
}

// 函数-更新控件加入
void create_update(GtkWidget *widget, char kind, void *source)
{
    update_group.widget.push_back(widget);
    update_group.kind.push_back(kind);
    update_group.number_or_string.push_back((void *)source);
}

void init_model()
{
    // 加载 运行状态记录文件 & 预读取初始数据
    init_model_record();
    get_pre_load_file();
    init_image_enter_line();
    text_enter_ch_load();

    // 启动 执行端通讯线程
    thread base_t1(Socket_Thread);
    base_t1.detach();

    // 启动 数据库读写线程
    thread base_t2(Disk_Thread);
    base_t2.detach();

    // 启动 自动包清理线程
    thread base_t3(Cool_Pack_Delete);
    base_t3.detach();

    //
    gtk3_text_display.resize(1);
}

void interface_control(int argc, char *argv[])
{
    gtk_init(&argc, &argv);

    GtkWidget *window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_default_size(GTK_WINDOW(window), 1280, 720);
    g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);

    // 放进窗口
    GtkWidget *init_interface = gtk_fixed_new();
    gtk_container_add(GTK_CONTAINER(window), init_interface);

    inoutput_group.widget.reserve(20);
    inoutput_group.widget[0] = window;
    inoutput_group.widget[1] = init_interface;

    // 面板消息控制界面 功能

    // 尝试 与执行端通信
    const char text_1[16] = "建立通信";
    GtkWidget *button_1 = create_button(init_interface, 100, 160, 100, 130, 1, text_1);

    GtkWidget *display_11 = create_text_fixed_display(init_interface, 100, 160, 150, 180, text_11);
    inoutput_group.widget[2] = display_11; // 通信状态

    // 启动 默认工作模式
    const char text_2[16] = "模型启动";
    const char text_20[16] = "模型关闭";
    GtkWidget *button_2 = create_button(init_interface, 200, 260, 100, 130, 2, text_2);
    inoutput_group.widget[5] = button_2; // 启动

    GtkWidget *button_20 = create_button(init_interface, 200, 260, 100, 130, -2, text_20);
    inoutput_group.widget[4] = button_20; // 关闭

    GtkWidget *display_21 = create_text_fixed_display(init_interface, 200, 260, 150, 180, text_21);
    inoutput_group.widget[3] = display_21; // 显示

    // 设置 运行资源分配
    const char text_30[24] = "运行资源分配";

    const char text_31[24] = "当前使用线程数";
    GtkWidget *display_31 = create_number_display(init_interface, 500, 560, 50, 80);
    create_update(display_31, 3, &Calculate_Thread_Num);

    const char text_32[24] = "更改线程数";
    GtkWidget *button_32 = create_button(init_interface, 500, 560, 100, 130, 5, text_32);
    GtkWidget *input_32 = create_text_input(init_interface, 500, 560, 150, 180, "10");
    inoutput_group.widget[6] = input_32;

    const char text_33[24] = "当前内存上限";
    GtkWidget *button_33 = create_button(init_interface, 300, 360, 150, 180, 8, text_33);
    GtkWidget *input_33 = create_text_input(init_interface, 300, 360, 200, 230, "24");
    inoutput_group.widget[7] = input_33;

    const char text_34[24] = "当前内存量:G";
    GtkWidget *text_display_34 = create_text_fixed_display(init_interface, 300, 360, 250, 280, text_34);
    GtkWidget *num_display_34 = create_number_display(init_interface, 300, 360, 300, 330);
    create_update(num_display_34, 3, &CURRENT_SYSTEM_MEMORY);

    const char text_35[24] = "当前包上限";
    GtkWidget *button_35 = create_button(init_interface, 400, 460, 150, 180, 9, text_35);
    GtkWidget *num_input_35 = create_text_input(init_interface, 400, 460, 200, 230, "1400");
    inoutput_group.widget[8] = num_input_35;

    const char text_36[24] = "实际包量:万";
    GtkWidget *text_display_36 = create_text_fixed_display(init_interface, 400, 460, 250, 280, text_36);
    GtkWidget *num_display_36 = create_number_display(init_interface, 400, 460, 300, 330);
    create_update(num_display_36, 3, &Current_Pack_Num);

    const char text_37[32] = "十秒内图像节点生成数";

    const char text_38[32] = "十秒内概念节点生成数";

    const char text_39[32] = "十秒内文本节点生成数";

    // 显示 运行状态监控
    const char text_60[24] = "运行状态监控";

    const char text_61[24] = "已运行模型时间";
    GtkWidget *display_61 = create_number_display(init_interface, 100, 160, 50, 80);
    create_update(display_61, 3, &Code_Time);

    const char text_64[24] = "当前模型时间";
    GtkWidget *display_64 = create_number_display(init_interface, 200, 260, 50, 80);
    create_update(display_64, 3, &CURRENT_MODEL_TIME);

    const char text_62[24] = "已存储节点数量";
    create_text_fixed_display(init_interface, 300, 360, 100, 130, text_62);
    GtkWidget *display_62 = create_number_display(init_interface, 300, 360, 50, 80);
    create_update(display_62, 2, &NEWIST_USEFUL_ID);

    const char text_63[24] = "记录字符数";
    create_text_fixed_display(init_interface, 400, 460, 100, 130, text_63);
    GtkWidget *display_63 = create_number_display(init_interface, 400, 460, 50, 80);
    create_update(display_63, 2, &ALL_NUM_OF_CH);

    const char text_65[24] = "上次传输的间隔";
    GtkWidget *text_display_65 = create_text_fixed_display(init_interface, 100, 160, 250, 280, text_65);
    GtkWidget *display_65 = create_number_display(init_interface, 100, 160, 200, 230);
    create_update(display_65, 2, &Last_Gap_Model_Time);

    // 修改 模型参数控制
    const char text_40[24] = "模型参数控制";
    const char text_41[32] = "建模最小数量每秒";
    const char text_42[32] = "建模最大数量每秒";
    const char text_43[24] = "属性生成率";
    const char text_44[24] = "图像生成率";
    const char text_45[24] = "文本生成率";
    const char text_46[24] = "认知生成率";

    const char text_47[32] = "随机输出行为倾向";
    const char text_48[24] = "对象";
    const char text_49[24] = "值";

    // 输入 文本对话控制
    const char text_50[24] = "文本对话控制";

    const char text_51[24] = "追求目标";
    const char text_52[24] = "维持行为";
    const char text_53[24] = "解释文本";
    const char text_54[24] = "求知文本";
    const char text_55[24] = "赋予对象属性"; // 注意 好感 正确 合理 关联 独立
    const char text_56[24] = "回答对话";

    GtkWidget *input_57 = create_text_input(init_interface, 100, 300, 400, 600, text_57);
    inoutput_group.widget[7] = input_57; // 操作文本
    const char text_59[8] = "确认";
    GtkWidget *button_59 = create_button(init_interface, 100, 160, 350, 380, 6, text_59);
    inoutput_group.widget[8] = button_59; // 确认键
    const char text_510[16] = "操作类型";
    GtkWidget *input_510 = create_text_input(init_interface, 200, 260, 350, 380, text_510);
    inoutput_group.widget[9] = input_510; // 操作类型

    GtkWidget *output_58 = create_text_flowed_display(init_interface, 350, 550, 400, 600, text_58);
    inoutput_group.widget[10] = output_58; // 显示文本项目
    const char text_511[8] = "删除";
    GtkWidget *button_511 = create_button(init_interface, 350, 410, 350, 380, 7, text_511);
    inoutput_group.widget[11] = button_511; // 删除键
    const char text_512[16] = "删除项目";
    GtkWidget *input_512 = create_text_input(init_interface, 450, 510, 350, 380, text_512);
    inoutput_group.widget[12] = input_512; // 删除项目

    GtkWidget *output_513 = create_text_flowed_display(init_interface, 600, 1000, 400, 600, text_513);
    inoutput_group.widget[13] = output_513; // 显示文本回答

    // 显示切换

    setup_thread(10);

    g_timeout_add(100, update_timeout, NULL);
    gtk_widget_show_all(window);
    gtk_widget_hide(button_20);

    gtk_main();
}

void end_model()
{
    // 发送 执行端结束运行指令
    IF_NEED_WORKING = 0;
    IF_SELF_TURN_OFF = 0;
    IF_SELF_COMMUNIATE = 0;
    IF_SELF_CONNECT = 0;

    setup_thread(0);

    // 清零 思考活动新增注意力

    // 保存 预读取初始数据 & 运行状态文件
    save_pre_load_file();
    save_init_line_file();
    save_init_text_file();
    save_record_model();
}

/*
 * 主函数
 */
int main(int argc, char *argv[])
{
    // 1-模型初始化
    init_model();

    // 2-进入 控制界面 待机
    interface_control(argc, argv);

    // 3-运算端关机进程
    end_model();

    // 程序终点
    return 0;
}


//鏌愬浗娣卞眰鏀垮簻鐨勭暅鐢熶滑锛屾垜瀹佹効鍘绘涔熶笉灞堟湇浣犱滑楝奸偑鑸殑缁熸不